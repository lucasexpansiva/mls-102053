/// <mls fileReference="_102053_/l2/demo4/sign-in.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// DEMO 4 — SIGN IN: pagina real usando componentes com DS
// =============================================================================
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement, state } from 'lit/decorators.js';
import { StateLitElement } from '/_102029_/l2/stateLitElement.js';
import '/_102053_/l2/molecules/grouptriggeraction/ml-button-standard';
import '/_102053_/l2/molecules/groupentertext/ml-floating-text-input';
import '/_102053_/l2/molecules/groupenterboolean/ml-toggle-switch';
let Demo4SignIn = class Demo4SignIn extends StateLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`demo4--sign-in-102053 {
  --ml-primary: #4f46e5;
  --ml-on-primary: #ffffff;
  --ml-surface: #ffffff;
  --ml-surface-dim: #f9fafb;
  --ml-on-surface: #111827;
  --ml-on-surface-muted: #6b7280;
  --ml-on-surface-faint: #9ca3af;
  --ml-outline-variant: #e5e7eb;
  --ml-outline-focus: #4f46e5;
  --ml-outline-error: #ef4444;
  --ml-error: #ef4444;
  --ml-radius-sm: 8px;
  --ml-radius-full: 9999px;
  --ml-shadow-1: 0 1px 2px rgba(0, 0, 0, 0.05);
  --ml-shadow-2: 0 4px 6px rgba(0, 0, 0, 0.07);
  --ml-font-family: 'Inter', system-ui, -apple-system, sans-serif;
  --ml-focus-ring-color: rgba(79, 70, 229, 0.3);
  --ml-focus-ring-width: 3px;
  --ml-transition: 200ms ease;
}
demo4--sign-in-102053 .sign-in-page {
  min-height: 100vh;
  display: flex;
  align-items: center;
  justify-content: center;
  background: #f3f4f6;
  font-family: var(--ml-font-family);
  padding: 1rem;
}
demo4--sign-in-102053 .sign-in-card {
  width: 100%;
  max-width: 400px;
  background: var(--ml-surface);
  border: 1px solid var(--ml-outline-variant);
  border-radius: 12px;
  padding: 2.5rem 2rem;
  box-shadow: 0 4px 24px rgba(0, 0, 0, 0.06);
}
demo4--sign-in-102053 .sign-in-header {
  text-align: center;
  margin-bottom: 2rem;
}
demo4--sign-in-102053 .sign-in-title {
  font-size: 1.5rem;
  font-weight: 700;
  color: var(--ml-on-surface);
  margin: 0 0 0.25rem;
}
demo4--sign-in-102053 .sign-in-subtitle {
  font-size: 0.875rem;
  color: var(--ml-on-surface-muted);
  margin: 0;
}
demo4--sign-in-102053 .sign-in-error {
  background: #fef2f2;
  color: var(--ml-error);
  font-size: 0.8125rem;
  font-family: var(--ml-font-family);
  padding: 0.75rem 1rem;
  border-radius: 6px;
  margin-bottom: 1rem;
  border: 1px solid #fecaca;
}
demo4--sign-in-102053 .sign-in-form {
  display: flex;
  flex-direction: column;
}
demo4--sign-in-102053 .sign-in-options {
  display: flex;
  align-items: center;
  justify-content: space-between;
  margin: 1.25rem 0;
}
demo4--sign-in-102053 .sign-in-footer {
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 0.25rem;
  margin-top: 1.5rem;
  padding-top: 1.5rem;
  border-top: 1px solid var(--ml-outline-variant);
}
demo4--sign-in-102053 .sign-in-footer-text {
  font-size: 0.8125rem;
  color: var(--ml-on-surface-muted);
}
`);
        this.email = '';
        this.password = '';
        this.remember = false;
        this.loading = false;
        this.error = '';
    }
    handleSubmit() {
        if (!this.email || !this.password) {
            this.error = 'Preencha todos os campos';
            return;
        }
        this.error = '';
        this.loading = true;
        setTimeout(() => {
            this.loading = false;
        }, 2000);
    }
    render() {
        return html `
      <div class="sign-in-page">
        <div class="sign-in-card">

          <div class="sign-in-header">
            <h1 class="sign-in-title">Entrar</h1>
            <p class="sign-in-subtitle">Acesse sua conta para continuar</p>
          </div>

          ${this.error ? html `
            <div class="sign-in-error">${this.error}</div>
          ` : html ``}

          <div class="sign-in-form">
            <groupentertext--ml-floating-text-input
              .value=${this.email}
              input-type="email"
              placeholder="seu@email.com"
              .isEditing=${true}
              ?disabled=${this.loading}
              @input=${(e) => { this.email = e.detail?.value; }}>
              <Label>E-mail</Label>
            </groupentertext--ml-floating-text-input>

            <groupentertext--ml-floating-text-input
              data-class="mt-4"
              .value=${this.password}
              input-type="password"
              placeholder="********"
              .isEditing=${true}
              ?disabled=${this.loading}
              @input=${(e) => { this.password = e.detail?.value; }}>
              <Label>Senha</Label>
            </groupentertext--ml-floating-text-input>

            <div class="sign-in-options">
              <groupenterboolean--ml-toggle-switch
                .value=${this.remember}
                ?disabled=${this.loading}
                @change=${(e) => { this.remember = e.detail?.value; }}>
                <Label data-class="text-xs">Lembrar de mim</Label>
              </groupenterboolean--ml-toggle-switch>

              <grouptriggeraction--ml-button-standard data-variant="link" size="sm">
                <Label data-class="text-xs">Esqueci minha senha</Label>
              </grouptriggeraction--ml-button-standard>
            </div>

            <grouptriggeraction--ml-button-standard
              data-class="w-full"
              data-variant="primary"
              size="lg"
              ?loading=${this.loading}
              @action=${this.handleSubmit}>
              <Label>Entrar</Label>
            </grouptriggeraction--ml-button-standard>
          </div>

          <div class="sign-in-footer">
            <span class="sign-in-footer-text">Nao tem uma conta?</span>
            <grouptriggeraction--ml-button-standard data-variant="link" size="sm">
              <Label>Criar conta</Label>
            </grouptriggeraction--ml-button-standard>
          </div>

        </div>
      </div>
    `;
    }
};
__decorate([
    state()
], Demo4SignIn.prototype, "email", void 0);
__decorate([
    state()
], Demo4SignIn.prototype, "password", void 0);
__decorate([
    state()
], Demo4SignIn.prototype, "remember", void 0);
__decorate([
    state()
], Demo4SignIn.prototype, "loading", void 0);
__decorate([
    state()
], Demo4SignIn.prototype, "error", void 0);
Demo4SignIn = __decorate([
    customElement('demo4--sign-in-102053')
], Demo4SignIn);
export { Demo4SignIn };
