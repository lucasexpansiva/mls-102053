var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102053_/l2/demo1/acao-visualizacao.ts" enhancement="_102020_/l2/enhancementAura"/>
// GERADO a partir de todo/.demo-fragments/acao-visualizacao.frag.ts — base comparável demo1/demo2/demo3.
import { html } from 'lit';
import { customElement } from 'lit/decorators.js';
import { StateLitElement } from '/_102029_/l2/stateLitElement.js';
import '/_102040_/l2/molecules/grouptriggeraction/ml-button-standard';
import '/_102040_/l2/molecules/grouptriggeraction/ml-icon-button';
import '/_102040_/l2/molecules/grouptriggeraction/ml-split-button';
import '/_102040_/l2/molecules/groupshowprogress/ml-linear-progress';
import '/_102040_/l2/molecules/groupshowprogress/ml-circular-progress';
import '/_102040_/l2/molecules/groupviewcard/ml-profile-card';
import '/_102040_/l2/molecules/groupviewcard/ml-vertical-card';
import '/_102040_/l2/molecules/groupviewmetric/ml-metric-card';
import '/_102040_/l2/molecules/groupviewmetric/ml-metric-big-number';
let Demo1AcaoVisualizacao = class Demo1AcaoVisualizacao extends StateLitElement {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(`demo1--acao-visualizacao-102053 {
  display: block;
  font-family: 'Inter', system-ui, sans-serif;
}
demo1--acao-visualizacao-102053 .page {
  min-height: 100vh;
  padding: 2.5rem 2rem;
}
demo1--acao-visualizacao-102053 .shell {
  max-width: 64rem;
  margin: 0 auto;
}
demo1--acao-visualizacao-102053 .head {
  text-align: center;
  margin-bottom: 2.5rem;
}
demo1--acao-visualizacao-102053 .brand {
  font-weight: 700;
  letter-spacing: 0.05em;
  margin-bottom: 0.5rem;
}
demo1--acao-visualizacao-102053 .title {
  font-size: 1.625rem;
  font-weight: 700;
  margin-bottom: 0.25rem;
}
demo1--acao-visualizacao-102053 .subtitle {
  font-size: 0.8125rem;
}
demo1--acao-visualizacao-102053 .block {
  margin-bottom: 2rem;
  border-radius: 16px;
  padding: 1.5rem;
}
demo1--acao-visualizacao-102053 .block-title {
  font-size: 0.75rem;
  font-weight: 600;
  text-transform: uppercase;
  letter-spacing: 0.08em;
  margin-bottom: 0.75rem;
}
demo1--acao-visualizacao-102053 .grid {
  display: grid;
  grid-template-columns: repeat(2, minmax(0, 1fr));
  gap: 1.25rem;
  align-items: start;
}
demo1--acao-visualizacao-102053 .page {
  background: #f1f5f9;
}
demo1--acao-visualizacao-102053 .brand {
  color: #0369a1;
}
demo1--acao-visualizacao-102053 .title {
  color: #0f172a;
}
demo1--acao-visualizacao-102053 .subtitle {
  color: #64748b;
}
demo1--acao-visualizacao-102053 .block {
  background: #ffffff;
  border: 1px solid #e2e8f0;
}
demo1--acao-visualizacao-102053 .block-title {
  color: #94a3b8;
}
`);
    }
    render() {
        return html `
      <div class="page">
        <div class="shell">
          <header class="head">
            <div class="brand">◆ collab · 102040</div>
            <h1 class="title">Ação & Visualização — originais (102040)</h1>
            <p class="subtitle">button · icon · split · progress · cards · metrics</p>
          </header>

          <section class="block">
            <h2 class="block-title">groupTriggerAction — button / icon / split</h2>
            <div class="grid">
              <grouptriggeraction--ml-button-standard data-variant="primary"><Label>Primary</Label></grouptriggeraction--ml-button-standard>
              <grouptriggeraction--ml-button-standard data-variant="secondary"><Label>Secondary</Label></grouptriggeraction--ml-button-standard>
              <grouptriggeraction--ml-button-standard data-variant="danger"><Label>Danger</Label></grouptriggeraction--ml-button-standard>
              <grouptriggeraction--ml-icon-button data-variant="primary"><Icon>★</Icon><Label>Favoritar</Label></grouptriggeraction--ml-icon-button>
              <grouptriggeraction--ml-split-button data-variant="primary"><Label>Salvar</Label></grouptriggeraction--ml-split-button>
            </div>
          </section>

          <section class="block">
            <h2 class="block-title">groupShowProgress — linear / circular</h2>
            <div class="grid">
              <groupshowprogress--ml-linear-progress value="72" show-value label="Upload"></groupshowprogress--ml-linear-progress>
              <groupshowprogress--ml-linear-progress value="40" variant="success" size="sm" show-value></groupshowprogress--ml-linear-progress>
              <groupshowprogress--ml-circular-progress value="68" size="lg" show-value></groupshowprogress--ml-circular-progress>
              <groupshowprogress--ml-circular-progress value="33" size="lg" show-value></groupshowprogress--ml-circular-progress>
            </div>
          </section>

          <section class="block">
            <h2 class="block-title">groupViewCard — profile / vertical</h2>
            <div class="grid">
              <groupviewcard--ml-profile-card clickable="true">
                <CardTitle>Ada Lovelace</CardTitle>
                <CardDescription>Engenheira de software</CardDescription>
                <CardContent>Card de perfil clicável.</CardContent>
              </groupviewcard--ml-profile-card>
              <groupviewcard--ml-vertical-card>
                <CardTitle>Plano Pro</CardTitle>
                <CardDescription>R$ 49/mês</CardDescription>
                <CardContent>Card vertical com ação.</CardContent>
                <CardAction>
                  <grouptriggeraction--ml-button-standard data-variant="primary"><Label>Assinar</Label></grouptriggeraction--ml-button-standard>
                </CardAction>
              </groupviewcard--ml-vertical-card>
            </div>
          </section>

          <section class="block">
            <h2 class="block-title">groupViewMetric — metric-card / big-number</h2>
            <div class="grid">
              <groupviewmetric--ml-metric-card>
                <Icon>📈</Icon>
                <Label>Receita mensal</Label>
                <Value>R$ 128.430</Value>
                <Trend direction="up">+12,5%</Trend>
                <Helper>vs. mês anterior</Helper>
              </groupviewmetric--ml-metric-card>
              <groupviewmetric--ml-metric-card>
                <Icon>👥</Icon>
                <Label>Churn</Label>
                <Value>3,2%</Value>
                <Trend direction="down">-0,8%</Trend>
                <Helper>últimos 30 dias</Helper>
              </groupviewmetric--ml-metric-card>
              <groupviewmetric--ml-metric-big-number>
                <Label>Usuários ativos</Label>
                <Value>24.918</Value>
                <Trend direction="up">▲ 8,1%</Trend>
                <Helper>Atualizado há 5 min</Helper>
              </groupviewmetric--ml-metric-big-number>
            </div>
          </section>
        </div>
      </div>
    `;
    }
};
Demo1AcaoVisualizacao = __decorate([
    customElement('demo1--acao-visualizacao-102053')
], Demo1AcaoVisualizacao);
export { Demo1AcaoVisualizacao };
