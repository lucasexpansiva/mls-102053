var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102053_/l2/demo1/selecao.ts" enhancement="_102020_/l2/enhancementAura"/>
// GERADO a partir de todo/.demo-fragments/selecao.frag.ts — base comparável demo1/demo2/demo3.
import { html } from 'lit';
import { customElement, state } from 'lit/decorators.js';
import { StateLitElement } from '/_102029_/l2/stateLitElement.js';
import '/_102040_/l2/molecules/groupselectone/ml-select-dropdown';
import '/_102040_/l2/molecules/groupselectone/ml-radio-group';
import '/_102040_/l2/molecules/groupselectone/ml-segmented-control';
import '/_102040_/l2/molecules/groupselectone/ml-combobox';
import '/_102040_/l2/molecules/groupselectone/ml-card-selector';
import '/_102040_/l2/molecules/groupselectmany/ml-multi-select-dropdown';
import '/_102040_/l2/molecules/groupselectmany/ml-popover-multi-select';
import '/_102040_/l2/molecules/groupsearchcontent/ml-search-bar';
import '/_102040_/l2/molecules/groupselectfileforupload/ml-file-upload-dropzone';
let Demo1Selecao = class Demo1Selecao extends StateLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`demo1--selecao-102053 {
  display: block;
  font-family: 'Inter', system-ui, sans-serif;
}
demo1--selecao-102053 .page {
  min-height: 100vh;
  padding: 2.5rem 2rem;
}
demo1--selecao-102053 .shell {
  max-width: 64rem;
  margin: 0 auto;
}
demo1--selecao-102053 .head {
  text-align: center;
  margin-bottom: 2.5rem;
}
demo1--selecao-102053 .brand {
  font-weight: 700;
  letter-spacing: 0.05em;
  margin-bottom: 0.5rem;
}
demo1--selecao-102053 .title {
  font-size: 1.625rem;
  font-weight: 700;
  margin-bottom: 0.25rem;
}
demo1--selecao-102053 .subtitle {
  font-size: 0.8125rem;
}
demo1--selecao-102053 .block {
  margin-bottom: 2rem;
  border-radius: 16px;
  padding: 1.5rem;
}
demo1--selecao-102053 .block-title {
  font-size: 0.75rem;
  font-weight: 600;
  text-transform: uppercase;
  letter-spacing: 0.08em;
  margin-bottom: 0.75rem;
}
demo1--selecao-102053 .grid {
  display: grid;
  grid-template-columns: repeat(2, minmax(0, 1fr));
  gap: 1.25rem;
  align-items: start;
}
demo1--selecao-102053 .page {
  background: #f1f5f9;
}
demo1--selecao-102053 .brand {
  color: #0369a1;
}
demo1--selecao-102053 .title {
  color: #0f172a;
}
demo1--selecao-102053 .subtitle {
  color: #64748b;
}
demo1--selecao-102053 .block {
  background: #ffffff;
  border: 1px solid #e2e8f0;
}
demo1--selecao-102053 .block-title {
  color: #94a3b8;
}
`);
        this.country = 'br';
        this.plan = 'standard';
        this.view = 'week';
        this.fruit = 'banana';
        this.tier = 'team';
        this.skills = 'ts,js';
        this.hab = 'lit,ts';
        this.q = 'lit';
    }
    upd(key) {
        return (e) => {
            this[key] = e.detail?.value;
        };
    }
    render() {
        return html `
      <div class="page">
        <div class="shell">
          <header class="head">
            <div class="brand">◆ collab · 102040</div>
            <h1 class="title">Seleção — originais (102040)</h1>
            <p class="subtitle">select-one · select-many · search · upload</p>
          </header>

          <section class="block">
            <h2 class="block-title">groupSelectOne — dropdown / radio / segmented / combobox / card</h2>
            <div class="grid">
              <groupselectone--ml-select-dropdown name="country" searchable="true" .value=${this.country} .isEditing=${true} @change=${this.upd('country')}>
                <Label>País</Label>
                <Helper>Selecionado: ${this.country ?? '—'}</Helper>
                <Item value="br">Brasil</Item>
                <Item value="us">Estados Unidos</Item>
                <Item value="pt">Portugal</Item>
                <Item value="jp">Japão</Item>
              </groupselectone--ml-select-dropdown>
              <groupselectone--ml-radio-group name="plan" .value=${this.plan} .isEditing=${true} @change=${this.upd('plan')}>
                <Label>Plano</Label>
                <Item value="free">Gratuito</Item>
                <Item value="standard">Standard</Item>
                <Item value="pro">Pro</Item>
              </groupselectone--ml-radio-group>
              <groupselectone--ml-segmented-control name="view" .value=${this.view} .isEditing=${true} @change=${this.upd('view')}>
                <Label>Visualização</Label>
                <Item value="day">Dia</Item>
                <Item value="week">Semana</Item>
                <Item value="month">Mês</Item>
              </groupselectone--ml-segmented-control>
              <groupselectone--ml-combobox .value=${this.fruit} clearable .isEditing=${true} @change=${this.upd('fruit')}>
                <Label>Fruta</Label>
                <Helper>Selecionado: ${this.fruit ?? '—'}</Helper>
                <Item value="apple">Maçã</Item>
                <Item value="banana">Banana</Item>
                <Item value="grape">Uva</Item>
                <Item value="orange">Laranja</Item>
              </groupselectone--ml-combobox>
              <groupselectone--ml-card-selector name="tier" .value=${this.tier} .isEditing=${true} @change=${this.upd('tier')}>
                <Label>Nível</Label>
                <Item value="starter">Starter</Item>
                <Item value="team">Team</Item>
                <Item value="business">Business</Item>
              </groupselectone--ml-card-selector>
            </div>
          </section>

          <section class="block">
            <h2 class="block-title">groupSelectMany — multi-select / popover</h2>
            <div class="grid">
              <groupselectmany--ml-multi-select-dropdown name="skills" searchable="true" .value=${this.skills} .isEditing=${true} @change=${this.upd('skills')}>
                <Label>Tecnologias</Label>
                <Helper>Selecionadas: ${this.skills || '—'}</Helper>
                <Item value="ts">TypeScript</Item>
                <Item value="js">JavaScript</Item>
                <Item value="py">Python</Item>
                <Item value="go">Go</Item>
              </groupselectmany--ml-multi-select-dropdown>
              <groupselectmany--ml-popover-multi-select searchable max-selection="3" .value=${this.hab} .isEditing=${true} @change=${this.upd('hab')}>
                <Label>Habilidades (máx. 3)</Label>
                <Helper>Selecionadas: ${this.hab || '—'}</Helper>
                <Item value="lit">Lit</Item>
                <Item value="ts">TypeScript</Item>
                <Item value="less">LESS</Item>
                <Item value="a11y">Acessibilidade</Item>
                <Item value="design">Design Systems</Item>
              </groupselectmany--ml-popover-multi-select>
            </div>
          </section>

          <section class="block">
            <h2 class="block-title">groupSearchContent / groupSelectFileForUpload</h2>
            <div class="grid">
              <groupsearchcontent--ml-search-bar .value=${this.q} @change=${this.upd('q')}>
                <Label>Buscar</Label>
                <Helper>Última busca: ${this.q ?? '—'}</Helper>
                <Suggestion value="lit">Lit</Suggestion>
                <Suggestion value="ts">TypeScript</Suggestion>
                <Suggestion value="less">LESS</Suggestion>
                <Suggestion value="glass">Glassmorphism</Suggestion>
              </groupsearchcontent--ml-search-bar>
              <groupselectfileforupload--ml-file-upload-dropzone multiple accept="image/*" max-files="5" max-size-kb="2048">
                <Label>Imagens</Label>
                <Helper>Até 5 imagens, máx. 2 MB cada</Helper>
              </groupselectfileforupload--ml-file-upload-dropzone>
            </div>
          </section>
        </div>
      </div>
    `;
    }
};
__decorate([
    state()
], Demo1Selecao.prototype, "country", void 0);
__decorate([
    state()
], Demo1Selecao.prototype, "plan", void 0);
__decorate([
    state()
], Demo1Selecao.prototype, "view", void 0);
__decorate([
    state()
], Demo1Selecao.prototype, "fruit", void 0);
__decorate([
    state()
], Demo1Selecao.prototype, "tier", void 0);
__decorate([
    state()
], Demo1Selecao.prototype, "skills", void 0);
__decorate([
    state()
], Demo1Selecao.prototype, "hab", void 0);
__decorate([
    state()
], Demo1Selecao.prototype, "q", void 0);
Demo1Selecao = __decorate([
    customElement('demo1--selecao-102053')
], Demo1Selecao);
export { Demo1Selecao };
