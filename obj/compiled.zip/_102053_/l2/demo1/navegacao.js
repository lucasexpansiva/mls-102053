var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102053_/l2/demo1/navegacao.ts" enhancement="_102020_/l2/enhancementAura"/>
// GERADO a partir de todo/.demo-fragments/navegacao.frag.ts — base comparável demo1/demo2/demo3.
import { html } from 'lit';
import { customElement, state } from 'lit/decorators.js';
import { StateLitElement } from '/_102029_/l2/stateLitElement.js';
import '/_102040_/l2/molecules/groupnavigatesection/ml-tabs';
import '/_102040_/l2/molecules/groupnavigatesection/ml-navigate-pills';
import '/_102040_/l2/molecules/groupnavigatesection/ml-breadcrumb-trail';
import '/_102040_/l2/molecules/groupnavigatesteps/ml-horizontal-stepper';
import '/_102040_/l2/molecules/groupnavigatesteps/ml-wizard-steps';
import '/_102040_/l2/molecules/groupnavigatemain/ml-sidebar-nav';
let Demo1Navegacao = class Demo1Navegacao extends StateLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`demo1--navegacao-102053 {
  display: block;
  font-family: 'Inter', system-ui, sans-serif;
}
demo1--navegacao-102053 .page {
  min-height: 100vh;
  padding: 2.5rem 2rem;
}
demo1--navegacao-102053 .shell {
  max-width: 64rem;
  margin: 0 auto;
}
demo1--navegacao-102053 .head {
  text-align: center;
  margin-bottom: 2.5rem;
}
demo1--navegacao-102053 .brand {
  font-weight: 700;
  letter-spacing: 0.05em;
  margin-bottom: 0.5rem;
}
demo1--navegacao-102053 .title {
  font-size: 1.625rem;
  font-weight: 700;
  margin-bottom: 0.25rem;
}
demo1--navegacao-102053 .subtitle {
  font-size: 0.8125rem;
}
demo1--navegacao-102053 .block {
  margin-bottom: 2rem;
  border-radius: 16px;
  padding: 1.5rem;
}
demo1--navegacao-102053 .block-title {
  font-size: 0.75rem;
  font-weight: 600;
  text-transform: uppercase;
  letter-spacing: 0.08em;
  margin-bottom: 0.75rem;
}
demo1--navegacao-102053 .grid {
  display: grid;
  grid-template-columns: repeat(2, minmax(0, 1fr));
  gap: 1.25rem;
  align-items: start;
}
demo1--navegacao-102053 .page {
  background: #f1f5f9;
}
demo1--navegacao-102053 .brand {
  color: #0369a1;
}
demo1--navegacao-102053 .title {
  color: #0f172a;
}
demo1--navegacao-102053 .subtitle {
  color: #64748b;
}
demo1--navegacao-102053 .block {
  background: #ffffff;
  border: 1px solid #e2e8f0;
}
demo1--navegacao-102053 .block-title {
  color: #94a3b8;
}
`);
        this.main = 'dashboard';
        this.tab = 'details';
        this.pill = 'overview';
        this.step = 1;
        this.wiz = 1;
    }
    upd(key) {
        return (e) => {
            this[key] = e.detail?.value;
        };
    }
    render() {
        return html `
      <div class="page">
        <div class="shell">
          <header class="head">
            <div class="brand">◆ collab · 102040</div>
            <h1 class="title">Navegação — originais (102040)</h1>
            <p class="subtitle">tabs · pills · breadcrumb · stepper · wizard · sidebar</p>
          </header>

          <section class="block">
            <h2 class="block-title">groupNavigateSection — tabs / pills / breadcrumb</h2>
            <div class="grid">
              <groupnavigatesection--ml-tabs .value=${this.tab} @change=${this.upd('tab')}>
                <Label>Produto</Label>
                <Tab value="details" title="Detalhes">Descrição do produto.</Tab>
                <Tab value="reviews" title="Avaliações">Comentários dos clientes.</Tab>
              </groupnavigatesection--ml-tabs>
              <groupnavigatesection--ml-navigate-pills .value=${this.pill} @change=${this.upd('pill')}>
                <Label>Seções</Label>
                <Tab value="overview" title="Visão geral">Resumo.</Tab>
                <Tab value="team" title="Equipe">Pessoas.</Tab>
              </groupnavigatesection--ml-navigate-pills>
              <groupnavigatesection--ml-breadcrumb-trail value="produto">
                <Tab value="home" title="Início">Home.</Tab>
                <Tab value="catalogo" title="Catálogo">Catálogo.</Tab>
                <Tab value="produto" title="Notebook Pro">Produto atual.</Tab>
              </groupnavigatesection--ml-breadcrumb-trail>
            </div>
          </section>

          <section class="block">
            <h2 class="block-title">groupNavigateSteps — horizontal / wizard</h2>
            <div class="grid">
              <groupnavigatesteps--ml-horizontal-stepper .value=${this.step} @change=${this.upd('step')}>
                <Label>Cadastro (etapa ${this.step})</Label>
                <Step title="Conta" description="Acesso"></Step>
                <Step title="Perfil" description="Dados"></Step>
                <Step title="Pagamento" description="Plano"></Step>
                <Step title="Pronto" description="Revisão"></Step>
              </groupnavigatesteps--ml-horizontal-stepper>
              <groupnavigatesteps--ml-wizard-steps .value=${this.wiz} linear="false" @change=${this.upd('wiz')}>
                <Label>Onboarding (etapa ${this.wiz})</Label>
                <Step title="Conta" description="Acesso" completed></Step>
                <Step title="Perfil" description="Dados pessoais"></Step>
                <Step title="Plano" description="Escolha"></Step>
              </groupnavigatesteps--ml-wizard-steps>
            </div>
          </section>

          <section class="block">
            <h2 class="block-title">groupNavigateMain — sidebar-nav</h2>
            <div class="grid">
              <div style="height:22rem; border-radius:14px; overflow:hidden; display:flex;">
                <groupnavigatemain--ml-sidebar-nav .value=${this.main} @change=${this.upd('main')}>
                  <Label>Aurora</Label>
                  <Item value="dashboard" icon="▦">Dashboard</Item>
                  <Item value="projects" icon="▤" badge="3">Projetos</Item>
                  <Group label="Workspace">
                    <Item value="tasks" icon="✓">Tarefas</Item>
                    <Item value="calendar" icon="▣">Calendário</Item>
                  </Group>
                  <Footer>
                    <Item value="settings" icon="⚙">Configurações</Item>
                  </Footer>
                </groupnavigatemain--ml-sidebar-nav>
              </div>
            </div>
          </section>
        </div>
      </div>
    `;
    }
};
__decorate([
    state()
], Demo1Navegacao.prototype, "main", void 0);
__decorate([
    state()
], Demo1Navegacao.prototype, "tab", void 0);
__decorate([
    state()
], Demo1Navegacao.prototype, "pill", void 0);
__decorate([
    state()
], Demo1Navegacao.prototype, "step", void 0);
__decorate([
    state()
], Demo1Navegacao.prototype, "wiz", void 0);
Demo1Navegacao = __decorate([
    customElement('demo1--navegacao-102053')
], Demo1Navegacao);
export { Demo1Navegacao };
