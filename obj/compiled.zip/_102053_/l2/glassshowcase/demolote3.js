var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102053_/l2/glassshowcase/demolote3.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// GLASS SHOWCASE — DEMO LOTE 3 (botões e cards)
// =============================================================================
import { html } from 'lit';
import { customElement } from 'lit/decorators.js';
import { StateLitElement } from '/_102029_/l2/stateLitElement.js';
import '/_102054_/l2/molecules/grouptriggeraction/ml-icon-button';
import '/_102054_/l2/molecules/grouptriggeraction/ml-split-button';
import '/_102054_/l2/molecules/groupviewcard/ml-profile-card';
import '/_102054_/l2/molecules/groupviewcard/ml-vertical-card';
import '/_102054_/l2/molecules/grouptriggeraction/ml-button-standard';
let GlassShowcaseDemoLote3 = class GlassShowcaseDemoLote3 extends StateLitElement {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(`@font-face {
  font-family: 'Inter';
  font-style: normal;
  font-weight: 400;
  font-display: swap;
  src: url(https://fonts.gstatic.com/s/inter/v20/UcCO3FwrK3iLTeHuS_nVMrMxCp50SjIw2boKoduKmMEVuLyfMZg.ttf) format('truetype');
}
@font-face {
  font-family: 'Inter';
  font-style: normal;
  font-weight: 500;
  font-display: swap;
  src: url(https://fonts.gstatic.com/s/inter/v20/UcCO3FwrK3iLTeHuS_nVMrMxCp50SjIw2boKoduKmMEVuI6fMZg.ttf) format('truetype');
}
@font-face {
  font-family: 'Inter';
  font-style: normal;
  font-weight: 600;
  font-display: swap;
  src: url(https://fonts.gstatic.com/s/inter/v20/UcCO3FwrK3iLTeHuS_nVMrMxCp50SjIw2boKoduKmMEVuGKYMZg.ttf) format('truetype');
}
@font-face {
  font-family: 'Inter';
  font-style: normal;
  font-weight: 700;
  font-display: swap;
  src: url(https://fonts.gstatic.com/s/inter/v20/UcCO3FwrK3iLTeHuS_nVMrMxCp50SjIw2boKoduKmMEVuFuYMZg.ttf) format('truetype');
}
glassshowcase--demolote3-102053 {
  display: block;
  font-family: 'Inter', system-ui, sans-serif;
}
glassshowcase--demolote3-102053 .page {
  min-height: 100vh;
  padding: 2.5rem 2rem;
  background: radial-gradient(circle at 15% 15%, #4c1d95 0%, transparent 55%), radial-gradient(circle at 85% 85%, #be185d 0%, transparent 50%), linear-gradient(135deg, #0b1220 0%, #1e1b4b 100%);
  background-attachment: fixed;
}
glassshowcase--demolote3-102053 .shell {
  max-width: 44rem;
  margin: 0 auto;
}
glassshowcase--demolote3-102053 .head {
  text-align: center;
  margin-bottom: 2.5rem;
}
glassshowcase--demolote3-102053 .brand {
  color: #c7d2fe;
  font-weight: 700;
  letter-spacing: 0.05em;
  margin-bottom: 0.5rem;
}
glassshowcase--demolote3-102053 .title {
  color: #fff;
  font-size: 1.75rem;
  font-weight: 700;
  margin-bottom: 0.25rem;
}
glassshowcase--demolote3-102053 .subtitle {
  color: rgba(255, 255, 255, 0.65);
  font-size: 0.875rem;
}
glassshowcase--demolote3-102053 .block {
  margin-bottom: 2rem;
}
glassshowcase--demolote3-102053 .block-title {
  color: rgba(255, 255, 255, 0.55);
  font-size: 0.75rem;
  font-weight: 600;
  text-transform: uppercase;
  letter-spacing: 0.08em;
  margin-bottom: 0.75rem;
}
glassshowcase--demolote3-102053 .row {
  display: flex;
  flex-wrap: wrap;
  gap: 1rem;
  align-items: center;
}
glassshowcase--demolote3-102053 .cards {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(240px, 1fr));
  gap: 1.5rem;
}
`);
    }
    render() {
        return html `
      <div class="page">
        <div class="shell">
          <header class="head">
            <div class="brand">◆ Aurora</div>
            <h1 class="title">Lote 3 — Botões e Cards</h1>
            <p class="subtitle">icon-button · split-button · profile-card · vertical-card</p>
          </header>

          <section class="block">
            <h2 class="block-title">Icon Button</h2>
            <div class="row">
              <grouptriggeraction--ml-icon-button size="sm"><Label>Buscar</Label><Icon><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="100%" height="100%"><circle cx="11" cy="11" r="7"/><path d="M21 21l-4.3-4.3"/></svg></Icon></grouptriggeraction--ml-icon-button>
              <grouptriggeraction--ml-icon-button size="md"><Label>Adicionar</Label><Icon><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="100%" height="100%"><path d="M12 5v14M5 12h14"/></svg></Icon></grouptriggeraction--ml-icon-button>
              <grouptriggeraction--ml-icon-button size="lg" loading="true"><Label>Carregando</Label></grouptriggeraction--ml-icon-button>
            </div>
          </section>

          <section class="block">
            <h2 class="block-title">Split Button</h2>
            <div class="row">
              <grouptriggeraction--ml-split-button>
                <Label value="save">Salvar</Label>
                <span value="save-new">Salvar e criar novo</span>
                <span value="save-copy">Salvar como cópia</span>
              </grouptriggeraction--ml-split-button>
            </div>
          </section>

          <section class="block">
            <h2 class="block-title">Cards</h2>
            <div class="cards">
              <groupviewcard--ml-profile-card clickable="true">
                <CardTitle>Ada Lovelace</CardTitle>
                <CardDescription>Engenheira de software</CardDescription>
                <CardContent>Card de perfil clicável em vidro.</CardContent>
              </groupviewcard--ml-profile-card>

              <groupviewcard--ml-vertical-card selected="true">
                <CardTitle>Plano Pro</CardTitle>
                <CardDescription>R$ 49/mês (selecionado)</CardDescription>
                <CardContent>Card vertical com ação.</CardContent>
                <CardAction>
                  <grouptriggeraction--ml-button-standard data-variant="primary"><Label>Assinar</Label></grouptriggeraction--ml-button-standard>
                </CardAction>
              </groupviewcard--ml-vertical-card>
            </div>
          </section>
        </div>
      </div>
    `;
    }
};
GlassShowcaseDemoLote3 = __decorate([
    customElement('glassshowcase--demolote3-102053')
], GlassShowcaseDemoLote3);
export { GlassShowcaseDemoLote3 };
