var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102053_/l2/glassshowcase/demolote2.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// GLASS SHOWCASE — DEMO LOTE 2 (overlays)
// =============================================================================
// Reúne os overlays glass do lote 2 (mls-102054): banner, toast, modal, reveal.
// A página é o contrato de container (fundo escuro rico).
import { html } from 'lit';
import { customElement, state } from 'lit/decorators.js';
import { StateLitElement } from '/_102029_/l2/stateLitElement.js';
import '/_102054_/l2/molecules/groupnotifyuser/ml-notify-banner';
import '/_102054_/l2/molecules/groupnotifyuser/ml-toast-notification';
import '/_102054_/l2/molecules/groupnotifyuser/ml-alert-modal';
import '/_102054_/l2/molecules/groupexpandcontent/ml-reveal-overlay';
import '/_102054_/l2/molecules/grouptriggeraction/ml-button-standard';
let GlassShowcaseDemoLote2 = class GlassShowcaseDemoLote2 extends StateLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`@font-face {
  font-family: 'Inter';
  font-style: normal;
  font-weight: 400;
  font-display: swap;
  src: url(https://fonts.gstatic.com/s/inter/v20/UcCO3FwrK3iLTeHuS_nVMrMxCp50SjIw2boKoduKmMEVuLyfMZg.ttf) format('truetype');
}
@font-face {
  font-family: 'Inter';
  font-style: normal;
  font-weight: 500;
  font-display: swap;
  src: url(https://fonts.gstatic.com/s/inter/v20/UcCO3FwrK3iLTeHuS_nVMrMxCp50SjIw2boKoduKmMEVuI6fMZg.ttf) format('truetype');
}
@font-face {
  font-family: 'Inter';
  font-style: normal;
  font-weight: 600;
  font-display: swap;
  src: url(https://fonts.gstatic.com/s/inter/v20/UcCO3FwrK3iLTeHuS_nVMrMxCp50SjIw2boKoduKmMEVuGKYMZg.ttf) format('truetype');
}
@font-face {
  font-family: 'Inter';
  font-style: normal;
  font-weight: 700;
  font-display: swap;
  src: url(https://fonts.gstatic.com/s/inter/v20/UcCO3FwrK3iLTeHuS_nVMrMxCp50SjIw2boKoduKmMEVuFuYMZg.ttf) format('truetype');
}
glassshowcase--demolote2-102053 {
  display: block;
  font-family: 'Inter', system-ui, sans-serif;
}
glassshowcase--demolote2-102053 .page {
  min-height: 100vh;
  padding: 2.5rem 2rem;
  background: radial-gradient(circle at 15% 15%, #4c1d95 0%, transparent 55%), radial-gradient(circle at 85% 85%, #be185d 0%, transparent 50%), linear-gradient(135deg, #0b1220 0%, #1e1b4b 100%);
  background-attachment: fixed;
}
glassshowcase--demolote2-102053 .shell {
  max-width: 40rem;
  margin: 0 auto;
}
glassshowcase--demolote2-102053 .head {
  text-align: center;
  margin-bottom: 2.5rem;
}
glassshowcase--demolote2-102053 .brand {
  color: #c7d2fe;
  font-weight: 700;
  letter-spacing: 0.05em;
  margin-bottom: 0.5rem;
}
glassshowcase--demolote2-102053 .title {
  color: #fff;
  font-size: 1.75rem;
  font-weight: 700;
  margin-bottom: 0.25rem;
}
glassshowcase--demolote2-102053 .subtitle {
  color: rgba(255, 255, 255, 0.65);
  font-size: 0.875rem;
}
glassshowcase--demolote2-102053 .block {
  margin-bottom: 2rem;
  display: flex;
  flex-direction: column;
  gap: 0.75rem;
  align-items: flex-start;
}
glassshowcase--demolote2-102053 .block-title {
  color: rgba(255, 255, 255, 0.55);
  font-size: 0.75rem;
  font-weight: 600;
  text-transform: uppercase;
  letter-spacing: 0.08em;
}
`);
        this.bannerVisible = true;
        this.toastVisible = true;
        this.modalOpen = false;
    }
    render() {
        return html `
      <div class="page">
        <div class="shell">
          <header class="head">
            <div class="brand">◆ Aurora</div>
            <h1 class="title">Lote 2 — Overlays</h1>
            <p class="subtitle">banner · toast · modal · reveal (glassmorphism)</p>
          </header>

          <!-- Banner -->
          <section class="block">
            <h2 class="block-title">Notify Banner</h2>
            <groupnotifyuser--ml-notify-banner
              type="info"
              .visible=${this.bannerVisible}
              @dismiss=${() => {
            this.bannerVisible = false;
        }}
            >
              <Title>Atualização disponível</Title>
              <Message>Uma nova versão está pronta para instalar.</Message>
              <Action>Atualizar</Action>
            </groupnotifyuser--ml-notify-banner>
            ${!this.bannerVisible
            ? html `<grouptriggeraction--ml-button-standard
                  data-variant="ghost"
                  size="sm"
                  @action=${() => {
                this.bannerVisible = true;
            }}
                  ><Label>Mostrar banner</Label></grouptriggeraction--ml-button-standard
                >`
            : html ``}
          </section>

          <!-- Toast -->
          <section class="block">
            <h2 class="block-title">Toast Notification</h2>
            <groupnotifyuser--ml-toast-notification
              type="success"
              .visible=${this.toastVisible}
              @dismiss=${() => {
            this.toastVisible = false;
        }}
            >
              <Title>Salvo!</Title>
              <Message>Suas alterações foram salvas.</Message>
            </groupnotifyuser--ml-toast-notification>
            ${!this.toastVisible
            ? html `<grouptriggeraction--ml-button-standard
                  data-variant="ghost"
                  size="sm"
                  @action=${() => {
                this.toastVisible = true;
            }}
                  ><Label>Mostrar toast</Label></grouptriggeraction--ml-button-standard
                >`
            : html ``}
          </section>

          <!-- Modal -->
          <section class="block">
            <h2 class="block-title">Alert Modal</h2>
            <grouptriggeraction--ml-button-standard
              data-variant="primary"
              @action=${() => {
            this.modalOpen = true;
        }}
            >
              <Label>Abrir modal</Label>
            </grouptriggeraction--ml-button-standard>
          </section>

          <!-- Reveal -->
          <section class="block">
            <h2 class="block-title">Reveal Overlay</h2>
            <groupexpandcontent--ml-reveal-overlay multiple="true">
              <Label>Conteúdo oculto até revelar</Label>
              <Section title="Chave de API">sk-live-9f8a7b6c5d4e3f2a1b0c9d8e7f6a5b4c</Section>
              <Section title="Token">eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...</Section>
            </groupexpandcontent--ml-reveal-overlay>
          </section>
        </div>

        <groupnotifyuser--ml-alert-modal
          type="warning"
          .visible=${this.modalOpen}
          @dismiss=${() => {
            this.modalOpen = false;
        }}
        >
          <Title>Confirmar ação</Title>
          <Message>O scrim desfoca esta página atrás do modal.</Message>
          <Action>
            <grouptriggeraction--ml-button-standard
              data-variant="ghost"
              @action=${() => {
            this.modalOpen = false;
        }}
              ><Label>Cancelar</Label></grouptriggeraction--ml-button-standard
            >
            <grouptriggeraction--ml-button-standard
              data-variant="primary"
              @action=${() => {
            this.modalOpen = false;
        }}
              ><Label>Confirmar</Label></grouptriggeraction--ml-button-standard
            >
          </Action>
        </groupnotifyuser--ml-alert-modal>
      </div>
    `;
    }
};
__decorate([
    state()
], GlassShowcaseDemoLote2.prototype, "bannerVisible", void 0);
__decorate([
    state()
], GlassShowcaseDemoLote2.prototype, "toastVisible", void 0);
__decorate([
    state()
], GlassShowcaseDemoLote2.prototype, "modalOpen", void 0);
GlassShowcaseDemoLote2 = __decorate([
    customElement('glassshowcase--demolote2-102053')
], GlassShowcaseDemoLote2);
export { GlassShowcaseDemoLote2 };
