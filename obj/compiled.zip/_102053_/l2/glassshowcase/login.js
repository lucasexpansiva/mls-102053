var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102053_/l2/glassshowcase/login.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// GLASS SHOWCASE — LOGIN
// =============================================================================
// Página real usando as moléculas glass do mls-102054 (import cross-project).
// Padrão controlado: .value + .isEditing + @input/@change realimentando o @state.
// A página É o contrato de container (fundo escuro rico) — ver login.less.
import { html } from 'lit';
import { customElement, state } from 'lit/decorators.js';
import { StateLitElement } from '/_102029_/l2/stateLitElement.js';
// Moléculas glass (mls-102054)
import '/_102054_/l2/molecules/groupentertext/ml-floating-text-input';
import '/_102054_/l2/molecules/groupenterboolean/ml-toggle-switch';
import '/_102054_/l2/molecules/grouptriggeraction/ml-button-standard';
let GlassShowcaseLogin = class GlassShowcaseLogin extends StateLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`@font-face {
  font-family: 'Inter';
  font-style: normal;
  font-weight: 400;
  font-display: swap;
  src: url(https://fonts.gstatic.com/s/inter/v20/UcCO3FwrK3iLTeHuS_nVMrMxCp50SjIw2boKoduKmMEVuLyfMZg.ttf) format('truetype');
}
@font-face {
  font-family: 'Inter';
  font-style: normal;
  font-weight: 500;
  font-display: swap;
  src: url(https://fonts.gstatic.com/s/inter/v20/UcCO3FwrK3iLTeHuS_nVMrMxCp50SjIw2boKoduKmMEVuI6fMZg.ttf) format('truetype');
}
@font-face {
  font-family: 'Inter';
  font-style: normal;
  font-weight: 600;
  font-display: swap;
  src: url(https://fonts.gstatic.com/s/inter/v20/UcCO3FwrK3iLTeHuS_nVMrMxCp50SjIw2boKoduKmMEVuGKYMZg.ttf) format('truetype');
}
@font-face {
  font-family: 'Inter';
  font-style: normal;
  font-weight: 700;
  font-display: swap;
  src: url(https://fonts.gstatic.com/s/inter/v20/UcCO3FwrK3iLTeHuS_nVMrMxCp50SjIw2boKoduKmMEVuFuYMZg.ttf) format('truetype');
}
glassshowcase--login-102053 {
  display: block;
  font-family: 'Inter', system-ui, sans-serif;
  color: white;
}
glassshowcase--login-102053 .page {
  min-height: 100vh;
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 2rem;
  background: radial-gradient(circle at 20% 20%, #4c1d95 0%, transparent 55%), radial-gradient(circle at 80% 70%, #be185d 0%, transparent 50%), linear-gradient(135deg, #0b1220 0%, #1e1b4b 100%);
  background-attachment: fixed;
}
glassshowcase--login-102053 .card {
  width: 100%;
  max-width: 24rem;
  padding: 2.5rem 2rem;
  border-radius: 24px;
  border: 1px solid rgba(255, 255, 255, 0.18);
  background: rgba(255, 255, 255, 0.08);
  backdrop-filter: blur(18px);
  -webkit-backdrop-filter: blur(18px);
  box-shadow: 0 16px 50px rgba(0, 0, 0, 0.35), inset 0 1px 1px rgba(255, 255, 255, 0.25);
}
glassshowcase--login-102053 .brand {
  color: #c7d2fe;
  font-weight: 700;
  letter-spacing: 0.05em;
  margin-bottom: 1.5rem;
}
glassshowcase--login-102053 .title {
  color: #fff;
  font-size: 1.5rem;
  font-weight: 700;
  margin-bottom: 0.25rem;
}
glassshowcase--login-102053 .subtitle {
  color: rgba(255, 255, 255, 0.65);
  font-size: 0.875rem;
  margin-bottom: 2rem;
}
glassshowcase--login-102053 .fields {
  display: flex;
  flex-direction: column;
  gap: 1.25rem;
  margin-bottom: 1.25rem;
}
glassshowcase--login-102053 .row-between {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 1rem;
  margin-bottom: 1.75rem;
}
glassshowcase--login-102053 .submit grouptriggeraction--ml-button-standard {
  display: block;
}
glassshowcase--login-102053 .submit .glass-btn {
  width: 100%;
}
glassshowcase--login-102053 .footer {
  margin-top: 1.5rem;
  text-align: center;
  color: rgba(255, 255, 255, 0.65);
  font-size: 0.875rem;
}
`);
        // ── Estado controlado ──────────────────────────────────────────────────────
        this.email = '';
        this.password = '';
        this.remember = false;
        this.emailError = '';
        this.loading = false;
    }
    // ── Handlers ─────────────────────────────────────────────────────────────--
    onEmailInput(e) {
        this.email = e.detail.value;
        if (this.emailError)
            this.emailError = '';
    }
    onPasswordInput(e) {
        this.password = e.detail.value;
    }
    onRememberChange(e) {
        this.remember = e.detail.value;
    }
    isEmailValid() {
        return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(this.email);
    }
    onSubmit() {
        if (!this.isEmailValid()) {
            this.emailError = 'Informe um e-mail válido';
            return;
        }
        this.loading = true;
        // simula request
        setTimeout(() => {
            this.loading = false;
        }, 1500);
    }
    goToSignup() {
        // Navegação entre páginas é responsabilidade do app host (router).
        this.dispatchEvent(new CustomEvent('navigate', { bubbles: true, composed: true, detail: { to: 'signup' } }));
    }
    render() {
        return html `
      <div class="page">
        <div class="card">
          <div class="brand">◆ Aurora</div>
          <h1 class="title">Bem-vindo de volta</h1>
          <p class="subtitle">Entre para continuar</p>

          <div class="fields">
            <groupentertext--ml-floating-text-input
              name="email"
              input-type="email"
              .value=${this.email}
              .isEditing=${true}
              .error=${this.emailError}
              @input=${this.onEmailInput}
            >
              <Label>E-mail</Label>
            </groupentertext--ml-floating-text-input>

            <groupentertext--ml-floating-text-input
              name="password"
              input-type="password"
              .value=${this.password}
              .isEditing=${true}
              @input=${this.onPasswordInput}
            >
              <Label>Senha</Label>
            </groupentertext--ml-floating-text-input>
          </div>

          <div class="row-between">
            <groupenterboolean--ml-toggle-switch
              name="remember"
              .value=${this.remember}
              .isEditing=${true}
              @change=${this.onRememberChange}
            >
              <Label>Manter conectado</Label>
            </groupenterboolean--ml-toggle-switch>
            <grouptriggeraction--ml-button-standard data-variant="link" size="sm">
              <Label>Esqueci a senha</Label>
            </grouptriggeraction--ml-button-standard>
          </div>

          <div class="submit">
            <grouptriggeraction--ml-button-standard
              data-variant="primary"
              .loading=${this.loading}
              @action=${this.onSubmit}
            >
              <Label>Entrar</Label>
            </grouptriggeraction--ml-button-standard>
          </div>

          <p class="footer">
            Não tem conta?
            <grouptriggeraction--ml-button-standard data-variant="link" size="sm" @action=${this.goToSignup}>
              <Label>Criar conta</Label>
            </grouptriggeraction--ml-button-standard>
          </p>
        </div>
      </div>
    `;
    }
};
__decorate([
    state()
], GlassShowcaseLogin.prototype, "email", void 0);
__decorate([
    state()
], GlassShowcaseLogin.prototype, "password", void 0);
__decorate([
    state()
], GlassShowcaseLogin.prototype, "remember", void 0);
__decorate([
    state()
], GlassShowcaseLogin.prototype, "emailError", void 0);
__decorate([
    state()
], GlassShowcaseLogin.prototype, "loading", void 0);
GlassShowcaseLogin = __decorate([
    customElement('glassshowcase--login-102053')
], GlassShowcaseLogin);
export { GlassShowcaseLogin };
