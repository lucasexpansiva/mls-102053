var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102053_/l2/glassshowcase/demodropdown.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// GLASS SHOWCASE — DEMO DROPDOWN
// =============================================================================
// Exemplo enxuto do ml-select-dropdown (glass, mls-102054). Padrão controlado:
// .value + .isEditing + @change realimentando o @state. A página é o contrato
// de container (fundo escuro rico) — ver demodropdown.less.
import { html } from 'lit';
import { customElement, state } from 'lit/decorators.js';
import { StateLitElement } from '/_102029_/l2/stateLitElement.js';
import '/_102054_/l2/molecules/groupselectone/ml-select-dropdown';
let GlassShowcaseDemoDropdown = class GlassShowcaseDemoDropdown extends StateLitElement {
    constructor() {
        super(...arguments);
        this.country = '';
        this.team = '';
    }
    onCountry(e) {
        this.country = e.detail.value;
    }
    onTeam(e) {
        this.team = e.detail.value;
    }
    render() {
        return html `
      <div class="page">
        <div class="card">
          <div class="brand">◆ Aurora</div>
          <h1 class="title">Select Dropdown</h1>
          <p class="subtitle">Exemplo glass do <code>ml-select-dropdown</code></p>

          <div class="fields">
            <groupselectone--ml-select-dropdown
              name="country"
              searchable="true"
              .value=${this.country}
              .isEditing=${true}
              @change=${this.onCountry}
            >
              <Label>País</Label>
              <Helper>Use a busca para filtrar</Helper>
              <Item value="br">Brasil</Item>
              <Item value="us">Estados Unidos</Item>
              <Item value="pt">Portugal</Item>
              <Item value="jp">Japão</Item>
              <Item value="de">Alemanha</Item>
            </groupselectone--ml-select-dropdown>

            <groupselectone--ml-select-dropdown
              name="team"
              .value=${this.team}
              .isEditing=${true}
              @change=${this.onTeam}
            >
              <Label>Time</Label>
              <Group label="Engenharia">
                <Item value="fe">Front-end</Item>
                <Item value="be">Back-end</Item>
              </Group>
              <Group label="Produto">
                <Item value="pm">Product Manager</Item>
                <Item value="ux">UX Designer</Item>
              </Group>
            </groupselectone--ml-select-dropdown>
          </div>

          <p class="result">Selecionado — país: <strong>${this.country || '—'}</strong> · time: <strong>${this.team || '—'}</strong></p>
        </div>
      </div>
    `;
    }
};
__decorate([
    state()
], GlassShowcaseDemoDropdown.prototype, "country", void 0);
__decorate([
    state()
], GlassShowcaseDemoDropdown.prototype, "team", void 0);
GlassShowcaseDemoDropdown = __decorate([
    customElement('glassshowcase--demodropdown-102053')
], GlassShowcaseDemoDropdown);
export { GlassShowcaseDemoDropdown };
