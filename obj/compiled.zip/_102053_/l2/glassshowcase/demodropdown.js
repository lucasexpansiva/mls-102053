var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102053_/l2/glassshowcase/demodropdown.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// GLASS SHOWCASE — DEMO DROPDOWN
// =============================================================================
// Exemplo enxuto do ml-select-dropdown (glass, mls-102054). Padrão controlado:
// .value + .isEditing + @change realimentando o @state. A página é o contrato
// de container (fundo escuro rico) — ver demodropdown.less.
import { html } from 'lit';
import { customElement, state } from 'lit/decorators.js';
import { StateLitElement } from '/_102029_/l2/stateLitElement.js';
import '/_102054_/l2/molecules/groupselectone/ml-select-dropdown';
let GlassShowcaseDemoDropdown = class GlassShowcaseDemoDropdown extends StateLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`@font-face {
  font-family: 'Inter';
  font-style: normal;
  font-weight: 400;
  font-display: swap;
  src: url(https://fonts.gstatic.com/s/inter/v20/UcCO3FwrK3iLTeHuS_nVMrMxCp50SjIw2boKoduKmMEVuLyfMZg.ttf) format('truetype');
}
@font-face {
  font-family: 'Inter';
  font-style: normal;
  font-weight: 500;
  font-display: swap;
  src: url(https://fonts.gstatic.com/s/inter/v20/UcCO3FwrK3iLTeHuS_nVMrMxCp50SjIw2boKoduKmMEVuI6fMZg.ttf) format('truetype');
}
@font-face {
  font-family: 'Inter';
  font-style: normal;
  font-weight: 600;
  font-display: swap;
  src: url(https://fonts.gstatic.com/s/inter/v20/UcCO3FwrK3iLTeHuS_nVMrMxCp50SjIw2boKoduKmMEVuGKYMZg.ttf) format('truetype');
}
@font-face {
  font-family: 'Inter';
  font-style: normal;
  font-weight: 700;
  font-display: swap;
  src: url(https://fonts.gstatic.com/s/inter/v20/UcCO3FwrK3iLTeHuS_nVMrMxCp50SjIw2boKoduKmMEVuFuYMZg.ttf) format('truetype');
}
glassshowcase--demodropdown-102053 {
  display: block;
  font-family: 'Inter', system-ui, sans-serif;
}
glassshowcase--demodropdown-102053 .page {
  min-height: 100vh;
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 2rem;
  background: radial-gradient(circle at 20% 20%, #4c1d95 0%, transparent 55%), radial-gradient(circle at 80% 70%, #be185d 0%, transparent 50%), linear-gradient(135deg, #0b1220 0%, #1e1b4b 100%);
  background-attachment: fixed;
}
glassshowcase--demodropdown-102053 .card {
  width: 100%;
  max-width: 26rem;
  padding: 2.5rem 2rem;
  border-radius: 24px;
  border: 1px solid rgba(255, 255, 255, 0.18);
  background: rgba(255, 255, 255, 0.08);
  backdrop-filter: blur(18px);
  -webkit-backdrop-filter: blur(18px);
  box-shadow: 0 16px 50px rgba(0, 0, 0, 0.35), inset 0 1px 1px rgba(255, 255, 255, 0.25);
}
glassshowcase--demodropdown-102053 .brand {
  color: #c7d2fe;
  font-weight: 700;
  letter-spacing: 0.05em;
  margin-bottom: 1.5rem;
}
glassshowcase--demodropdown-102053 .title {
  color: #fff;
  font-size: 1.5rem;
  font-weight: 700;
  margin-bottom: 0.25rem;
}
glassshowcase--demodropdown-102053 .subtitle {
  color: rgba(255, 255, 255, 0.65);
  font-size: 0.875rem;
  margin-bottom: 2rem;
}
glassshowcase--demodropdown-102053 .subtitle code {
  color: #c7d2fe;
}
glassshowcase--demodropdown-102053 .fields {
  display: flex;
  flex-direction: column;
  gap: 1.25rem;
}
glassshowcase--demodropdown-102053 .result {
  margin-top: 1.75rem;
  font-size: 0.875rem;
  color: rgba(255, 255, 255, 0.75);
}
glassshowcase--demodropdown-102053 .result strong {
  color: #fff;
}
`);
        this.country = '';
        this.team = '';
    }
    onCountry(e) {
        this.country = e.detail.value;
    }
    onTeam(e) {
        this.team = e.detail.value;
    }
    render() {
        return html `
      <div class="page">
        <div class="card">
          <div class="brand">◆ Aurora</div>
          <h1 class="title">Select Dropdown</h1>
          <p class="subtitle">Exemplo glass do <code>ml-select-dropdown</code></p>

          <div class="fields">
            <groupselectone--ml-select-dropdown
              name="country"
              searchable="true"
              .value=${this.country}
              .isEditing=${true}
              @change=${this.onCountry}
            >
              <Label>País</Label>
              <Helper>Use a busca para filtrar</Helper>
              <Item value="br">Brasil</Item>
              <Item value="us">Estados Unidos</Item>
              <Item value="pt">Portugal</Item>
              <Item value="jp">Japão</Item>
              <Item value="de">Alemanha</Item>
            </groupselectone--ml-select-dropdown>

            <groupselectone--ml-select-dropdown
              name="team"
              .value=${this.team}
              .isEditing=${true}
              @change=${this.onTeam}
            >
              <Label>Time</Label>
              <Group label="Engenharia">
                <Item value="fe">Front-end</Item>
                <Item value="be">Back-end</Item>
              </Group>
              <Group label="Produto">
                <Item value="pm">Product Manager</Item>
                <Item value="ux">UX Designer</Item>
              </Group>
            </groupselectone--ml-select-dropdown>
          </div>

          <p class="result">Selecionado — país: <strong>${this.country || '—'}</strong> · time: <strong>${this.team || '—'}</strong></p>
        </div>
      </div>
    `;
    }
};
__decorate([
    state()
], GlassShowcaseDemoDropdown.prototype, "country", void 0);
__decorate([
    state()
], GlassShowcaseDemoDropdown.prototype, "team", void 0);
GlassShowcaseDemoDropdown = __decorate([
    customElement('glassshowcase--demodropdown-102053')
], GlassShowcaseDemoDropdown);
export { GlassShowcaseDemoDropdown };
