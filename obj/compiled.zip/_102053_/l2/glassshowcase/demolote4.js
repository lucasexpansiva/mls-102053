var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102053_/l2/glassshowcase/demolote4.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// GLASS SHOWCASE — DEMO LOTE 4 (navegação)
// =============================================================================
import { html } from 'lit';
import { customElement, state } from 'lit/decorators.js';
import { StateLitElement } from '/_102029_/l2/stateLitElement.js';
import '/_102054_/l2/molecules/groupnavigatesection/ml-tabs';
import '/_102054_/l2/molecules/groupnavigatesection/ml-navigate-pills';
import '/_102054_/l2/molecules/groupnavigatesection/ml-breadcrumb-trail';
import '/_102054_/l2/molecules/groupnavigatemain/ml-sidebar-nav';
let GlassShowcaseDemoLote4 = class GlassShowcaseDemoLote4 extends StateLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`@font-face {
  font-family: 'Inter';
  font-style: normal;
  font-weight: 400;
  font-display: swap;
  src: url(https://fonts.gstatic.com/s/inter/v20/UcCO3FwrK3iLTeHuS_nVMrMxCp50SjIw2boKoduKmMEVuLyfMZg.ttf) format('truetype');
}
@font-face {
  font-family: 'Inter';
  font-style: normal;
  font-weight: 500;
  font-display: swap;
  src: url(https://fonts.gstatic.com/s/inter/v20/UcCO3FwrK3iLTeHuS_nVMrMxCp50SjIw2boKoduKmMEVuI6fMZg.ttf) format('truetype');
}
@font-face {
  font-family: 'Inter';
  font-style: normal;
  font-weight: 600;
  font-display: swap;
  src: url(https://fonts.gstatic.com/s/inter/v20/UcCO3FwrK3iLTeHuS_nVMrMxCp50SjIw2boKoduKmMEVuGKYMZg.ttf) format('truetype');
}
@font-face {
  font-family: 'Inter';
  font-style: normal;
  font-weight: 700;
  font-display: swap;
  src: url(https://fonts.gstatic.com/s/inter/v20/UcCO3FwrK3iLTeHuS_nVMrMxCp50SjIw2boKoduKmMEVuFuYMZg.ttf) format('truetype');
}
glassshowcase--demolote4-102053 {
  display: block;
  font-family: 'Inter', system-ui, sans-serif;
}
glassshowcase--demolote4-102053 .page {
  min-height: 100vh;
  padding: 2.5rem 2rem;
  background: radial-gradient(circle at 15% 15%, #4c1d95 0%, transparent 55%), radial-gradient(circle at 85% 85%, #be185d 0%, transparent 50%), linear-gradient(135deg, #0b1220 0%, #1e1b4b 100%);
  background-attachment: fixed;
}
glassshowcase--demolote4-102053 .shell {
  max-width: 44rem;
  margin: 0 auto;
}
glassshowcase--demolote4-102053 .head {
  text-align: center;
  margin-bottom: 2.5rem;
}
glassshowcase--demolote4-102053 .brand {
  color: #c7d2fe;
  font-weight: 700;
  letter-spacing: 0.05em;
  margin-bottom: 0.5rem;
}
glassshowcase--demolote4-102053 .title {
  color: #fff;
  font-size: 1.75rem;
  font-weight: 700;
  margin-bottom: 0.25rem;
}
glassshowcase--demolote4-102053 .subtitle {
  color: rgba(255, 255, 255, 0.65);
  font-size: 0.875rem;
}
glassshowcase--demolote4-102053 .block {
  margin-bottom: 2rem;
}
glassshowcase--demolote4-102053 .block-title {
  color: rgba(255, 255, 255, 0.55);
  font-size: 0.75rem;
  font-weight: 600;
  text-transform: uppercase;
  letter-spacing: 0.08em;
  margin-bottom: 0.75rem;
}
glassshowcase--demolote4-102053 .sidebar-frame {
  height: 24rem;
  border-radius: 18px;
  overflow: hidden;
  border: 1px solid rgba(255, 255, 255, 0.15);
  display: flex;
}
glassshowcase--demolote4-102053 .sidebar-content {
  flex: 1;
  padding: 1.5rem;
  color: rgba(255, 255, 255, 0.85);
  background: rgba(255, 255, 255, 0.04);
}
glassshowcase--demolote4-102053 .sidebar-content strong {
  color: #fff;
}
`);
        this.tab = 'details';
        this.pill = 'overview';
        this.navItem = 'dashboard';
    }
    render() {
        return html `
      <div class="page">
        <div class="shell">
          <header class="head">
            <div class="brand">◆ Aurora</div>
            <h1 class="title">Lote 4 — Navegação</h1>
            <p class="subtitle">tabs · pills · breadcrumb · sidebar</p>
          </header>

          <section class="block">
            <h2 class="block-title">Breadcrumb</h2>
            <groupnavigatesection--ml-breadcrumb-trail value="produto">
              <Tab value="home" title="Início">Home.</Tab>
              <Tab value="catalogo" title="Catálogo">Catálogo.</Tab>
              <Tab value="eletronicos" title="Eletrônicos">Eletrônicos.</Tab>
              <Tab value="produto" title="Notebook Pro">Produto atual.</Tab>
            </groupnavigatesection--ml-breadcrumb-trail>
          </section>

          <section class="block">
            <h2 class="block-title">Pills</h2>
            <groupnavigatesection--ml-navigate-pills
              .value=${this.pill}
              @change=${(e) => {
            this.pill = e.detail.value;
        }}
            >
              <Tab value="overview" title="Visão geral">Resumo do projeto.</Tab>
              <Tab value="timeline" title="Cronograma">Marcos e entregas.</Tab>
              <Tab value="team" title="Equipe">Pessoas envolvidas.</Tab>
            </groupnavigatesection--ml-navigate-pills>
          </section>

          <section class="block">
            <h2 class="block-title">Tabs</h2>
            <groupnavigatesection--ml-tabs
              .value=${this.tab}
              @change=${(e) => {
            this.tab = e.detail.value;
        }}
            >
              <Tab value="details" title="Detalhes">Especificações do produto.</Tab>
              <Tab value="reviews" title="Avaliações">Comentários dos clientes.</Tab>
              <Tab value="shipping" title="Entrega">Prazos e custos.</Tab>
            </groupnavigatesection--ml-tabs>
          </section>

          <section class="block">
            <h2 class="block-title">Sidebar</h2>
            <div class="sidebar-frame">
              <groupnavigatemain--ml-sidebar-nav
                .value=${this.navItem}
                @change=${(e) => {
            this.navItem = e.detail.value;
        }}
              >
                <Label>Aurora</Label>
                <Item value="dashboard" icon="▦">Dashboard</Item>
                <Item value="projects" icon="▤" badge="3">Projetos</Item>
                <Group label="Workspace">
                  <Item value="tasks" icon="✓">Tarefas</Item>
                  <Item value="calendar" icon="▣">Calendário</Item>
                </Group>
                <Footer>
                  <Item value="settings" icon="⚙">Configurações</Item>
                </Footer>
              </groupnavigatemain--ml-sidebar-nav>
              <div class="sidebar-content">Selecionado: <strong>${this.navItem}</strong></div>
            </div>
          </section>
        </div>
      </div>
    `;
    }
};
__decorate([
    state()
], GlassShowcaseDemoLote4.prototype, "tab", void 0);
__decorate([
    state()
], GlassShowcaseDemoLote4.prototype, "pill", void 0);
__decorate([
    state()
], GlassShowcaseDemoLote4.prototype, "navItem", void 0);
GlassShowcaseDemoLote4 = __decorate([
    customElement('glassshowcase--demolote4-102053')
], GlassShowcaseDemoLote4);
export { GlassShowcaseDemoLote4 };
