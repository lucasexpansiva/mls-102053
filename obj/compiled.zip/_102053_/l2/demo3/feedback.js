var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102053_/l2/demo3/feedback.ts" enhancement="_102020_/l2/enhancementAura"/>
// GERADO a partir de todo/.demo-fragments/feedback.frag.ts — base comparável demo1/demo2/demo3.
import { html } from 'lit';
import { customElement, state } from 'lit/decorators.js';
import { StateLitElement } from '/_102029_/l2/stateLitElement.js';
import '/_102055_/l2/molecules/groupnotifyuser/ml-notify-banner-glass';
import '/_102055_/l2/molecules/groupnotifyuser/ml-toast-notification-glass';
import '/_102055_/l2/molecules/groupnotifyuser/ml-alert-modal-glass';
import '/_102055_/l2/molecules/groupexpandcontent/ml-accordion-glass';
import '/_102055_/l2/molecules/groupexpandcontent/ml-collapsible-panel-glass';
import '/_102055_/l2/molecules/groupexpandcontent/ml-reveal-overlay-glass';
import '/_102055_/l2/molecules/grouprateitem/ml-star-rating-glass';
import '/_102055_/l2/molecules/grouprateitem/ml-emoji-mood-scale-glass';
let Demo3Feedback = class Demo3Feedback extends StateLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`demo3--feedback-102053 {
  display: block;
  font-family: 'Inter', system-ui, sans-serif;
}
demo3--feedback-102053 .page {
  min-height: 100vh;
  padding: 2.5rem 2rem;
}
demo3--feedback-102053 .shell {
  max-width: 64rem;
  margin: 0 auto;
}
demo3--feedback-102053 .head {
  text-align: center;
  margin-bottom: 2.5rem;
}
demo3--feedback-102053 .brand {
  font-weight: 700;
  letter-spacing: 0.05em;
  margin-bottom: 0.5rem;
}
demo3--feedback-102053 .title {
  font-size: 1.625rem;
  font-weight: 700;
  margin-bottom: 0.25rem;
}
demo3--feedback-102053 .subtitle {
  font-size: 0.8125rem;
}
demo3--feedback-102053 .block {
  margin-bottom: 2rem;
  border-radius: 16px;
  padding: 1.5rem;
}
demo3--feedback-102053 .block-title {
  font-size: 0.75rem;
  font-weight: 600;
  text-transform: uppercase;
  letter-spacing: 0.08em;
  margin-bottom: 0.75rem;
}
demo3--feedback-102053 .grid {
  display: grid;
  grid-template-columns: repeat(2, minmax(0, 1fr));
  gap: 1.25rem;
  align-items: start;
}
demo3--feedback-102053 .page {
  background: radial-gradient(circle at 15% 15%, #4c1d95 0%, transparent 55%), radial-gradient(circle at 85% 85%, #be185d 0%, transparent 50%), linear-gradient(135deg, #0b1220 0%, #1e1b4b 100%);
  background-attachment: fixed;
}
demo3--feedback-102053 .brand {
  color: #c7d2fe;
}
demo3--feedback-102053 .title {
  color: #ffffff;
}
demo3--feedback-102053 .subtitle {
  color: rgba(255, 255, 255, 0.65);
}
demo3--feedback-102053 .block {
  background: rgba(255, 255, 255, 0.05);
  border: 1px solid rgba(255, 255, 255, 0.12);
  backdrop-filter: blur(6px);
  -webkit-backdrop-filter: blur(6px);
}
demo3--feedback-102053 .block-title {
  color: rgba(255, 255, 255, 0.55);
}
`);
        this.stars = 3;
        this.mood = 4;
        this.modalOpen = false;
    }
    upd(key) {
        return (e) => {
            this[key] = e.detail?.value;
        };
    }
    render() {
        return html `
      <div class="page">
        <div class="shell">
          <header class="head">
            <div class="brand">◆ collab · 102055</div>
            <h1 class="title">Feedback & Conteúdo — glass por herança (102055)</h1>
            <p class="subtitle">banner · toast · modal · accordion · collapsible · reveal · rating</p>
          </header>

          <section class="block">
            <h2 class="block-title">groupNotifyUser — banner / toast / modal</h2>
            <div class="grid">
              <groupnotifyuser--ml-notify-banner-glass type="success" visible="true">
                <Title>Tudo certo</Title>
                <Message>As alterações foram salvas com sucesso.</Message>
              </groupnotifyuser--ml-notify-banner-glass>
              <groupnotifyuser--ml-toast-notification-glass type="info" visible="true">
                <Title>Atualização disponível</Title>
                <Message>Uma nova versão está pronta.</Message>
              </groupnotifyuser--ml-toast-notification-glass>
              <div>
                <button type="button" @click=${() => { this.modalOpen = true; }}>Abrir modal</button>
                <groupnotifyuser--ml-alert-modal-glass .visible=${this.modalOpen} @close=${() => { this.modalOpen = false; }}>
                  <Title>Atenção</Title>
                  <Message>Deseja confirmar esta ação?</Message>
                  <Action>
                    <button type="button" @click=${() => { this.modalOpen = false; }}>Entendi</button>
                  </Action>
                </groupnotifyuser--ml-alert-modal-glass>
              </div>
            </div>
          </section>

          <section class="block">
            <h2 class="block-title">groupExpandContent — accordion / collapsible / reveal</h2>
            <div class="grid">
              <groupexpandcontent--ml-accordion-glass multiple="true">
                <Label>Detalhes do projeto</Label>
                <Section title="Visão geral" expanded>Escopo do projeto e resultados esperados.</Section>
                <Section title="Cronograma">Entregas toda sexta-feira.</Section>
                <Section title="Riscos">Acompanhar atrasos de fornecedores.</Section>
              </groupexpandcontent--ml-accordion-glass>
              <groupexpandcontent--ml-collapsible-panel-glass>
                <Label>Perguntas frequentes</Label>
                <Section title="Como começar?" subtitle="Primeiros passos" icon="🚀" expanded>Crie a conta e siga o onboarding.</Section>
                <Section title="Posso cancelar?" subtitle="Assinatura">Sim, a qualquer momento.</Section>
              </groupexpandcontent--ml-collapsible-panel-glass>
              <groupexpandcontent--ml-reveal-overlay-glass multiple="true">
                <Label>Conteúdo oculto até revelar</Label>
                <Section title="Chave de API">sk-live-9f8a7b6c5d4e3f2a1b0c</Section>
              </groupexpandcontent--ml-reveal-overlay-glass>
            </div>
          </section>

          <section class="block">
            <h2 class="block-title">groupRateItem — star-rating / emoji-mood-scale</h2>
            <div class="grid">
              <grouprateitem--ml-star-rating-glass .value=${this.stars} min="1" max="5" @change=${this.upd('stars')}>
                <Label>Avaliação (${this.stars} ★)</Label>
                <Helper>Clique ou use as setas</Helper>
              </grouprateitem--ml-star-rating-glass>
              <grouprateitem--ml-emoji-mood-scale-glass .value=${this.mood} @change=${this.upd('mood')}>
                <Label>Como foi sua experiência? (${this.mood})</Label>
                <Item value="1">😡</Item>
                <Item value="2">🙁</Item>
                <Item value="3">😐</Item>
                <Item value="4">🙂</Item>
                <Item value="5">😍</Item>
              </grouprateitem--ml-emoji-mood-scale-glass>
            </div>
          </section>
        </div>
      </div>
    `;
    }
};
__decorate([
    state()
], Demo3Feedback.prototype, "stars", void 0);
__decorate([
    state()
], Demo3Feedback.prototype, "mood", void 0);
__decorate([
    state()
], Demo3Feedback.prototype, "modalOpen", void 0);
Demo3Feedback = __decorate([
    customElement('demo3--feedback-102053')
], Demo3Feedback);
export { Demo3Feedback };
