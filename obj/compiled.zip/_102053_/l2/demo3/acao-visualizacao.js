var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102053_/l2/demo3/acao-visualizacao.ts" enhancement="_102020_/l2/enhancementAura"/>
// GERADO a partir de todo/.demo-fragments/acao-visualizacao.frag.ts — base comparável demo1/demo2/demo3.
import { html } from 'lit';
import { customElement } from 'lit/decorators.js';
import { StateLitElement } from '/_102029_/l2/stateLitElement.js';
import '/_102055_/l2/molecules/grouptriggeraction/ml-button-standard-glass';
import '/_102055_/l2/molecules/grouptriggeraction/ml-icon-button-glass';
import '/_102055_/l2/molecules/grouptriggeraction/ml-split-button-glass';
import '/_102055_/l2/molecules/groupshowprogress/ml-linear-progress-glass';
import '/_102055_/l2/molecules/groupshowprogress/ml-circular-progress-glass';
import '/_102055_/l2/molecules/groupviewcard/ml-profile-card-glass';
import '/_102055_/l2/molecules/groupviewcard/ml-vertical-card-glass';
import '/_102055_/l2/molecules/groupviewmetric/ml-metric-card-glass';
import '/_102055_/l2/molecules/groupviewmetric/ml-metric-big-number-glass';
let Demo3AcaoVisualizacao = class Demo3AcaoVisualizacao extends StateLitElement {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(`demo3--acao-visualizacao-102053 {
  display: block;
  font-family: 'Inter', system-ui, sans-serif;
}
demo3--acao-visualizacao-102053 .page {
  min-height: 100vh;
  padding: 2.5rem 2rem;
}
demo3--acao-visualizacao-102053 .shell {
  max-width: 64rem;
  margin: 0 auto;
}
demo3--acao-visualizacao-102053 .head {
  text-align: center;
  margin-bottom: 2.5rem;
}
demo3--acao-visualizacao-102053 .brand {
  font-weight: 700;
  letter-spacing: 0.05em;
  margin-bottom: 0.5rem;
}
demo3--acao-visualizacao-102053 .title {
  font-size: 1.625rem;
  font-weight: 700;
  margin-bottom: 0.25rem;
}
demo3--acao-visualizacao-102053 .subtitle {
  font-size: 0.8125rem;
}
demo3--acao-visualizacao-102053 .block {
  margin-bottom: 2rem;
  border-radius: 16px;
  padding: 1.5rem;
}
demo3--acao-visualizacao-102053 .block-title {
  font-size: 0.75rem;
  font-weight: 600;
  text-transform: uppercase;
  letter-spacing: 0.08em;
  margin-bottom: 0.75rem;
}
demo3--acao-visualizacao-102053 .grid {
  display: grid;
  grid-template-columns: repeat(2, minmax(0, 1fr));
  gap: 1.25rem;
  align-items: start;
}
demo3--acao-visualizacao-102053 .page {
  background: radial-gradient(circle at 15% 15%, #4c1d95 0%, transparent 55%), radial-gradient(circle at 85% 85%, #be185d 0%, transparent 50%), linear-gradient(135deg, #0b1220 0%, #1e1b4b 100%);
  background-attachment: fixed;
}
demo3--acao-visualizacao-102053 .brand {
  color: #c7d2fe;
}
demo3--acao-visualizacao-102053 .title {
  color: #ffffff;
}
demo3--acao-visualizacao-102053 .subtitle {
  color: rgba(255, 255, 255, 0.65);
}
demo3--acao-visualizacao-102053 .block {
  background: rgba(255, 255, 255, 0.05);
  border: 1px solid rgba(255, 255, 255, 0.12);
  backdrop-filter: blur(6px);
  -webkit-backdrop-filter: blur(6px);
}
demo3--acao-visualizacao-102053 .block-title {
  color: rgba(255, 255, 255, 0.55);
}
`);
    }
    render() {
        return html `
      <div class="page">
        <div class="shell">
          <header class="head">
            <div class="brand">◆ collab · 102055</div>
            <h1 class="title">Ação & Visualização — glass por herança (102055)</h1>
            <p class="subtitle">button · icon · split · progress · cards · metrics</p>
          </header>

          <section class="block">
            <h2 class="block-title">groupTriggerAction — button / icon / split</h2>
            <div class="grid">
              <grouptriggeraction--ml-button-standard-glass data-variant="primary"><Label>Primary</Label></grouptriggeraction--ml-button-standard-glass>
              <grouptriggeraction--ml-button-standard-glass data-variant="secondary"><Label>Secondary</Label></grouptriggeraction--ml-button-standard-glass>
              <grouptriggeraction--ml-button-standard-glass data-variant="danger"><Label>Danger</Label></grouptriggeraction--ml-button-standard-glass>
              <grouptriggeraction--ml-icon-button-glass data-variant="primary"><Icon>★</Icon><Label>Favoritar</Label></grouptriggeraction--ml-icon-button-glass>
              <grouptriggeraction--ml-split-button-glass data-variant="primary"><Label>Salvar</Label></grouptriggeraction--ml-split-button-glass>
            </div>
          </section>

          <section class="block">
            <h2 class="block-title">groupShowProgress — linear / circular</h2>
            <div class="grid">
              <groupshowprogress--ml-linear-progress-glass value="72" show-value label="Upload"></groupshowprogress--ml-linear-progress-glass>
              <groupshowprogress--ml-linear-progress-glass value="40" variant="success" size="sm" show-value></groupshowprogress--ml-linear-progress-glass>
              <groupshowprogress--ml-circular-progress-glass value="68" size="lg" show-value></groupshowprogress--ml-circular-progress-glass>
              <groupshowprogress--ml-circular-progress-glass value="33" size="lg" show-value></groupshowprogress--ml-circular-progress-glass>
            </div>
          </section>

          <section class="block">
            <h2 class="block-title">groupViewCard — profile / vertical</h2>
            <div class="grid">
              <groupviewcard--ml-profile-card-glass clickable="true">
                <CardTitle>Ada Lovelace</CardTitle>
                <CardDescription>Engenheira de software</CardDescription>
                <CardContent>Card de perfil clicável.</CardContent>
              </groupviewcard--ml-profile-card-glass>
              <groupviewcard--ml-vertical-card-glass>
                <CardTitle>Plano Pro</CardTitle>
                <CardDescription>R$ 49/mês</CardDescription>
                <CardContent>Card vertical com ação.</CardContent>
                <CardAction>
                  <grouptriggeraction--ml-button-standard-glass data-variant="primary"><Label>Assinar</Label></grouptriggeraction--ml-button-standard-glass>
                </CardAction>
              </groupviewcard--ml-vertical-card-glass>
            </div>
          </section>

          <section class="block">
            <h2 class="block-title">groupViewMetric — metric-card / big-number</h2>
            <div class="grid">
              <groupviewmetric--ml-metric-card-glass>
                <Icon>📈</Icon>
                <Label>Receita mensal</Label>
                <Value>R$ 128.430</Value>
                <Trend direction="up">+12,5%</Trend>
                <Helper>vs. mês anterior</Helper>
              </groupviewmetric--ml-metric-card-glass>
              <groupviewmetric--ml-metric-card-glass>
                <Icon>👥</Icon>
                <Label>Churn</Label>
                <Value>3,2%</Value>
                <Trend direction="down">-0,8%</Trend>
                <Helper>últimos 30 dias</Helper>
              </groupviewmetric--ml-metric-card-glass>
              <groupviewmetric--ml-metric-big-number-glass>
                <Label>Usuários ativos</Label>
                <Value>24.918</Value>
                <Trend direction="up">▲ 8,1%</Trend>
                <Helper>Atualizado há 5 min</Helper>
              </groupviewmetric--ml-metric-big-number-glass>
            </div>
          </section>
        </div>
      </div>
    `;
    }
};
Demo3AcaoVisualizacao = __decorate([
    customElement('demo3--acao-visualizacao-102053')
], Demo3AcaoVisualizacao);
export { Demo3AcaoVisualizacao };
