/// <mls fileReference="_102053_/l2/molecules/groupenternumberinterval/ml-number-range-slider.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// ML-NUMBER-RANGE-SLIDER MOLECULE
// =============================================================================
// Skill Group: groupEnterNumberInterval
// This molecule does NOT contain business logic.
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement, state } from 'lit/decorators.js';
import { unsafeHTML } from 'lit/directives/unsafe-html.js';
import { propertyDataSource } from '/_102029_/l2/collabDecorators.js';
import { MoleculeAuraElement } from '/_102033_/l2/moleculeBase.js';
import { cn } from '/_102033_/l2/cn.js';
/// **collab_i18n_start**
const message_en = {
    placeholder: '—',
    startLabel: 'Start value',
    endLabel: 'End value',
    separator: '–',
};
const messages = {
    en: message_en,
};
/// **collab_i18n_end**
let MlNumberRangeSliderMolecule = class MlNumberRangeSliderMolecule extends MoleculeAuraElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`groupenternumberinterval--ml-number-range-slider .ml-range-container > div:first-child {
  height: 16px;
}
groupenternumberinterval--ml-number-range-slider .ml-range-container-error .ml-range-track {
  border-color: var(--ml-outline-error, #ef4444);
}
groupenternumberinterval--ml-number-range-slider .ml-range-container-error .ml-range-input::-webkit-slider-thumb {
  border-color: var(--ml-outline-error, #ef4444);
}
groupenternumberinterval--ml-number-range-slider .ml-range-container-error .ml-range-input::-moz-range-thumb {
  border-color: var(--ml-outline-error, #ef4444);
}
groupenternumberinterval--ml-number-range-slider .ml-range-container-loading .ml-range-track,
groupenternumberinterval--ml-number-range-slider .ml-range-container-loading .ml-range-highlight,
groupenternumberinterval--ml-number-range-slider .ml-range-container-loading .ml-range-input {
  opacity: 0.5;
}
groupenternumberinterval--ml-number-range-slider .ml-range-container-readonly .ml-range-input {
  cursor: default;
}
groupenternumberinterval--ml-number-range-slider .ml-range-track {
  position: absolute;
  top: 50%;
  left: 0;
  right: 0;
  height: 6px;
  transform: translateY(-50%);
  background: var(--ml-surface-dim, #f5f5f5);
  border: var(--ml-border-width, 1px) var(--ml-border-style, solid) var(--ml-outline-variant, #e2e8f0);
  border-radius: var(--ml-radius-full, 9999px);
  pointer-events: none;
  z-index: 0;
}
groupenternumberinterval--ml-number-range-slider .ml-range-highlight {
  position: absolute;
  top: 50%;
  height: 6px;
  transform: translateY(-50%);
  background: var(--ml-primary, #3b82f6);
  border-radius: var(--ml-radius-full, 9999px);
  pointer-events: none;
  z-index: 0;
}
groupenternumberinterval--ml-number-range-slider .ml-range-input {
  -webkit-appearance: none;
  appearance: none;
  background: transparent;
  cursor: pointer;
  height: 16px;
  margin: 0;
}
groupenternumberinterval--ml-number-range-slider .ml-range-input::-webkit-slider-runnable-track {
  -webkit-appearance: none;
  height: 6px;
  background: transparent;
  border: none;
  box-shadow: none;
  pointer-events: none;
}
groupenternumberinterval--ml-number-range-slider .ml-range-input::-moz-range-track {
  height: 6px;
  background: transparent;
  border: none;
  box-shadow: none;
  pointer-events: none;
}
groupenternumberinterval--ml-number-range-slider .ml-range-input::-webkit-slider-thumb {
  -webkit-appearance: none;
  height: 16px;
  width: 16px;
  margin-top: -5px;
  background: var(--ml-primary, #3b82f6);
  border: 2px solid var(--ml-surface, #ffffff);
  border-radius: var(--ml-radius-full, 9999px);
  box-shadow: var(--ml-shadow-1, 0 1px 3px rgba(0, 0, 0, 0.1));
  transition: transform var(--ml-transition, 200ms ease), box-shadow var(--ml-transition, 200ms ease);
}
groupenternumberinterval--ml-number-range-slider .ml-range-input::-moz-range-thumb {
  height: 16px;
  width: 16px;
  background: var(--ml-primary, #3b82f6);
  border: 2px solid var(--ml-surface, #ffffff);
  border-radius: var(--ml-radius-full, 9999px);
  box-shadow: var(--ml-shadow-1, 0 1px 3px rgba(0, 0, 0, 0.1));
  transition: transform var(--ml-transition, 200ms ease), box-shadow var(--ml-transition, 200ms ease);
}
groupenternumberinterval--ml-number-range-slider .ml-range-input:focus {
  outline: none;
}
groupenternumberinterval--ml-number-range-slider .ml-range-input:focus::-webkit-slider-thumb {
  box-shadow: 0 0 0 var(--ml-focus-ring-width, 2px) var(--ml-focus-ring-color, rgba(59, 130, 246, 0.4));
}
groupenternumberinterval--ml-number-range-slider .ml-range-input:focus::-moz-range-thumb {
  box-shadow: 0 0 0 var(--ml-focus-ring-width, 2px) var(--ml-focus-ring-color, rgba(59, 130, 246, 0.4));
}
groupenternumberinterval--ml-number-range-slider .ml-range-input:hover::-webkit-slider-thumb {
  transform: scale(1.1);
}
groupenternumberinterval--ml-number-range-slider .ml-range-input:hover::-moz-range-thumb {
  transform: scale(1.1);
}
groupenternumberinterval--ml-number-range-slider .ml-range-input:active::-webkit-slider-thumb {
  transform: scale(1.2);
  cursor: grabbing;
}
groupenternumberinterval--ml-number-range-slider .ml-range-input:active::-moz-range-thumb {
  transform: scale(1.2);
  cursor: grabbing;
}
groupenternumberinterval--ml-number-range-slider .ml-range-input:disabled,
groupenternumberinterval--ml-number-range-slider .ml-range-input[disabled] {
  cursor: not-allowed;
}
groupenternumberinterval--ml-number-range-slider .ml-range-input:disabled::-webkit-slider-thumb,
groupenternumberinterval--ml-number-range-slider .ml-range-input[disabled]::-webkit-slider-thumb {
  background: var(--ml-outline-variant, #e2e8f0);
}
groupenternumberinterval--ml-number-range-slider .ml-range-input:disabled::-moz-range-thumb,
groupenternumberinterval--ml-number-range-slider .ml-range-input[disabled]::-moz-range-thumb {
  background: var(--ml-outline-variant, #e2e8f0);
}
groupenternumberinterval--ml-number-range-slider .ml-range-input-start {
  z-index: 2;
}
groupenternumberinterval--ml-number-range-slider .ml-range-input-start:hover {
  z-index: 3;
}
groupenternumberinterval--ml-number-range-slider .ml-range-input-end {
  z-index: 1;
}
groupenternumberinterval--ml-number-range-slider .ml-range-input-end:hover {
  z-index: 3;
}
groupenternumberinterval--ml-number-range-slider .ml-range-input-active {
  z-index: 4;
}
groupenternumberinterval--ml-number-range-slider .ml-label {
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
  font-weight: var(--ml-font-weight-medium, 500);
  color: var(--ml-on-surface, #1c1b1f);
}
groupenternumberinterval--ml-number-range-slider .ml-error-text {
  color: var(--ml-error, #ef4444);
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
}
groupenternumberinterval--ml-number-range-slider .ml-helper {
  color: var(--ml-on-surface-faint, #79747e);
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
}
groupenternumberinterval--ml-number-range-slider .ml-text {
  color: var(--ml-on-surface, #1c1b1f);
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
}
groupenternumberinterval--ml-number-range-slider .ml-text-muted {
  color: var(--ml-on-surface-muted, #49454f);
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
}
groupenternumberinterval--ml-number-range-slider .ml-text-faint {
  color: var(--ml-on-surface-faint, #79747e);
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
}
groupenternumberinterval--ml-number-range-slider .ml-range-affix {
  color: var(--ml-on-surface-muted, #49454f);
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
  font-size: 0.875em;
}
groupenternumberinterval--ml-number-range-slider .ml-range-value {
  font-variant-numeric: tabular-nums;
  white-space: nowrap;
}
groupenternumberinterval--ml-number-range-slider .ml-range-values {
  font-variant-numeric: tabular-nums;
}
groupenternumberinterval--ml-number-range-slider .ml-range-separator {
  user-select: none;
}
groupenternumberinterval--ml-number-range-slider .ml-spinner {
  display: inline-block;
  width: 16px;
  height: 16px;
  border: 2px solid var(--ml-outline-variant, #e2e8f0);
  border-top-color: var(--ml-primary, #3b82f6);
  border-radius: var(--ml-radius-full, 9999px);
  animation: ml-range-slider-spin 1s linear infinite;
}
groupenternumberinterval--ml-number-range-slider .ml-range-spinner {
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  z-index: 3;
  pointer-events: none;
}
@keyframes ml-range-slider-spin {
  to {
    transform: rotate(360deg);
  }
}
groupenternumberinterval--ml-number-range-slider .ml-disabled {
  opacity: var(--ml-disabled-opacity, 0.5);
  cursor: not-allowed;
  pointer-events: none;
}
`);
        this.msg = messages.en;
        // ===========================================================================
        // SLOT TAGS
        // ===========================================================================
        this.slotTags = ['Label', 'LabelStart', 'LabelEnd', 'Helper', 'Prefix', 'Suffix'];
        // ===========================================================================
        // PROPERTIES — From Contract
        // ===========================================================================
        this.startValue = null;
        this.endValue = null;
        this.error = '';
        this.name = '';
        this.min = null;
        this.max = null;
        this.step = 1;
        this.decimals = 0;
        this.locale = '';
        this.placeholder = '';
        this.minGap = 0;
        this.maxGap = 0;
        this.isEditing = true;
        this.disabled = false;
        this.readonly = false;
        this.required = false;
        this.loading = false;
        // ===========================================================================
        // INTERNAL STATE
        // ===========================================================================
        this.activeHandle = null;
        // Which handle sits on top when idle — chosen by pointer proximity so both thumbs are reachable
        this.topHandle = 'end';
        this.uid = `ml-range-${Math.random().toString(36).slice(2, 9)}`;
    }
    // ===========================================================================
    // EVENT HANDLERS
    // ===========================================================================
    handleStartInput(e) {
        e.stopPropagation();
        if (this.isBlocked())
            return;
        this.activeHandle = 'start';
        const input = e.target;
        const { min, max } = this.getRangeBounds();
        const raw = Number(input.value);
        const start = this.normalizeValue(raw, min, max);
        const endRaw = this.endValue ?? start;
        const end = this.normalizeValue(endRaw, min, max);
        const pair = this.clampPair(start, end, 'start', min, max);
        this.startValue = pair.start;
        this.endValue = pair.end;
        this.dispatchInputEvent();
    }
    handleEndInput(e) {
        e.stopPropagation();
        if (this.isBlocked())
            return;
        this.activeHandle = 'end';
        const input = e.target;
        const { min, max } = this.getRangeBounds();
        const raw = Number(input.value);
        const end = this.normalizeValue(raw, min, max);
        const startRaw = this.startValue ?? end;
        const start = this.normalizeValue(startRaw, min, max);
        const pair = this.clampPair(start, end, 'end', min, max);
        this.startValue = pair.start;
        this.endValue = pair.end;
        this.dispatchInputEvent();
    }
    handleStartChange(e) {
        e.stopPropagation();
        if (this.isBlocked())
            return;
        this.activeHandle = null;
        this.dispatchChangeEvent();
    }
    handleEndChange(e) {
        e.stopPropagation();
        if (this.isBlocked())
            return;
        this.activeHandle = null;
        this.dispatchChangeEvent();
    }
    handleFocus() {
        if (this.isBlocked())
            return;
        this.dispatchEvent(new CustomEvent('focus', { bubbles: true, composed: true }));
    }
    handleBlur() {
        if (this.isBlocked())
            return;
        this.activeHandle = null;
        this.dispatchEvent(new CustomEvent('blur', { bubbles: true, composed: true }));
        this.dispatchChangeEvent();
    }
    /**
     * Dual overlapping <input type="range"> share the full track hit-area.
     * Raise the handle closest to the pointer so start/end can be grabbed independently.
     */
    handleSliderPointerMove(e) {
        if (this.isBlocked())
            return;
        // Keep the dragging handle on top for the whole gesture
        if (this.activeHandle)
            return;
        const target = e.currentTarget;
        const rect = target.getBoundingClientRect();
        if (rect.width <= 0)
            return;
        const { min, max } = this.getRangeBounds();
        const startValue = this.startValue ?? min;
        const endValue = this.endValue ?? max;
        const startPercent = this.getPercent(startValue, min, max);
        const endPercent = this.getPercent(endValue, min, max);
        const pointerPercent = ((e.clientX - rect.left) / rect.width) * 100;
        const distStart = Math.abs(pointerPercent - startPercent);
        const distEnd = Math.abs(pointerPercent - endPercent);
        let next;
        if (distStart < distEnd) {
            next = 'start';
        }
        else if (distEnd < distStart) {
            next = 'end';
        }
        else {
            // Equidistant / overlapping thumbs: side of the thumb decides which one to grab
            next = pointerPercent < startPercent ? 'start' : 'end';
        }
        if (this.topHandle !== next) {
            this.topHandle = next;
        }
    }
    // Resolve top handle before the click/touch hits an input (no prior mousemove on touch)
    handleSliderPointerDown(e) {
        this.handleSliderPointerMove(e);
    }
    dispatchInputEvent() {
        this.dispatchEvent(new CustomEvent('input', {
            bubbles: true,
            composed: true,
            detail: { startValue: this.startValue, endValue: this.endValue },
        }));
    }
    dispatchChangeEvent() {
        this.dispatchEvent(new CustomEvent('change', {
            bubbles: true,
            composed: true,
            detail: { startValue: this.startValue, endValue: this.endValue },
        }));
    }
    // ===========================================================================
    // HELPERS
    // ===========================================================================
    isBlocked() {
        return this.disabled || this.readonly || this.loading;
    }
    getPlaceholderText() {
        return this.placeholder || this.msg.placeholder;
    }
    getRangeBounds() {
        let min = this.min ?? null;
        let max = this.max ?? null;
        const candidates = [this.startValue, this.endValue]
            .filter((v) => v !== null && v !== undefined);
        if (min === null) {
            min = candidates.length > 0 ? Math.min(...candidates) : 0;
        }
        if (max === null) {
            max = candidates.length > 0 ? Math.max(...candidates) : 100;
        }
        if (min === max) {
            max = min + 1;
        }
        if (min > max) {
            const temp = min;
            min = max;
            max = temp;
        }
        return { min, max };
    }
    clampToBounds(value, min, max) {
        let next = value;
        next = Math.max(next, min);
        next = Math.min(next, max);
        return next;
    }
    applyStep(value, min) {
        const step = this.step ?? 1;
        if (step <= 0)
            return value;
        const steps = Math.round((value - min) / step);
        return min + steps * step;
    }
    roundToDecimals(value) {
        const decimals = Math.max(0, this.decimals ?? 0);
        const factor = Math.pow(10, decimals);
        return Math.round(value * factor) / factor;
    }
    normalizeValue(value, min, max) {
        let next = value;
        next = this.applyStep(next, min);
        next = this.roundToDecimals(next);
        next = this.clampToBounds(next, min, max);
        return next;
    }
    clampPair(start, end, active, min, max) {
        let s = this.clampToBounds(start, min, max);
        let e = this.clampToBounds(end, min, max);
        if (s > e) {
            if (active === 'start')
                e = s;
            else
                s = e;
        }
        const minGap = Math.max(0, this.minGap ?? 0);
        const maxGap = Math.max(0, this.maxGap ?? 0);
        if (minGap > 0 && e - s < minGap) {
            if (active === 'start')
                e = s + minGap;
            else
                s = e - minGap;
        }
        if (maxGap > 0 && e - s > maxGap) {
            if (active === 'start')
                e = s + maxGap;
            else
                s = e - maxGap;
        }
        s = this.clampToBounds(s, min, max);
        e = this.clampToBounds(e, min, max);
        if (s > e) {
            if (active === 'start')
                e = s;
            else
                s = e;
        }
        return { start: s, end: e };
    }
    getPercent(value, min, max) {
        if (max === min)
            return 0;
        return ((value - min) / (max - min)) * 100;
    }
    formatNumber(value) {
        if (value === null || value === undefined || Number.isNaN(value))
            return '';
        const decimals = Math.max(0, this.decimals ?? 0);
        const locale = this.locale || undefined;
        try {
            return new Intl.NumberFormat(locale, {
                minimumFractionDigits: decimals,
                maximumFractionDigits: decimals,
            }).format(value);
        }
        catch {
            return value.toFixed(decimals);
        }
    }
    getContainerClasses() {
        const hasError = this.hasError();
        return [
            'relative w-full',
            'ml-range-container',
            hasError ? 'ml-range-container-error' : '',
            this.loading ? 'ml-range-container-loading' : '',
            this.disabled ? 'ml-disabled' : '',
            this.readonly ? 'ml-range-container-readonly' : '',
        ].filter(Boolean).join(' ');
    }
    getInputClasses(handle) {
        return [
            'absolute left-0 top-0 w-full',
            'ml-range-input',
            handle === 'start' ? 'ml-range-input-start' : 'ml-range-input-end',
            this.activeHandle === handle ? 'ml-range-input-active' : '',
        ].filter(Boolean).join(' ');
    }
    getInputStyle(handle) {
        // Active handle always wins; otherwise the proximity-selected topHandle
        const isOnTop = this.activeHandle === handle ||
            (this.activeHandle === null && this.topHandle === handle);
        return `z-index: ${isOnTop ? 3 : 1};`;
    }
    hasError() {
        return Boolean(this.error && String(this.error).trim().length > 0);
    }
    renderLabel() {
        if (!this.hasSlot('Label'))
            return html ``;
        return html `
      <div
        id="${this.uid}-label"
        class="${cn('mb-2 text-sm ml-label', this.getSlotClass('Label'))}"
      >
        ${unsafeHTML(this.getSlotContent('Label'))}
      </div>
    `;
    }
    renderHelperOrError() {
        if (this.hasError()) {
            return html `
        <p id="${this.uid}-error" class="${cn('mt-2 text-xs ml-error-text')}">
          ${unsafeHTML(String(this.error))}
        </p>
      `;
        }
        if (this.hasSlot('Helper')) {
            return html `
        <p id="${this.uid}-helper" class="${cn('mt-2 text-xs ml-helper', this.getSlotClass('Helper'))}">
          ${unsafeHTML(this.getSlotContent('Helper'))}
        </p>
      `;
        }
        return html ``;
    }
    renderAffix(tag) {
        if (!this.hasSlot(tag))
            return html ``;
        return html `
      <span class="${cn('ml-range-affix', this.getSlotClass(tag))}">
        ${unsafeHTML(this.getSlotContent(tag))}
      </span>
    `;
    }
    renderValueDisplay(value) {
        const text = value === null || value === undefined ? this.getPlaceholderText() : this.formatNumber(value);
        return html `
      <span class="flex items-center gap-1 ml-range-value">
        ${this.renderAffix('Prefix')}
        <span class="ml-text">${text}</span>
        ${this.renderAffix('Suffix')}
      </span>
    `;
    }
    renderValueLabels() {
        const startLabelId = `${this.uid}-label-start`;
        const endLabelId = `${this.uid}-label-end`;
        const hasStartLabel = this.hasSlot('LabelStart');
        const hasEndLabel = this.hasSlot('LabelEnd');
        return html `
      <div class="mt-2 flex items-center justify-between text-xs ml-range-labels">
        <div id="${startLabelId}" class="${cn('ml-text-muted', this.getSlotClass('LabelStart'))}">
          ${hasStartLabel ? unsafeHTML(this.getSlotContent('LabelStart')) : this.msg.startLabel}
        </div>
        <div id="${endLabelId}" class="${cn('ml-text-muted', this.getSlotClass('LabelEnd'))}">
          ${hasEndLabel ? unsafeHTML(this.getSlotContent('LabelEnd')) : this.msg.endLabel}
        </div>
      </div>
    `;
    }
    renderViewMode() {
        const placeholder = this.getPlaceholderText();
        const startEmpty = this.startValue === null || this.startValue === undefined;
        const endEmpty = this.endValue === null || this.endValue === undefined;
        return html `
      <div class="${cn('w-full', this.cssClass)}">
        ${this.renderLabel()}
        <div class="ml-range-view">
          ${startEmpty && endEmpty ? html `
            <span class="ml-text-faint">${placeholder}</span>
          ` : html `
            <div class="flex items-center gap-2 ml-text">
              ${this.renderValueDisplay(this.startValue)}
              <span class="ml-range-separator ml-text-muted">${this.msg.separator}</span>
              ${this.renderValueDisplay(this.endValue)}
            </div>
          `}
        </div>
      </div>
    `;
    }
    renderEditMode() {
        const { min, max } = this.getRangeBounds();
        const startValue = this.startValue ?? min;
        const endValue = this.endValue ?? max;
        const startPercent = this.getPercent(startValue, min, max);
        const endPercent = this.getPercent(endValue, min, max);
        const highlightLeft = Math.min(startPercent, endPercent);
        const highlightWidth = Math.max(0, Math.abs(endPercent - startPercent));
        const isBlocked = this.isBlocked();
        const hasError = this.hasError();
        const startLabelId = `${this.uid}-label-start`;
        const endLabelId = `${this.uid}-label-end`;
        return html `
      <div class="${cn('w-full', this.cssClass)}">
        ${this.renderLabel()}

        <div class="${this.getContainerClasses()}">
          <div
            class="relative w-full"
            @pointerdown="${this.handleSliderPointerDown}"
            @pointermove="${this.handleSliderPointerMove}"
          >
            <div class="ml-range-track"></div>
            <div
              class="ml-range-highlight"
              style="left: ${highlightLeft}%; width: ${highlightWidth}%;"
            ></div>

            <input
              class="${this.getInputClasses('start')}"
              style="${this.getInputStyle('start')}"
              type="range"
              min="${min}"
              max="${max}"
              step="${this.step ?? 1}"
              .value="${String(startValue)}"
              ?disabled="${isBlocked}"
              aria-labelledby="${startLabelId}"
              aria-valuemin="${min}"
              aria-valuemax="${max}"
              aria-valuenow="${this.startValue ?? ''}"
              aria-invalid="${hasError ? 'true' : 'false'}"
              aria-required="${this.required ? 'true' : 'false'}"
              aria-readonly="${this.readonly ? 'true' : 'false'}"
              @input="${this.handleStartInput}"
              @change="${this.handleStartChange}"
              @focus="${this.handleFocus}"
              @blur="${this.handleBlur}"
            />

            <input
              class="${this.getInputClasses('end')}"
              style="${this.getInputStyle('end')}"
              type="range"
              min="${min}"
              max="${max}"
              step="${this.step ?? 1}"
              .value="${String(endValue)}"
              ?disabled="${isBlocked}"
              aria-labelledby="${endLabelId}"
              aria-valuemin="${min}"
              aria-valuemax="${max}"
              aria-valuenow="${this.endValue ?? ''}"
              aria-invalid="${hasError ? 'true' : 'false'}"
              aria-required="${this.required ? 'true' : 'false'}"
              aria-readonly="${this.readonly ? 'true' : 'false'}"
              @input="${this.handleEndInput}"
              @change="${this.handleEndChange}"
              @focus="${this.handleFocus}"
              @blur="${this.handleBlur}"
            />

            ${this.loading ? html `<div class="ml-spinner ml-range-spinner"></div>` : html ``}
          </div>

          <div class="mt-2 flex items-center justify-between text-sm ml-range-values">
            ${this.renderValueDisplay(this.startValue)}
            ${this.renderValueDisplay(this.endValue)}
          </div>

          ${this.renderValueLabels()}
        </div>

        ${this.renderHelperOrError()}
      </div>
    `;
    }
    // ===========================================================================
    // RENDER
    // ===========================================================================
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        if (!this.isEditing)
            return this.renderViewMode();
        return this.renderEditMode();
    }
};
__decorate([
    propertyDataSource({ type: Number, attribute: 'start-value' })
], MlNumberRangeSliderMolecule.prototype, "startValue", void 0);
__decorate([
    propertyDataSource({ type: Number, attribute: 'end-value' })
], MlNumberRangeSliderMolecule.prototype, "endValue", void 0);
__decorate([
    propertyDataSource({ type: String })
], MlNumberRangeSliderMolecule.prototype, "error", void 0);
__decorate([
    propertyDataSource({ type: String })
], MlNumberRangeSliderMolecule.prototype, "name", void 0);
__decorate([
    propertyDataSource({ type: Number })
], MlNumberRangeSliderMolecule.prototype, "min", void 0);
__decorate([
    propertyDataSource({ type: Number })
], MlNumberRangeSliderMolecule.prototype, "max", void 0);
__decorate([
    propertyDataSource({ type: Number })
], MlNumberRangeSliderMolecule.prototype, "step", void 0);
__decorate([
    propertyDataSource({ type: Number })
], MlNumberRangeSliderMolecule.prototype, "decimals", void 0);
__decorate([
    propertyDataSource({ type: String })
], MlNumberRangeSliderMolecule.prototype, "locale", void 0);
__decorate([
    propertyDataSource({ type: String })
], MlNumberRangeSliderMolecule.prototype, "placeholder", void 0);
__decorate([
    propertyDataSource({ type: Number, attribute: 'min-gap' })
], MlNumberRangeSliderMolecule.prototype, "minGap", void 0);
__decorate([
    propertyDataSource({ type: Number, attribute: 'max-gap' })
], MlNumberRangeSliderMolecule.prototype, "maxGap", void 0);
__decorate([
    propertyDataSource({ type: Boolean, attribute: 'is-editing' })
], MlNumberRangeSliderMolecule.prototype, "isEditing", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MlNumberRangeSliderMolecule.prototype, "disabled", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MlNumberRangeSliderMolecule.prototype, "readonly", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MlNumberRangeSliderMolecule.prototype, "required", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MlNumberRangeSliderMolecule.prototype, "loading", void 0);
__decorate([
    state()
], MlNumberRangeSliderMolecule.prototype, "activeHandle", void 0);
__decorate([
    state()
], MlNumberRangeSliderMolecule.prototype, "topHandle", void 0);
MlNumberRangeSliderMolecule = __decorate([
    customElement('groupenternumberinterval--ml-number-range-slider')
], MlNumberRangeSliderMolecule);
export { MlNumberRangeSliderMolecule };
