/// <mls fileReference="_102053_/l2/molecules/groupenternumberinterval/ml-number-range-slider2.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// ML NUMBER RANGE SLIDER 2 MOLECULE
// =============================================================================
// Skill Group: groupEnterNumberInterval
// Dual-handle numeric range slider (horizontal). Presentation-only.
// This molecule does NOT contain business logic.
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement, state } from 'lit/decorators.js';
import { unsafeHTML } from 'lit/directives/unsafe-html.js';
import { propertyDataSource } from '/_102029_/l2/collabDecorators.js';
import { MoleculeAuraElement } from '/_102033_/l2/moleculeBase.js';
import { cn } from '/_102033_/l2/cn.js';
/// **collab_i18n_start**
const message_en = {
    loading: 'Loading...',
    emptyValue: '—',
    rangeSeparator: '–',
    startHandle: 'Minimum value',
    endHandle: 'Maximum value',
};
const messages = {
    en: message_en,
    pt: {
        loading: 'Carregando...',
        emptyValue: '—',
        rangeSeparator: '–',
        startHandle: 'Valor mínimo',
        endHandle: 'Valor máximo',
    },
};
/// **collab_i18n_end**
let MlNumberRangeSlider2Molecule = class MlNumberRangeSlider2Molecule extends MoleculeAuraElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`groupenternumberinterval--ml-number-range-slider2 .ml-number-range-slider {
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
  color: var(--ml-on-surface, #1c1b1f);
}
groupenternumberinterval--ml-number-range-slider2 .ml-label {
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
  font-weight: var(--ml-font-weight-medium, 500);
  color: var(--ml-on-surface, #1c1b1f);
}
groupenternumberinterval--ml-number-range-slider2 .ml-required-mark {
  color: var(--ml-error, #ef4444);
  margin-left: 2px;
}
groupenternumberinterval--ml-number-range-slider2 .ml-text {
  color: var(--ml-on-surface, #1c1b1f);
}
groupenternumberinterval--ml-number-range-slider2 .ml-text-muted {
  color: var(--ml-on-surface-muted, #49454f);
}
groupenternumberinterval--ml-number-range-slider2 .ml-text-faint {
  color: var(--ml-on-surface-faint, #79747e);
}
groupenternumberinterval--ml-number-range-slider2 .ml-affix {
  color: var(--ml-on-surface-muted, #49454f);
}
groupenternumberinterval--ml-number-range-slider2 .ml-prefix {
  color: var(--ml-on-surface-muted, #49454f);
}
groupenternumberinterval--ml-number-range-slider2 .ml-suffix {
  color: var(--ml-on-surface-muted, #49454f);
}
groupenternumberinterval--ml-number-range-slider2 .ml-value-text {
  color: var(--ml-on-surface, #1c1b1f);
  font-weight: var(--ml-font-weight-medium, 500);
}
groupenternumberinterval--ml-number-range-slider2 .ml-slider-track {
  touch-action: none;
  user-select: none;
}
groupenternumberinterval--ml-number-range-slider2 .ml-slider-rail {
  background: var(--ml-surface-dim, #f5f5f5);
  border: var(--ml-border-width, 1px) var(--ml-border-style, solid) var(--ml-outline-variant, #e2e8f0);
}
groupenternumberinterval--ml-number-range-slider2 .ml-slider-range {
  background: var(--ml-primary, #3b82f6);
  transition: left var(--ml-transition, 200ms ease), width var(--ml-transition, 200ms ease);
}
groupenternumberinterval--ml-number-range-slider2 .ml-slider-handle {
  background: var(--ml-surface, #ffffff);
  border: 2px var(--ml-border-style, solid) var(--ml-primary, #3b82f6);
  box-shadow: var(--ml-shadow-1, 0 1px 3px rgba(0, 0, 0, 0.1));
  outline: none;
  z-index: 1;
  transition: box-shadow var(--ml-transition, 200ms ease), border-color var(--ml-transition, 200ms ease), background-color var(--ml-transition, 200ms ease);
}
groupenternumberinterval--ml-number-range-slider2 .ml-slider-handle:hover {
  box-shadow: var(--ml-shadow-2, 0 4px 6px rgba(0, 0, 0, 0.1));
}
groupenternumberinterval--ml-number-range-slider2 .ml-slider-handle:focus,
groupenternumberinterval--ml-number-range-slider2 .ml-slider-handle:focus-visible {
  border-color: var(--ml-outline-focus, #3b82f6);
  box-shadow: 0 0 0 var(--ml-focus-ring-width, 2px) var(--ml-focus-ring-color, rgba(59, 130, 246, 0.4));
}
groupenternumberinterval--ml-number-range-slider2 .ml-slider-handle-start {
  z-index: 2;
}
groupenternumberinterval--ml-number-range-slider2 .ml-slider-handle-end {
  z-index: 2;
}
groupenternumberinterval--ml-number-range-slider2 .ml-slider-handle-active {
  background: var(--ml-primary, #3b82f6);
  border-color: var(--ml-primary, #3b82f6);
  box-shadow: 0 0 0 var(--ml-focus-ring-width, 2px) var(--ml-focus-ring-color, rgba(59, 130, 246, 0.4));
}
groupenternumberinterval--ml-number-range-slider2 .ml-slider-track-error .ml-slider-handle {
  border-color: var(--ml-outline-error, #ef4444);
}
groupenternumberinterval--ml-number-range-slider2 .ml-slider-track-error .ml-slider-range {
  background: var(--ml-error, #ef4444);
}
groupenternumberinterval--ml-number-range-slider2 .ml-has-error .ml-slider-handle {
  border-color: var(--ml-outline-error, #ef4444);
}
groupenternumberinterval--ml-number-range-slider2 .ml-has-error .ml-slider-handle:focus,
groupenternumberinterval--ml-number-range-slider2 .ml-has-error .ml-slider-handle:focus-visible {
  border-color: var(--ml-outline-error, #ef4444);
  box-shadow: 0 0 0 var(--ml-focus-ring-width, 2px) var(--ml-focus-ring-color, rgba(59, 130, 246, 0.4));
}
groupenternumberinterval--ml-number-range-slider2 .ml-error-text {
  color: var(--ml-error, #ef4444);
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
}
groupenternumberinterval--ml-number-range-slider2 .ml-helper {
  color: var(--ml-on-surface-faint, #79747e);
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
}
groupenternumberinterval--ml-number-range-slider2 .ml-disabled {
  opacity: var(--ml-disabled-opacity, 0.5);
  cursor: not-allowed;
}
groupenternumberinterval--ml-number-range-slider2 .ml-disabled .ml-slider-track,
groupenternumberinterval--ml-number-range-slider2 .ml-disabled .ml-slider-handle {
  cursor: not-allowed;
  pointer-events: none;
}
groupenternumberinterval--ml-number-range-slider2 .ml-view-mode .ml-text {
  color: var(--ml-on-surface, #1c1b1f);
}
groupenternumberinterval--ml-number-range-slider2 .ml-spinner {
  border-color: var(--ml-outline-variant, #e2e8f0);
  border-top-color: var(--ml-primary, #3b82f6);
}
groupenternumberinterval--ml-number-range-slider2 .ml-skeleton {
  background: var(--ml-surface-dim, #f5f5f5);
  border: var(--ml-border-width, 1px) var(--ml-border-style, solid) var(--ml-outline-variant, #e2e8f0);
}
`);
        this.msg = messages.en;
        // ===========================================================================
        // SLOT TAGS
        // ===========================================================================
        this.slotTags = ['Label', 'LabelStart', 'LabelEnd', 'Helper', 'Prefix', 'Suffix'];
        // ===========================================================================
        // PROPERTIES — Data
        // ===========================================================================
        this.startValue = null;
        this.endValue = null;
        this.error = '';
        this.name = '';
        // ===========================================================================
        // PROPERTIES — Configuration
        // ===========================================================================
        this.min = null;
        this.max = null;
        this.step = 1;
        this.decimals = 0;
        this.locale = '';
        this.placeholder = '';
        this.minGap = 0;
        this.maxGap = 0;
        // ===========================================================================
        // PROPERTIES — States
        // ===========================================================================
        this.isEditing = true;
        this.disabled = false;
        this.readonly = false;
        this.required = false;
        this.loading = false;
        // ===========================================================================
        // INTERNAL STATE
        // ===========================================================================
        this.activeHandle = null;
        this.focusedHandle = null;
        this.trackEl = null;
        this.dragging = false;
        this.boundPointerMove = null;
        this.boundPointerUp = null;
    }
    // ===========================================================================
    // LIFECYCLE
    // ===========================================================================
    disconnectedCallback() {
        super.disconnectedCallback();
        this.teardownDragListeners();
    }
    // ===========================================================================
    // BOUNDS HELPERS
    // ===========================================================================
    getEffectiveMin() {
        return this.min === null || this.min === undefined ? 0 : Number(this.min);
    }
    getEffectiveMax() {
        return this.max === null || this.max === undefined ? 100 : Number(this.max);
    }
    getStep() {
        const s = Number(this.step);
        return !s || s <= 0 ? 1 : s;
    }
    getDecimals() {
        const d = Number(this.decimals);
        return !d || d < 0 ? 0 : Math.floor(d);
    }
    getMinGap() {
        const g = Number(this.minGap);
        return !g || g < 0 ? 0 : g;
    }
    getMaxGap() {
        const g = Number(this.maxGap);
        return !g || g < 0 ? 0 : g;
    }
    roundToDecimals(value) {
        const d = this.getDecimals();
        const factor = Math.pow(10, d);
        return Math.round(value * factor) / factor;
    }
    snapToStep(value) {
        const min = this.getEffectiveMin();
        const step = this.getStep();
        const snapped = min + Math.round((value - min) / step) * step;
        return this.roundToDecimals(snapped);
    }
    clampToBounds(value) {
        let next = value;
        const min = this.getEffectiveMin();
        const max = this.getEffectiveMax();
        next = Math.max(next, min);
        next = Math.min(next, max);
        return this.roundToDecimals(next);
    }
    resolvePair(start, end) {
        if (start === null && end === null) {
            return { start: null, end: null };
        }
        let s = start === null || start === undefined ? null : this.clampToBounds(this.snapToStep(Number(start)));
        let e = end === null || end === undefined ? null : this.clampToBounds(this.snapToStep(Number(end)));
        if (s !== null && e !== null) {
            if (s > e) {
                const tmp = s;
                s = e;
                e = tmp;
            }
            const minGap = this.getMinGap();
            const maxGap = this.getMaxGap();
            if (minGap > 0 && e - s < minGap) {
                e = this.clampToBounds(this.snapToStep(s + minGap));
                if (e - s < minGap) {
                    s = this.clampToBounds(this.snapToStep(e - minGap));
                }
            }
            if (maxGap > 0 && e - s > maxGap) {
                e = this.clampToBounds(this.snapToStep(s + maxGap));
            }
        }
        return { start: s, end: e };
    }
    getDisplayStart() {
        if (this.startValue !== null && this.startValue !== undefined) {
            return Number(this.startValue);
        }
        return this.getEffectiveMin();
    }
    getDisplayEnd() {
        if (this.endValue !== null && this.endValue !== undefined) {
            return Number(this.endValue);
        }
        return this.getEffectiveMax();
    }
    valueToPercent(value) {
        const min = this.getEffectiveMin();
        const max = this.getEffectiveMax();
        const range = max - min;
        if (range <= 0)
            return 0;
        const pct = ((value - min) / range) * 100;
        return Math.min(100, Math.max(0, pct));
    }
    percentToValue(percent) {
        const min = this.getEffectiveMin();
        const max = this.getEffectiveMax();
        const raw = min + (percent / 100) * (max - min);
        return this.clampToBounds(this.snapToStep(raw));
    }
    clientXToPercent(clientX) {
        if (!this.trackEl)
            return 0;
        const rect = this.trackEl.getBoundingClientRect();
        if (rect.width <= 0)
            return 0;
        const x = clientX - rect.left;
        return Math.min(100, Math.max(0, (x / rect.width) * 100));
    }
    // ===========================================================================
    // FORMATTING
    // ===========================================================================
    formatNumber(value) {
        if (value === null || value === undefined || Number.isNaN(Number(value))) {
            return this.msg.emptyValue;
        }
        const num = Number(value);
        const d = this.getDecimals();
        const locale = this.locale && String(this.locale).trim() ? String(this.locale) : undefined;
        try {
            return num.toLocaleString(locale, {
                minimumFractionDigits: d,
                maximumFractionDigits: d,
            });
        }
        catch {
            return num.toFixed(d);
        }
    }
    wrapWithAffixes(formatted) {
        const prefix = this.hasSlot('Prefix') ? this.getSlotContent('Prefix') : '';
        const suffix = this.hasSlot('Suffix') ? this.getSlotContent('Suffix') : '';
        return html `
      ${prefix
            ? html `<span class="${cn('ml-affix ml-prefix', this.getSlotClass('Prefix'))}">${unsafeHTML(prefix)}</span>`
            : ''}
      <span class="ml-value-text">${formatted}</span>
      ${suffix
            ? html `<span class="${cn('ml-affix ml-suffix', this.getSlotClass('Suffix'))}">${unsafeHTML(suffix)}</span>`
            : ''}
    `;
    }
    formatIntervalDisplay() {
        const hasStart = this.startValue !== null && this.startValue !== undefined;
        const hasEnd = this.endValue !== null && this.endValue !== undefined;
        if (!hasStart && !hasEnd) {
            return html `<span class="ml-text-faint">${this.msg.emptyValue}</span>`;
        }
        const startText = hasStart ? this.formatNumber(this.startValue) : this.msg.emptyValue;
        const endText = hasEnd ? this.formatNumber(this.endValue) : this.msg.emptyValue;
        return html `
      <span class="inline-flex items-center gap-1">
        ${this.wrapWithAffixes(startText)}
        <span class="ml-text-muted">${this.msg.rangeSeparator}</span>
        ${this.wrapWithAffixes(endText)}
      </span>
    `;
    }
    // ===========================================================================
    // VALUE UPDATES
    // ===========================================================================
    applyPair(nextStart, nextEnd, emitInput, emitChange) {
        const resolved = this.resolvePair(nextStart, nextEnd);
        const startChanged = resolved.start !== this.startValue;
        const endChanged = resolved.end !== this.endValue;
        if (startChanged)
            this.startValue = resolved.start;
        if (endChanged)
            this.endValue = resolved.end;
        if (emitInput && (startChanged || endChanged)) {
            this.dispatchInput();
        }
        if (emitChange && (startChanged || endChanged)) {
            this.dispatchChange();
        }
    }
    moveHandle(handle, rawValue, emitInput) {
        const minGap = this.getMinGap();
        const maxGap = this.getMaxGap();
        let s = this.getDisplayStart();
        let e = this.getDisplayEnd();
        let next = this.clampToBounds(this.snapToStep(rawValue));
        if (handle === 'start') {
            // Keep start ≤ end - minGap
            const maxStart = minGap > 0 ? e - minGap : e;
            if (next > maxStart)
                next = this.clampToBounds(this.snapToStep(maxStart));
            // maxGap: if gap would exceed, pull end along
            if (maxGap > 0 && e - next > maxGap) {
                e = this.clampToBounds(this.snapToStep(next + maxGap));
            }
            // minGap push end if needed after clamp
            if (minGap > 0 && e - next < minGap) {
                e = this.clampToBounds(this.snapToStep(next + minGap));
            }
            s = next;
        }
        else {
            // Keep end ≥ start + minGap
            const minEnd = minGap > 0 ? s + minGap : s;
            if (next < minEnd)
                next = this.clampToBounds(this.snapToStep(minEnd));
            // maxGap: if gap would exceed, pull start along
            if (maxGap > 0 && next - s > maxGap) {
                s = this.clampToBounds(this.snapToStep(next - maxGap));
            }
            // minGap push start if needed after clamp
            if (minGap > 0 && next - s < minGap) {
                s = this.clampToBounds(this.snapToStep(next - minGap));
            }
            e = next;
        }
        this.applyPair(s, e, emitInput, false);
    }
    stepHandle(handle, direction) {
        if (this.disabled || this.readonly || this.loading || !this.isEditing)
            return;
        const current = handle === 'start' ? this.getDisplayStart() : this.getDisplayEnd();
        const next = current + direction * this.getStep();
        this.moveHandle(handle, next, true);
        this.dispatchChange();
    }
    // ===========================================================================
    // EVENTS
    // ===========================================================================
    dispatchChange() {
        this.dispatchEvent(new CustomEvent('change', {
            bubbles: true,
            composed: true,
            detail: {
                startValue: this.startValue,
                endValue: this.endValue,
            },
        }));
    }
    dispatchInput() {
        this.dispatchEvent(new CustomEvent('input', {
            bubbles: true,
            composed: true,
            detail: {
                startValue: this.startValue,
                endValue: this.endValue,
            },
        }));
    }
    dispatchFocus() {
        this.dispatchEvent(new CustomEvent('focus', {
            bubbles: true,
            composed: true,
            detail: {},
        }));
    }
    dispatchBlur() {
        this.dispatchEvent(new CustomEvent('blur', {
            bubbles: true,
            composed: true,
            detail: {},
        }));
    }
    // ===========================================================================
    // POINTER / DRAG
    // ===========================================================================
    canInteract() {
        return !!(this.isEditing && !this.disabled && !this.readonly && !this.loading);
    }
    handleTrackPointerDown(e) {
        if (!this.canInteract())
            return;
        if (e.button !== 0)
            return;
        this.trackEl = e.currentTarget;
        const percent = this.clientXToPercent(e.clientX);
        const value = this.percentToValue(percent);
        const start = this.getDisplayStart();
        const end = this.getDisplayEnd();
        const distStart = Math.abs(value - start);
        const distEnd = Math.abs(value - end);
        // Prefer the closer handle; if equal, pick based on which side of midpoint
        let handle;
        if (distStart < distEnd) {
            handle = 'start';
        }
        else if (distEnd < distStart) {
            handle = 'end';
        }
        else {
            handle = value <= (start + end) / 2 ? 'start' : 'end';
        }
        this.activeHandle = handle;
        this.dragging = true;
        this.moveHandle(handle, value, true);
        this.boundPointerMove = (ev) => this.handlePointerMove(ev);
        this.boundPointerUp = (ev) => this.handlePointerUp(ev);
        window.addEventListener('pointermove', this.boundPointerMove);
        window.addEventListener('pointerup', this.boundPointerUp);
        window.addEventListener('pointercancel', this.boundPointerUp);
        e.preventDefault();
    }
    handleHandlePointerDown(e, handle) {
        if (!this.canInteract())
            return;
        if (e.button !== 0)
            return;
        e.stopPropagation();
        e.preventDefault();
        const track = e.currentTarget.closest('.ml-slider-track');
        this.trackEl = track;
        this.activeHandle = handle;
        this.dragging = true;
        e.currentTarget.focus();
        this.boundPointerMove = (ev) => this.handlePointerMove(ev);
        this.boundPointerUp = (ev) => this.handlePointerUp(ev);
        window.addEventListener('pointermove', this.boundPointerMove);
        window.addEventListener('pointerup', this.boundPointerUp);
        window.addEventListener('pointercancel', this.boundPointerUp);
    }
    handlePointerMove(e) {
        if (!this.dragging || !this.activeHandle)
            return;
        const percent = this.clientXToPercent(e.clientX);
        const value = this.percentToValue(percent);
        this.moveHandle(this.activeHandle, value, true);
    }
    handlePointerUp(_e) {
        if (!this.dragging)
            return;
        this.dragging = false;
        this.teardownDragListeners();
        this.dispatchChange();
        this.activeHandle = null;
    }
    teardownDragListeners() {
        if (this.boundPointerMove) {
            window.removeEventListener('pointermove', this.boundPointerMove);
            this.boundPointerMove = null;
        }
        if (this.boundPointerUp) {
            window.removeEventListener('pointerup', this.boundPointerUp);
            window.removeEventListener('pointercancel', this.boundPointerUp);
            this.boundPointerUp = null;
        }
    }
    // ===========================================================================
    // KEYBOARD
    // ===========================================================================
    handleHandleKeyDown(e, handle) {
        if (!this.canInteract())
            return;
        switch (e.key) {
            case 'ArrowLeft':
            case 'ArrowDown':
                e.preventDefault();
                this.activeHandle = handle;
                this.stepHandle(handle, -1);
                break;
            case 'ArrowRight':
            case 'ArrowUp':
                e.preventDefault();
                this.activeHandle = handle;
                this.stepHandle(handle, 1);
                break;
            case 'Home':
                e.preventDefault();
                this.activeHandle = handle;
                this.moveHandle(handle, this.getEffectiveMin(), true);
                this.dispatchChange();
                break;
            case 'End':
                e.preventDefault();
                this.activeHandle = handle;
                this.moveHandle(handle, this.getEffectiveMax(), true);
                this.dispatchChange();
                break;
            case 'PageDown':
                e.preventDefault();
                this.activeHandle = handle;
                this.moveHandle(handle, (handle === 'start' ? this.getDisplayStart() : this.getDisplayEnd()) - this.getStep() * 10, true);
                this.dispatchChange();
                break;
            case 'PageUp':
                e.preventDefault();
                this.activeHandle = handle;
                this.moveHandle(handle, (handle === 'start' ? this.getDisplayStart() : this.getDisplayEnd()) + this.getStep() * 10, true);
                this.dispatchChange();
                break;
            default:
                break;
        }
    }
    handleHandleFocus(handle) {
        this.focusedHandle = handle;
        this.dispatchFocus();
    }
    handleHandleBlur(handle) {
        if (this.focusedHandle === handle) {
            this.focusedHandle = null;
        }
        if (this.activeHandle === handle && !this.dragging) {
            this.activeHandle = null;
        }
        this.dispatchBlur();
    }
    // ===========================================================================
    // CLASS HELPERS
    // ===========================================================================
    getRootClasses() {
        return [
            'flex flex-col w-full gap-1',
            'ml-number-range-slider',
            this.disabled ? 'ml-disabled' : '',
            this.error ? 'ml-has-error' : '',
            !this.isEditing ? 'ml-view-mode' : '',
        ]
            .filter(Boolean)
            .join(' ');
    }
    getTrackClasses() {
        return [
            'relative w-full h-2 flex items-center',
            'ml-slider-track',
            this.canInteract() ? 'cursor-pointer' : '',
            this.error ? 'ml-slider-track-error' : '',
        ]
            .filter(Boolean)
            .join(' ');
    }
    getHandleClasses(handle) {
        const isActive = this.activeHandle === handle || this.focusedHandle === handle;
        return [
            'absolute top-1/2 -translate-y-1/2 -translate-x-1/2',
            'w-4 h-4 rounded-full',
            'ml-slider-handle',
            handle === 'start' ? 'ml-slider-handle-start' : 'ml-slider-handle-end',
            isActive ? 'ml-slider-handle-active' : '',
            this.canInteract() ? 'cursor-grab' : '',
            this.dragging && this.activeHandle === handle ? 'cursor-grabbing' : '',
        ]
            .filter(Boolean)
            .join(' ');
    }
    // ===========================================================================
    // A11Y HELPERS
    // ===========================================================================
    getHandleLabel(handle) {
        if (handle === 'start') {
            const slot = this.getSlotContent('LabelStart');
            if (slot) {
                // strip tags for aria
                const tmp = document.createElement('div');
                tmp.innerHTML = slot;
                return tmp.textContent?.trim() || this.msg.startHandle;
            }
            return this.msg.startHandle;
        }
        const slot = this.getSlotContent('LabelEnd');
        if (slot) {
            const tmp = document.createElement('div');
            tmp.innerHTML = slot;
            return tmp.textContent?.trim() || this.msg.endHandle;
        }
        return this.msg.endHandle;
    }
    getErrorId() {
        return `ml-nrs-error-${this.name || 'field'}`;
    }
    getLabelId() {
        return `ml-nrs-label-${this.name || 'field'}`;
    }
    // ===========================================================================
    // RENDER PIECES
    // ===========================================================================
    renderLabel() {
        if (!this.hasSlot('Label'))
            return html ``;
        return html `
      <div
        id=${this.getLabelId()}
        class="${cn('mb-1 text-sm ml-label', this.getSlotClass('Label'))}"
      >
        ${unsafeHTML(this.getSlotContent('Label'))}
        ${this.required && this.isEditing
            ? html `<span class="ml-required-mark" aria-hidden="true">*</span>`
            : ''}
      </div>
    `;
    }
    renderHandleLabels() {
        const hasStart = this.hasSlot('LabelStart');
        const hasEnd = this.hasSlot('LabelEnd');
        if (!hasStart && !hasEnd)
            return html ``;
        return html `
      <div class="flex items-center justify-between gap-2 mb-1">
        <div class="${cn('text-xs ml-text-muted', this.getSlotClass('LabelStart'))}">
          ${hasStart ? unsafeHTML(this.getSlotContent('LabelStart')) : ''}
        </div>
        <div class="${cn('text-xs ml-text-muted text-right', this.getSlotClass('LabelEnd'))}">
          ${hasEnd ? unsafeHTML(this.getSlotContent('LabelEnd')) : ''}
        </div>
      </div>
    `;
    }
    renderValueReadout() {
        const hasStart = this.startValue !== null && this.startValue !== undefined;
        const hasEnd = this.endValue !== null && this.endValue !== undefined;
        const showPlaceholder = !hasStart || !hasEnd;
        if (showPlaceholder && this.placeholder) {
            return html `
        <div class="flex items-center justify-between gap-2 mb-2 text-sm">
          <span class="ml-text-faint">${this.placeholder}</span>
        </div>
      `;
        }
        return html `
      <div class="flex items-center justify-between gap-2 mb-2 text-sm ml-text">
        <span class="inline-flex items-center gap-1">
          ${this.wrapWithAffixes(this.formatNumber(hasStart ? this.startValue : null))}
        </span>
        <span class="ml-text-muted">${this.msg.rangeSeparator}</span>
        <span class="inline-flex items-center gap-1">
          ${this.wrapWithAffixes(this.formatNumber(hasEnd ? this.endValue : null))}
        </span>
      </div>
    `;
    }
    renderHandle(handle, value, percent) {
        const isInteractive = this.canInteract();
        const hasError = !!(this.error && String(this.error).trim());
        const describedBy = hasError ? this.getErrorId() : nothingAttr();
        return html `
      <div
        class="${this.getHandleClasses(handle)}"
        style="left: ${percent}%;"
        role="slider"
        tabindex=${isInteractive ? '0' : '-1'}
        aria-label=${this.getHandleLabel(handle)}
        aria-valuemin=${this.getEffectiveMin()}
        aria-valuemax=${this.getEffectiveMax()}
        aria-valuenow=${value}
        aria-valuetext=${this.formatNumber(value)}
        aria-disabled=${this.disabled ? 'true' : 'false'}
        aria-readonly=${this.readonly ? 'true' : 'false'}
        aria-required=${this.required ? 'true' : 'false'}
        aria-invalid=${hasError ? 'true' : 'false'}
        aria-describedby=${describedBy}
        @pointerdown=${(e) => this.handleHandlePointerDown(e, handle)}
        @keydown=${(e) => this.handleHandleKeyDown(e, handle)}
        @focus=${() => this.handleHandleFocus(handle)}
        @blur=${() => this.handleHandleBlur(handle)}
      ></div>
    `;
    }
    renderSlider() {
        const startVal = this.getDisplayStart();
        const endVal = this.getDisplayEnd();
        const startPct = this.valueToPercent(startVal);
        const endPct = this.valueToPercent(endVal);
        // Ensure visual order: start handle never to the right of end
        const leftPct = Math.min(startPct, endPct);
        const rightPct = Math.max(startPct, endPct);
        const rangeWidth = Math.max(0, rightPct - leftPct);
        return html `
      <div class="px-2 py-3">
        <div
          class="${this.getTrackClasses()}"
          @pointerdown=${(e) => this.handleTrackPointerDown(e)}
        >
          <div class="absolute inset-0 rounded-full ml-slider-rail"></div>
          <div
            class="absolute top-0 bottom-0 rounded-full ml-slider-range"
            style="left: ${leftPct}%; width: ${rangeWidth}%;"
          ></div>
          ${this.renderHandle('start', startVal, startPct)}
          ${this.renderHandle('end', endVal, endPct)}
        </div>
      </div>
    `;
    }
    renderFeedback() {
        if (!this.isEditing)
            return html ``;
        if (this.error && String(this.error).trim()) {
            return html `
        <p
          id=${this.getErrorId()}
          class="${cn('mt-1 text-xs ml-error-text')}"
          role="alert"
        >
          ${unsafeHTML(String(this.error))}
        </p>
      `;
        }
        if (this.hasSlot('Helper')) {
            return html `
        <p class="${cn('mt-1 text-xs ml-helper', this.getSlotClass('Helper'))}">
          ${unsafeHTML(this.getSlotContent('Helper'))}
        </p>
      `;
        }
        return html ``;
    }
    renderLoading() {
        return html `
      <div class="${cn(this.getRootClasses(), this.cssClass)}" aria-busy="true">
        ${this.renderLabel()}
        <div class="flex items-center gap-2 py-3">
          <div class="ml-spinner animate-spin w-5 h-5 rounded-full border-2"></div>
          <span class="text-sm ml-text-muted">${this.msg.loading}</span>
        </div>
        <div class="w-full h-2 rounded-full ml-skeleton"></div>
      </div>
    `;
    }
    renderViewMode() {
        return html `
      <div class="${cn(this.getRootClasses(), this.cssClass)}">
        ${this.renderLabel()}
        <div class="text-sm ml-text py-1">
          ${this.formatIntervalDisplay()}
        </div>
      </div>
    `;
    }
    // ===========================================================================
    // RENDER
    // ===========================================================================
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang] || messages.en;
        if (this.loading) {
            return this.renderLoading();
        }
        if (!this.isEditing) {
            return this.renderViewMode();
        }
        return html `
      <div class="${cn(this.getRootClasses(), this.cssClass)}">
        ${this.renderLabel()}
        ${this.renderHandleLabels()}
        ${this.renderValueReadout()}
        ${this.renderSlider()}
        ${this.renderFeedback()}
      </div>
    `;
    }
};
__decorate([
    propertyDataSource({ type: Number, attribute: 'start-value' })
], MlNumberRangeSlider2Molecule.prototype, "startValue", void 0);
__decorate([
    propertyDataSource({ type: Number, attribute: 'end-value' })
], MlNumberRangeSlider2Molecule.prototype, "endValue", void 0);
__decorate([
    propertyDataSource({ type: String })
], MlNumberRangeSlider2Molecule.prototype, "error", void 0);
__decorate([
    propertyDataSource({ type: String })
], MlNumberRangeSlider2Molecule.prototype, "name", void 0);
__decorate([
    propertyDataSource({ type: Number })
], MlNumberRangeSlider2Molecule.prototype, "min", void 0);
__decorate([
    propertyDataSource({ type: Number })
], MlNumberRangeSlider2Molecule.prototype, "max", void 0);
__decorate([
    propertyDataSource({ type: Number })
], MlNumberRangeSlider2Molecule.prototype, "step", void 0);
__decorate([
    propertyDataSource({ type: Number })
], MlNumberRangeSlider2Molecule.prototype, "decimals", void 0);
__decorate([
    propertyDataSource({ type: String })
], MlNumberRangeSlider2Molecule.prototype, "locale", void 0);
__decorate([
    propertyDataSource({ type: String })
], MlNumberRangeSlider2Molecule.prototype, "placeholder", void 0);
__decorate([
    propertyDataSource({ type: Number, attribute: 'min-gap' })
], MlNumberRangeSlider2Molecule.prototype, "minGap", void 0);
__decorate([
    propertyDataSource({ type: Number, attribute: 'max-gap' })
], MlNumberRangeSlider2Molecule.prototype, "maxGap", void 0);
__decorate([
    propertyDataSource({ type: Boolean, attribute: 'is-editing' })
], MlNumberRangeSlider2Molecule.prototype, "isEditing", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MlNumberRangeSlider2Molecule.prototype, "disabled", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MlNumberRangeSlider2Molecule.prototype, "readonly", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MlNumberRangeSlider2Molecule.prototype, "required", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MlNumberRangeSlider2Molecule.prototype, "loading", void 0);
__decorate([
    state()
], MlNumberRangeSlider2Molecule.prototype, "activeHandle", void 0);
__decorate([
    state()
], MlNumberRangeSlider2Molecule.prototype, "focusedHandle", void 0);
MlNumberRangeSlider2Molecule = __decorate([
    customElement('groupenternumberinterval--ml-number-range-slider2')
], MlNumberRangeSlider2Molecule);
export { MlNumberRangeSlider2Molecule };
/** Helper: return empty string for aria-describedby when no error (avoids "null" attr). */
function nothingAttr() {
    return '';
}
