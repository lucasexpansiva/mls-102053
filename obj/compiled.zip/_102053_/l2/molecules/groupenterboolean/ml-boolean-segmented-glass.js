var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102053_/l2/molecules/groupenterboolean/ml-boolean-segmented-glass.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// BOOLEAN SEGMENTED — GLASSMORPHISM (mls-102053)
// =============================================================================
// Skill Group: groupEnterBoolean
// Casca (estratégia D): herda tudo de BooleanSegmentedMolecule (mls-102040),
// inclusive render() — o markup base emite classes semânticas ml-*; a aparência
// vem do .less irmão, escopado sob esta tag.
// This molecule does NOT contain business logic.
import { customElement } from 'lit/decorators.js';
import { BooleanSegmentedMolecule } from '/_102040_/l2/molecules/groupenterboolean/ml-boolean-segmented.js';
let BooleanSegmentedMoleculeGlass = class BooleanSegmentedMoleculeGlass extends BooleanSegmentedMolecule {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(`groupenterboolean--ml-boolean-segmented-glass {
  --ml-font-family: 'Inter', system-ui, sans-serif;
  --ml-font-weight-medium: 600;
  --ml-radius-sm: 12px;
  --ml-radius-md: 12px;
  --ml-border-width: 1px;
  --ml-border-style: solid;
  --ml-outline-variant: rgba(255, 255, 255, 0.25);
  --ml-outline-focus: rgba(199, 210, 254, 0.9);
  --ml-outline-error: rgba(255, 120, 120, 0.85);
  --ml-primary: rgba(99, 102, 241, 0.55);
  --ml-on-primary: #ffffff;
  --ml-surface: rgba(255, 255, 255, 0.1);
  --ml-on-surface: rgba(255, 255, 255, 0.95);
  --ml-on-surface-muted: rgba(255, 255, 255, 0.55);
  --ml-error: #ffb4ab;
  --ml-shadow-1: 0 4px 18px rgba(0, 0, 0, 0.18);
  --ml-shadow-2: 0 6px 24px rgba(0, 0, 0, 0.26);
  --ml-transition: 250ms ease;
  --ml-focus-ring-width: 3px;
  --ml-focus-ring-color: rgba(199, 210, 254, 0.3);
  --ml-disabled-opacity: 0.5;
  --ml-backdrop-blur: 10px;
}
groupenterboolean--ml-boolean-segmented-glass .ml-text {
  color: var(--ml-on-surface, rgba(255, 255, 255, 0.95));
  font-family: var(--ml-font-family, 'Inter', system-ui, sans-serif);
}
groupenterboolean--ml-boolean-segmented-glass .ml-label {
  font-family: var(--ml-font-family, 'Inter', system-ui, sans-serif);
  font-weight: var(--ml-font-weight-medium, 600);
  color: var(--ml-on-surface, rgba(255, 255, 255, 0.95));
}
groupenterboolean--ml-boolean-segmented-glass .ml-helper {
  color: var(--ml-on-surface-muted, rgba(255, 255, 255, 0.55));
  font-family: var(--ml-font-family, 'Inter', system-ui, sans-serif);
}
groupenterboolean--ml-boolean-segmented-glass .ml-error-text {
  color: var(--ml-error, #ffb4ab);
  font-family: var(--ml-font-family, 'Inter', system-ui, sans-serif);
}
groupenterboolean--ml-boolean-segmented-glass .ml-segmented-track {
  border-radius: var(--ml-radius-md, 12px);
}
groupenterboolean--ml-boolean-segmented-glass .ml-segmented-option {
  position: relative;
  overflow: hidden;
  background: var(--ml-surface, rgba(255, 255, 255, 0.1));
  color: var(--ml-on-surface, rgba(255, 255, 255, 0.95));
  font-family: var(--ml-font-family, 'Inter', system-ui, sans-serif);
  font-weight: var(--ml-font-weight-medium, 600);
  border: var(--ml-border-width, 1px) var(--ml-border-style, solid) var(--ml-outline-variant, rgba(255, 255, 255, 0.25));
  border-radius: var(--ml-radius-md, 12px);
  backdrop-filter: blur(var(--ml-backdrop-blur, 10px));
  -webkit-backdrop-filter: blur(var(--ml-backdrop-blur, 10px));
  box-shadow: var(--ml-shadow-1, 0 4px 18px rgba(0, 0, 0, 0.18));
  transition: background var(--ml-transition, 250ms ease), border-color var(--ml-transition, 250ms ease), color var(--ml-transition, 250ms ease), box-shadow var(--ml-transition, 250ms ease), transform 120ms ease;
  cursor: pointer;
}
groupenterboolean--ml-boolean-segmented-glass .ml-segmented-option::before {
  content: '';
  position: absolute;
  inset: 0;
  border-radius: inherit;
  border-top: 1px solid rgba(255, 255, 255, 0.5);
  border-left: 1px solid rgba(255, 255, 255, 0.25);
  pointer-events: none;
}
groupenterboolean--ml-boolean-segmented-glass .ml-segmented-option:focus {
  outline: none;
  box-shadow: 0 0 0 var(--ml-focus-ring-width, 3px) var(--ml-focus-ring-color, rgba(199, 210, 254, 0.3)), var(--ml-shadow-1, 0 4px 18px rgba(0, 0, 0, 0.18));
}
groupenterboolean--ml-boolean-segmented-glass .ml-segmented-option:hover:not(.ml-disabled):not(.ml-segmented-option-active) {
  background: rgba(255, 255, 255, 0.18);
  box-shadow: var(--ml-shadow-2, 0 6px 24px rgba(0, 0, 0, 0.26));
}
groupenterboolean--ml-boolean-segmented-glass .ml-segmented-option:not(.ml-disabled):active {
  transform: translateY(1px);
}
groupenterboolean--ml-boolean-segmented-glass .ml-segmented-option-active {
  background: var(--ml-primary, rgba(99, 102, 241, 0.55));
  color: var(--ml-on-primary, #ffffff);
  border-color: rgba(139, 142, 255, 0.6);
  box-shadow: var(--ml-shadow-2, 0 6px 24px rgba(0, 0, 0, 0.26)), inset 0 1px 0 rgba(255, 255, 255, 0.2);
}
groupenterboolean--ml-boolean-segmented-glass .ml-segmented-option-error {
  border-color: var(--ml-outline-error, rgba(255, 120, 120, 0.85));
}
groupenterboolean--ml-boolean-segmented-glass .ml-disabled {
  opacity: var(--ml-disabled-opacity, 0.5);
  cursor: not-allowed;
  pointer-events: none;
}
`);
    }
};
BooleanSegmentedMoleculeGlass = __decorate([
    customElement('groupenterboolean--ml-boolean-segmented-glass')
], BooleanSegmentedMoleculeGlass);
export { BooleanSegmentedMoleculeGlass };
