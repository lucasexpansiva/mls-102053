var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102053_/l2/molecules/groupenterboolean/ml-toggle-switch-glass.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// TOGGLE SWITCH — GLASSMORPHISM (mls-102053)
// =============================================================================
// Skill Group: groupEnterBoolean
// Casca (estratégia D): herda tudo de ToggleSwitchMolecule (mls-102040),
// inclusive render() — o markup base emite classes semânticas ml-*; a aparência
// vem do .less irmão, escopado sob esta tag.
// This molecule does NOT contain business logic.
import { customElement } from 'lit/decorators.js';
import { ToggleSwitchMolecule } from '/_102040_/l2/molecules/groupenterboolean/ml-toggle-switch.js';
let ToggleSwitchMoleculeGlass = class ToggleSwitchMoleculeGlass extends ToggleSwitchMolecule {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(`groupenterboolean--ml-toggle-switch-glass {
  --ml-font-family: 'Inter', system-ui, sans-serif;
  --ml-font-weight-medium: 600;
  --ml-radius-full: 9999px;
  --ml-border-width: 1px;
  --ml-border-style: solid;
  --ml-outline-variant: rgba(255, 255, 255, 0.25);
  --ml-outline-focus: rgba(199, 210, 254, 0.9);
  --ml-outline-error: rgba(255, 120, 120, 0.85);
  --ml-primary: rgba(99, 102, 241, 0.75);
  --ml-on-primary: #ffffff;
  --ml-surface: rgba(255, 255, 255, 0.9);
  --ml-on-surface: rgba(255, 255, 255, 0.95);
  --ml-on-surface-muted: rgba(255, 255, 255, 0.55);
  --ml-error: #ffb4ab;
  --ml-shadow-1: 0 4px 18px rgba(0, 0, 0, 0.18);
  --ml-transition: 250ms ease;
  --ml-focus-ring-width: 3px;
  --ml-focus-ring-color: rgba(199, 210, 254, 0.3);
  --ml-disabled-opacity: 0.5;
  --ml-backdrop-blur: 10px;
}
groupenterboolean--ml-toggle-switch-glass .ml-label {
  font-family: var(--ml-font-family, 'Inter', system-ui, sans-serif);
  font-weight: var(--ml-font-weight-medium, 600);
  color: var(--ml-on-surface, rgba(255, 255, 255, 0.95));
}
groupenterboolean--ml-toggle-switch-glass .ml-helper {
  color: var(--ml-on-surface-muted, rgba(255, 255, 255, 0.55));
  font-family: var(--ml-font-family, 'Inter', system-ui, sans-serif);
}
groupenterboolean--ml-toggle-switch-glass .ml-error-text {
  color: var(--ml-error, #ffb4ab);
  font-family: var(--ml-font-family, 'Inter', system-ui, sans-serif);
}
groupenterboolean--ml-toggle-switch-glass .ml-text {
  color: var(--ml-on-surface, rgba(255, 255, 255, 0.95));
  font-family: var(--ml-font-family, 'Inter', system-ui, sans-serif);
}
groupenterboolean--ml-toggle-switch-glass .ml-toggle-track {
  background: rgba(255, 255, 255, 0.1);
  border: var(--ml-border-width, 1px) var(--ml-border-style, solid) var(--ml-outline-variant, rgba(255, 255, 255, 0.25));
  border-radius: var(--ml-radius-full, 9999px);
  backdrop-filter: blur(var(--ml-backdrop-blur, 10px));
  -webkit-backdrop-filter: blur(var(--ml-backdrop-blur, 10px));
  box-shadow: var(--ml-shadow-1, 0 4px 18px rgba(0, 0, 0, 0.18)), inset 0 1px 0 rgba(255, 255, 255, 0.2);
  transition: background var(--ml-transition, 250ms ease), border-color var(--ml-transition, 250ms ease), box-shadow var(--ml-transition, 250ms ease);
}
groupenterboolean--ml-toggle-switch-glass .ml-toggle-track:focus {
  outline: none;
  box-shadow: 0 0 0 var(--ml-focus-ring-width, 3px) var(--ml-focus-ring-color, rgba(199, 210, 254, 0.3)), var(--ml-shadow-1, 0 4px 18px rgba(0, 0, 0, 0.18)), inset 0 1px 0 rgba(255, 255, 255, 0.2);
}
groupenterboolean--ml-toggle-switch-glass .ml-toggle-track:not(.ml-disabled):hover {
  background: rgba(255, 255, 255, 0.16);
  border-color: rgba(255, 255, 255, 0.38);
}
groupenterboolean--ml-toggle-switch-glass .ml-toggle-track-on {
  background: var(--ml-primary, rgba(99, 102, 241, 0.75));
  border-color: rgba(99, 102, 241, 0.55);
  box-shadow: 0 4px 18px rgba(99, 102, 241, 0.28), inset 0 1px 0 rgba(255, 255, 255, 0.25);
}
groupenterboolean--ml-toggle-switch-glass .ml-toggle-track-on:not(.ml-disabled):hover {
  background: rgba(99, 102, 241, 0.88);
  border-color: rgba(99, 102, 241, 0.7);
}
groupenterboolean--ml-toggle-switch-glass .ml-toggle-track-error {
  border-color: var(--ml-outline-error, rgba(255, 120, 120, 0.85));
}
groupenterboolean--ml-toggle-switch-glass .ml-toggle-thumb {
  background: var(--ml-surface, rgba(255, 255, 255, 0.9));
  border-radius: var(--ml-radius-full, 9999px);
  box-shadow: 0 1px 4px rgba(0, 0, 0, 0.22);
  transition: transform var(--ml-transition, 250ms ease);
}
groupenterboolean--ml-toggle-switch-glass .ml-disabled {
  opacity: var(--ml-disabled-opacity, 0.5);
  cursor: not-allowed;
  pointer-events: none;
}
`);
    }
};
ToggleSwitchMoleculeGlass = __decorate([
    customElement('groupenterboolean--ml-toggle-switch-glass')
], ToggleSwitchMoleculeGlass);
export { ToggleSwitchMoleculeGlass };
