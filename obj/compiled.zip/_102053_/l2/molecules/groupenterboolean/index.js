var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102053_/l2/molecules/groupenterboolean/index.ts" enhancement="_102020_/l2/enhancementAura"/>
import { html } from 'lit';
import { customElement, state } from 'lit/decorators.js';
import { StateLitElement } from '/_102029_/l2/stateLitElement.js';
import '/_102053_/l2/molecules/groupenterboolean/ml-boolean-segmented-glass';
import '/_102053_/l2/molecules/groupenterboolean/ml-toggle-switch-glass';
let GroupEnterBooleanIndex = class GroupEnterBooleanIndex extends StateLitElement {
    constructor() {
        super(...arguments);
        // ── Showcase card states ─────────────────────────────────────────────
        this.card1 = false;
        this.card2 = false;
    }
    render() {
        return html `
      <div class="font-sans" style="min-height:100vh; background: linear-gradient(135deg, #0f172a 0%, #312e81 45%, #7e22ce 100%);">
        ${this.renderHero()}
        ${this.renderShowcaseCards()}
        ${this.renderReferenceTable()}
      </div>
    `;
    }
    // ===========================================================================
    // HERO
    // ===========================================================================
    renderHero() {
        return html `
      <header class="px-8 py-20 text-center" style="background: rgba(255,255,255,0.06); border-bottom: 1px solid rgba(255,255,255,0.25); backdrop-filter: blur(10px);">
        <span class="inline-block px-3 py-1 rounded-full text-xs font-semibold uppercase tracking-widest mb-6" style="background: rgba(99,102,241,0.25); color: rgba(255,255,255,0.9); border: 1px solid rgba(255,255,255,0.25);">
          groupEnterBoolean
        </span>
        <h1 class="text-5xl font-bold mb-5 tracking-tight" style="color: rgba(255,255,255,0.96); font-family: 'Inter', system-ui, sans-serif; font-weight: 600;">
          Enter Boolean
        </h1>
        <p class="text-lg max-w-2xl mx-auto leading-relaxed" style="color: rgba(255,255,255,0.72);">
          Allows the user to input a true/false decision. Value is boolean — starts as false until the user changes it. Supports Label and Helper slot tags. Implementations are toggle/switch and checkbox, fully interchangeable by swapping the component tag.
        </p>
      </header>
    `;
    }
    // ===========================================================================
    // SHOWCASE CARDS
    // ===========================================================================
    renderShowcaseCards() {
        return html `
      <section class="px-8 py-12" style="border-bottom: 1px solid rgba(255,255,255,0.25);">
        <div class="max-w-2xl mx-auto flex flex-col gap-5">

          <div class="rounded-2xl" style="background: rgba(255,255,255,0.08); border: 1px solid rgba(255,255,255,0.25); box-shadow: 0 4px 18px rgba(0,0,0,0.18); backdrop-filter: blur(10px);">
            <div class="h-1 bg-violet-500 rounded-t-2xl"></div>
            <div class="p-6">
              <div class="flex items-center justify-between mb-1">
                <p class="text-sm font-bold" style="color: rgba(255,255,255,0.96);">Boolean Segmented</p>
                <code class="text-xs px-2 py-0.5 rounded" style="background: rgba(255,255,255,0.1); color: rgba(255,255,255,0.65);">groupenterboolean--ml-boolean-segmented-glass</code>
              </div>
              <p class="text-xs mb-5" style="color: rgba(255,255,255,0.55);">Segmented control for an explicit true/false choice</p>
              <groupenterboolean--ml-boolean-segmented-glass
                name="card-1"
                .value=${this.card1}
                .isEditing=${true}
                @change=${(e) => { this.card1 = e.detail.value; }}>
                <Label>Enable feature flag</Label>
                <Helper>Choose yes or no to toggle this setting</Helper>
              </groupenterboolean--ml-boolean-segmented-glass>
            </div>
          </div>

          <div class="rounded-2xl" style="background: rgba(255,255,255,0.08); border: 1px solid rgba(255,255,255,0.25); box-shadow: 0 4px 18px rgba(0,0,0,0.18); backdrop-filter: blur(10px);">
            <div class="h-1 bg-emerald-500 rounded-t-2xl"></div>
            <div class="p-6">
              <div class="flex items-center justify-between mb-1">
                <p class="text-sm font-bold" style="color: rgba(255,255,255,0.96);">Toggle Switch</p>
                <code class="text-xs px-2 py-0.5 rounded" style="background: rgba(255,255,255,0.1); color: rgba(255,255,255,0.65);">groupenterboolean--ml-toggle-switch-glass</code>
              </div>
              <p class="text-xs mb-5" style="color: rgba(255,255,255,0.55);">Classic on/off switch for binary settings</p>
              <groupenterboolean--ml-toggle-switch-glass
                name="card-2"
                .value=${this.card2}
                .isEditing=${true}
                @change=${(e) => { this.card2 = e.detail.value; }}>
                <Label>Enable notifications</Label>
                <Helper>Receive alerts when something important happens</Helper>
              </groupenterboolean--ml-toggle-switch-glass>
            </div>
          </div>

        </div>
      </section>
    `;
    }
    // ===========================================================================
    // REFERENCE TABLE
    // ===========================================================================
    renderReferenceTable() {
        const rows = [
            { scenario: 'Explicit yes/no choice with equal visual weight on both options', segmented: true, toggle: false },
            { scenario: 'Compact on/off setting in a dense settings panel', segmented: false, toggle: true },
            { scenario: 'Binary preference that should feel like a physical switch', segmented: false, toggle: true },
            { scenario: 'Form field where both true and false need equal prominence', segmented: true, toggle: false },
            { scenario: 'Interchangeable true/false input — same contract, swap the tag', segmented: true, toggle: true },
        ];
        const headers = [
            { label: 'Segmented', cls: 'text-violet-300' },
            { label: 'Toggle', cls: 'text-emerald-300' },
        ];
        return html `
      <section class="px-8 py-20" style="border-top: 1px solid rgba(255,255,255,0.25);">
        <div class="max-w-5xl mx-auto">
          <h2 class="text-2xl font-bold mb-2" style="color: rgba(255,255,255,0.96); font-family: 'Inter', system-ui, sans-serif; font-weight: 600;">Quick reference</h2>
          <p class="text-sm mb-8" style="color: rgba(255,255,255,0.65);">Pick segmented when both options need equal weight; pick toggle for compact on/off settings — both share the same boolean contract.</p>
          <div class="rounded-2xl overflow-hidden" style="background: rgba(255,255,255,0.08); border: 1px solid rgba(255,255,255,0.25); box-shadow: 0 4px 18px rgba(0,0,0,0.18); backdrop-filter: blur(10px);">
            <table class="w-full text-sm">
              <thead>
                <tr style="background: rgba(255,255,255,0.06); border-bottom: 1px solid rgba(255,255,255,0.25);">
                  <th class="text-left px-5 py-3.5 text-xs font-semibold uppercase tracking-wide w-3/4" style="color: rgba(255,255,255,0.55);">Scenario</th>
                  ${headers.map(h => html `
                    <th class="px-4 py-3.5 text-xs font-semibold uppercase tracking-wide ${h.cls}">${h.label}</th>
                  `)}
                </tr>
              </thead>
              <tbody>
                ${rows.map((row, i) => html `
                  <tr class="last:border-0" style="${i % 2 !== 0 ? 'background: rgba(255,255,255,0.04);' : ''} border-bottom: 1px solid rgba(255,255,255,0.12);">
                    <td class="px-5 py-3.5" style="color: rgba(255,255,255,0.82);">${row.scenario}</td>
                    ${[row.segmented, row.toggle].map(ok => html `
                      <td class="px-4 py-3.5 text-center">
                        ${ok
            ? html `<span class="inline-flex items-center justify-center w-6 h-6 rounded-full text-xs font-bold" style="background: rgba(16,185,129,0.2); color: #34d399;">✓</span>`
            : html `<span class="text-sm" style="color: rgba(255,255,255,0.25);">—</span>`}
                      </td>
                    `)}
                  </tr>
                `)}
              </tbody>
            </table>
          </div>
        </div>
      </section>
    `;
    }
};
__decorate([
    state()
], GroupEnterBooleanIndex.prototype, "card1", void 0);
__decorate([
    state()
], GroupEnterBooleanIndex.prototype, "card2", void 0);
GroupEnterBooleanIndex = __decorate([
    customElement('molecules--groupenterboolean--index-102053')
], GroupEnterBooleanIndex);
export { GroupEnterBooleanIndex };
