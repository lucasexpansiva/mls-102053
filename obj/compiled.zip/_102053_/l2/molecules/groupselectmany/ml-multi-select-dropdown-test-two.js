var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102053_/l2/molecules/groupselectmany/ml-multi-select-dropdown-test-two.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// MULTI SELECT DROPDOWN TEST TWO MOLECULE
// =============================================================================
// Skill Group: groupSelectMany
// This molecule does NOT contain business logic.
import { html, nothing } from 'lit';
import { customElement, state } from 'lit/decorators.js';
import { unsafeHTML } from 'lit/directives/unsafe-html.js';
import { render as litRender } from 'lit';
import { propertyDataSource } from '/_102029_/l2/collabDecorators.js';
import { MoleculeAuraElement } from '/_102033_/l2/moleculeBase.js';
import { cn } from '/_102033_/l2/cn.js';
/// **collab_i18n_start**
const message_en = {
    placeholder: 'Select one or more options',
    empty: 'No options available',
    loading: 'Loading...',
    minSelection: 'Select at least {count} items',
};
const messages = {
    en: message_en,
};
let MlMultiSelectDropdownTestTwoMolecule = class MlMultiSelectDropdownTestTwoMolecule extends MoleculeAuraElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`groupselectmany--ml-multi-select-dropdown-test-two .ml-label {
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
  font-weight: var(--ml-font-weight-medium, 500);
  color: var(--ml-on-surface, #1c1b1f);
}
groupselectmany--ml-multi-select-dropdown-test-two .ml-helper {
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
  color: var(--ml-on-surface-muted, #49454f);
}
groupselectmany--ml-multi-select-dropdown-test-two .ml-error-text {
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
  color: var(--ml-error, #ef4444);
}
groupselectmany--ml-multi-select-dropdown-test-two .ml-text {
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
  color: var(--ml-on-surface, #1c1b1f);
}
groupselectmany--ml-multi-select-dropdown-test-two .ml-text-muted {
  color: var(--ml-on-surface-muted, #49454f);
}
groupselectmany--ml-multi-select-dropdown-test-two .ml-text-faint {
  color: var(--ml-on-surface-faint, #79747e);
}
groupselectmany--ml-multi-select-dropdown-test-two .ml-disabled {
  opacity: var(--ml-disabled-opacity, 0.5);
  cursor: not-allowed;
  pointer-events: none;
}
groupselectmany--ml-multi-select-dropdown-test-two .ml-spinner {
  width: var(--ml-spinner-size, 16px);
  height: var(--ml-spinner-size, 16px);
  border-radius: var(--ml-radius-full, 9999px);
  border: var(--ml-border-width, 1px) var(--ml-border-style, solid) var(--ml-outline-variant, #e2e8f0);
  border-top-color: var(--ml-primary, #3b82f6);
  display: inline-block;
}
groupselectmany--ml-multi-select-dropdown-test-two .ml-msd-trigger {
  background: var(--ml-surface, #ffffff);
  border: var(--ml-border-width, 1px) var(--ml-border-style, solid) var(--ml-outline-variant, #e2e8f0);
  border-radius: var(--ml-radius-sm, 6px);
  color: var(--ml-on-surface, #1c1b1f);
  transition: border-color var(--ml-transition, 200ms ease), box-shadow var(--ml-transition, 200ms ease), background-color var(--ml-transition, 200ms ease);
}
groupselectmany--ml-multi-select-dropdown-test-two .ml-msd-trigger:hover {
  background: var(--ml-surface-dim, #f5f5f5);
}
groupselectmany--ml-multi-select-dropdown-test-two .ml-msd-trigger:focus-visible {
  border-color: var(--ml-outline-focus, #3b82f6);
  box-shadow: 0 0 0 var(--ml-focus-ring-width, 2px) var(--ml-focus-ring-color, rgba(59, 130, 246, 0.4));
  outline: none;
}
groupselectmany--ml-multi-select-dropdown-test-two .ml-msd-trigger-error {
  border-color: var(--ml-outline-error, #ef4444) !important;
}
groupselectmany--ml-multi-select-dropdown-test-two .ml-msd-trigger-has-value {
  font-weight: var(--ml-font-weight-medium, 500);
}
groupselectmany--ml-multi-select-dropdown-test-two .ml-msd-search-wrapper {
  border-bottom: var(--ml-border-width, 1px) var(--ml-border-style, solid) var(--ml-outline-variant, #e2e8f0);
}
groupselectmany--ml-multi-select-dropdown-test-two .ml-msd-search-input {
  background: var(--ml-surface, #ffffff);
  border: var(--ml-border-width, 1px) var(--ml-border-style, solid) var(--ml-outline-variant, #e2e8f0);
  border-radius: var(--ml-radius-sm, 6px);
  color: var(--ml-on-surface, #1c1b1f);
  transition: border-color var(--ml-transition, 200ms ease), box-shadow var(--ml-transition, 200ms ease);
}
groupselectmany--ml-multi-select-dropdown-test-two .ml-msd-search-input:focus-visible {
  border-color: var(--ml-outline-focus, #3b82f6);
  box-shadow: 0 0 0 var(--ml-focus-ring-width, 2px) var(--ml-focus-ring-color, rgba(59, 130, 246, 0.4));
  outline: none;
}
groupselectmany--ml-multi-select-dropdown-test-two .ml-msd-empty {
  color: var(--ml-on-surface-muted, #49454f);
}
groupselectmany--ml-multi-select-dropdown-test-two .ml-msd-loading {
  background: var(--ml-surface-dim, #f5f5f5);
  border: var(--ml-border-width, 1px) var(--ml-border-style, solid) var(--ml-outline-variant, #e2e8f0);
  border-radius: var(--ml-radius-sm, 6px);
}
groupselectmany--ml-multi-select-dropdown-test-two .ml-msd-view {
  color: var(--ml-on-surface, #1c1b1f);
}
groupselectmany--ml-multi-select-dropdown-test-two .ml-msd-tag {
  background: var(--ml-surface-dim, #f5f5f5);
  color: var(--ml-on-surface, #1c1b1f);
  border: var(--ml-border-width, 1px) var(--ml-border-style, solid) var(--ml-outline-variant, #e2e8f0);
  border-radius: var(--ml-radius-full, 9999px);
}
div[data-widget="groupselectmany--ml-multi-select-dropdown-test-two"] .ml-msd-panel {
  background: var(--ml-surface, #ffffff);
  border: var(--ml-border-width, 1px) var(--ml-border-style, solid) var(--ml-outline-variant, #e2e8f0);
  border-radius: var(--ml-radius-md, 8px);
  box-shadow: var(--ml-shadow-2, 0 4px 6px rgba(0, 0, 0, 0.1));
}
div[data-widget="groupselectmany--ml-multi-select-dropdown-test-two"] .ml-msd-item {
  color: var(--ml-on-surface, #1c1b1f);
  transition: background-color var(--ml-transition, 200ms ease), color var(--ml-transition, 200ms ease);
}
div[data-widget="groupselectmany--ml-multi-select-dropdown-test-two"] .ml-msd-item:hover {
  background: var(--ml-surface-dim, #f5f5f5);
}
div[data-widget="groupselectmany--ml-multi-select-dropdown-test-two"] .ml-msd-item-selected {
  background: var(--ml-primary, #3b82f6);
  color: var(--ml-on-primary, #ffffff);
}
div[data-widget="groupselectmany--ml-multi-select-dropdown-test-two"] .ml-msd-item-disabled {
  background: var(--ml-surface, #ffffff);
}
div[data-widget="groupselectmany--ml-multi-select-dropdown-test-two"] .ml-msd-item-marker {
  border-radius: var(--ml-radius-sm, 6px);
  border: var(--ml-border-width, 1px) var(--ml-border-style, solid) var(--ml-outline-variant, #e2e8f0);
  color: var(--ml-on-primary, #ffffff);
}
div[data-widget="groupselectmany--ml-multi-select-dropdown-test-two"] .ml-msd-item-marker-selected {
  background: var(--ml-primary, #3b82f6);
  border-color: var(--ml-primary, #3b82f6);
  color: var(--ml-on-primary, #ffffff);
}
div[data-widget="groupselectmany--ml-multi-select-dropdown-test-two"] .ml-msd-item-marker-empty {
  background: transparent;
  color: transparent;
}
div[data-widget="groupselectmany--ml-multi-select-dropdown-test-two"] .ml-msd-group-label {
  color: var(--ml-on-surface-muted, #49454f);
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
  font-weight: var(--ml-font-weight-medium, 500);
}
`);
        this.msg = messages.en;
        this.uid = `ml-msd-${Math.random().toString(36).slice(2, 9)}`;
        // ===========================================================================
        // SLOT TAGS
        // ==========================================================================
        this.slotTags = ['Label', 'Helper', 'Trigger', 'Item', 'Cell', 'Column', 'Group', 'Empty'];
        // ===========================================================================
        // PROPERTIES — From Contract
        // ==========================================================================
        this.value = '';
        this.error = '';
        this.name = '';
        this.placeholder = '';
        this.searchable = false;
        this.minSelection = 0;
        this.maxSelection = 0;
        this.isEditing = true;
        this.disabled = false;
        this.readonly = false;
        this.required = false;
        this.loading = false;
        // ===========================================================================
        // INTERNAL STATE
        // ==========================================================================
        this.isOpen = false;
        this.searchQuery = '';
        this.activeIndex = -1;
        // ===========================================================================
        // PORTAL
        // ==========================================================================
        this.portalContainer = null;
        this.portalWidgetName = 'groupselectmany--ml-multi-select-dropdown-test-two';
        this.boundUpdatePosition = () => this.updatePanelPosition();
        this.boundDocumentClick = (e) => this.handleDocumentClick(e);
        this.boundDocumentKeydown = (e) => this.handleDocumentKeydown(e);
        this.boundFocusOut = (e) => this.handleFocusOut(e);
    }
    // ===========================================================================
    // LIFECYCLE
    // ==========================================================================
    connectedCallback() {
        super.connectedCallback();
        this.addEventListener('focusout', this.boundFocusOut);
    }
    disconnectedCallback() {
        this.removeEventListener('focusout', this.boundFocusOut);
        this.destroyPortal();
        super.disconnectedCallback();
    }
    updated(changedProps) {
        if (changedProps.has('isEditing') || changedProps.has('disabled') || changedProps.has('readonly') || changedProps.has('loading')) {
            if (!this.isEditing || this.disabled || this.readonly || this.loading) {
                this.closePanel();
            }
        }
        if (changedProps.has('isOpen')) {
            if (this.isOpen) {
                this.createPortal();
                this.updateActiveIndexForItems();
            }
            else {
                this.destroyPortal();
            }
        }
        if (this.isOpen && this.portalContainer) {
            this.renderPortalContent();
            this.updatePanelPosition();
        }
        if (this.isOpen && changedProps.has('activeIndex')) {
            this.focusActiveItem();
        }
        if (changedProps.has('searchQuery')) {
            this.updateActiveIndexForItems();
        }
    }
    // ===========================================================================
    // EVENT HANDLERS
    // ==========================================================================
    handleTriggerClick() {
        if (!this.isEditing || this.disabled || this.readonly || this.loading)
            return;
        this.toggleOpen();
    }
    handleTriggerKeyDown(e) {
        if (!this.isEditing || this.disabled || this.readonly || this.loading)
            return;
        if (e.key === 'ArrowDown') {
            e.preventDefault();
            this.openPanel();
        }
        else if (e.key === 'Escape') {
            e.preventDefault();
            this.closePanel();
        }
    }
    handleSearchInput(e) {
        e.stopPropagation();
        const input = e.target;
        this.searchQuery = input.value;
    }
    handleItemToggle(item) {
        if (!this.isEditing || this.disabled || this.readonly || item.disabled)
            return;
        const selected = this.getSelectedSet();
        if (selected.has(item.value)) {
            selected.delete(item.value);
        }
        else {
            if (this.maxSelection > 0 && selected.size >= this.maxSelection)
                return;
            selected.add(item.value);
        }
        this.value = Array.from(selected).join(',');
        this.dispatchEvent(new CustomEvent('change', {
            bubbles: true,
            composed: true,
            detail: { value: this.value },
        }));
    }
    handleTriggerFocus() {
        if (!this.isEditing || this.disabled || this.readonly || this.loading)
            return;
        this.dispatchEvent(new CustomEvent('focus', { bubbles: true, composed: true }));
    }
    handleFocusOut(e) {
        const related = e.relatedTarget;
        if (!related || (!this.contains(related) && !this.portalContainer?.contains(related))) {
            this.dispatchEvent(new CustomEvent('blur', { bubbles: true, composed: true }));
            this.closePanel();
        }
    }
    handlePanelKeyDown(e) {
        if (!this.isOpen)
            return;
        if (e.key === 'Escape') {
            e.preventDefault();
            this.closePanel();
            this.focusTrigger();
            return;
        }
        if (e.key === 'ArrowDown') {
            e.preventDefault();
            this.moveActive(1);
            return;
        }
        if (e.key === 'ArrowUp') {
            e.preventDefault();
            this.moveActive(-1);
            return;
        }
        if (e.key === ' ' || e.key === 'Enter') {
            e.preventDefault();
            const items = this.getFlatItemsFiltered();
            const item = items[this.activeIndex];
            if (item)
                this.handleItemToggle(item);
        }
    }
    handleDocumentClick(e) {
        const target = e.target;
        if (!target || (!this.contains(target) && !this.portalContainer?.contains(target))) {
            this.closePanel();
        }
    }
    handleDocumentKeydown(e) {
        if (e.key === 'Escape') {
            this.closePanel();
        }
    }
    // ===========================================================================
    // PORTAL METHODS
    // ==========================================================================
    createPortal() {
        if (this.portalContainer)
            return;
        this.portalContainer = document.createElement('div');
        if (this.portalWidgetName) {
            this.portalContainer.setAttribute('data-widget', this.portalWidgetName);
        }
        document.body.appendChild(this.portalContainer);
        this.updatePanelPosition();
        this.renderPortalContent();
        window.addEventListener('scroll', this.boundUpdatePosition, true);
        window.addEventListener('resize', this.boundUpdatePosition);
        document.addEventListener('mousedown', this.boundDocumentClick);
        document.addEventListener('keydown', this.boundDocumentKeydown);
    }
    destroyPortal() {
        if (!this.portalContainer)
            return;
        window.removeEventListener('scroll', this.boundUpdatePosition, true);
        window.removeEventListener('resize', this.boundUpdatePosition);
        document.removeEventListener('mousedown', this.boundDocumentClick);
        document.removeEventListener('keydown', this.boundDocumentKeydown);
        this.portalContainer.remove();
        this.portalContainer = null;
    }
    updatePanelPosition() {
        if (!this.portalContainer)
            return;
        const trigger = this.querySelector('button[role="combobox"]');
        if (!trigger)
            return;
        const rect = trigger.getBoundingClientRect();
        Object.assign(this.portalContainer.style, {
            position: 'fixed',
            top: `${rect.bottom + 8}px`,
            left: `${rect.left}px`,
            width: `${rect.width}px`,
            zIndex: '9999',
        });
    }
    renderPortalContent() {
        if (!this.portalContainer)
            return;
        litRender(this.getPortalTemplate(), this.portalContainer);
    }
    openPanel() {
        if (this.isOpen || !this.isEditing || this.disabled || this.readonly || this.loading)
            return;
        this.isOpen = true;
    }
    closePanel() {
        if (!this.isOpen)
            return;
        this.isOpen = false;
    }
    toggleOpen() {
        if (this.isOpen) {
            this.closePanel();
        }
        else {
            this.openPanel();
        }
    }
    getPortalTemplate() {
        const groups = this.getGroupedItemsFiltered();
        const selected = this.getSelectedSet();
        const reachedMax = this.maxSelection > 0 && selected.size >= this.maxSelection;
        return html `
<div
class="${cn(this.getPanelClasses())}"
role="listbox"
aria-multiselectable="true"
@keydown=${this.handlePanelKeyDown}
>
${this.searchable ? this.renderSearchInput() : nothing}
${groups.length === 0
            ? this.renderEmptyState()
            : html `${groups.map(group => this.renderGroup(group, selected, reachedMax))}`}
</div>
`;
    }
    // ===========================================================================
    // RENDER
    // ==========================================================================
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        if (!this.isEditing) {
            return this.renderViewMode();
        }
        if (this.loading) {
            return html `
<div class="${cn('w-full', this.cssClass)}">
<div class="${this.getLoadingClasses()}">
<span class="ml-spinner"></span>
<span class="ml-text-muted">${this.msg.loading}</span>
</div>
</div>
`;
        }
        const labelId = `${this.uid}-label`;
        const helperId = `${this.uid}-helper`;
        const errorId = `${this.uid}-error`;
        const listboxId = `${this.uid}-listbox`;
        const selected = this.getSelectedSet();
        const errorText = this.getErrorText(selected.size);
        const describedBy = errorText
            ? errorId
            : this.hasSlot('Helper')
                ? helperId
                : undefined;
        return html `
<div class="${cn('w-full', this.cssClass)}">
${this.hasSlot('Label')
            ? html `
<div id="${labelId}" class="${cn('mb-2 text-sm ml-label', this.getSlotClass('Label'))}">
${unsafeHTML(this.getSlotContent('Label'))}
</div>
`
            : nothing}
<button
class="${cn(this.getTriggerClasses(!!errorText, selected.size > 0), this.getSlotClass('Trigger'))}"
role="combobox"
aria-haspopup="listbox"
aria-expanded="${this.isOpen ? 'true' : 'false'}"
aria-controls="${listboxId}"
aria-labelledby="${this.hasSlot('Label') ? labelId : ''}"
aria-describedby="${describedBy || ''}"
aria-invalid="${errorText ? 'true' : 'false'}"
aria-required="${this.required ? 'true' : 'false'}"
?disabled=${this.disabled || this.readonly}
@focus=${this.handleTriggerFocus}
@click=${this.handleTriggerClick}
@keydown=${this.handleTriggerKeyDown}
>
${this.renderTriggerContent(selected)}
</button>
${errorText
            ? html `<div id="${errorId}" class="${cn('mt-1 text-xs ml-error-text')}">${unsafeHTML(errorText)}</div>`
            : this.hasSlot('Helper')
                ? html `<div id="${helperId}" class="${cn('mt-1 text-xs ml-helper', this.getSlotClass('Helper'))}">${unsafeHTML(this.getSlotContent('Helper'))}</div>`
                : nothing}
</div>
`;
    }
    // ===========================================================================
    // RENDER PARTS
    // ==========================================================================
    renderTriggerContent(selected) {
        if (this.hasSlot('Trigger')) {
            return html `${unsafeHTML(this.getSlotContent('Trigger'))}`;
        }
        const items = this.getFlatItems();
        const selectedItems = items.filter(item => selected.has(item.value));
        const text = selectedItems.length > 0
            ? selectedItems.map(item => this.getPlainText(item.label)).join(', ')
            : (this.placeholder || this.msg.placeholder);
        const textClasses = selectedItems.length > 0 ? 'ml-text' : 'ml-text-faint';
        return html `<span class="${cn('truncate', textClasses)}">${text}</span>`;
    }
    renderSearchInput() {
        return html `
<div class="${this.getSearchWrapperClasses()}">
<input
class="${this.getSearchInputClasses()}"
type="text"
value="${this.searchQuery}"
placeholder="${this.msg.placeholder}"
@input=${this.handleSearchInput}
@change=${(e) => e.stopPropagation()}
/>
</div>
`;
    }
    renderGroup(group, selected, reachedMax) {
        const showLabel = group.label !== null && group.label !== '';
        return html `
${showLabel
            ? html `<div class="${this.getGroupLabelClasses()}">${unsafeHTML(group.label || '')}</div>`
            : nothing}
${group.items.map(item => this.renderItem(item, selected, reachedMax))}
`;
    }
    renderItem(item, selected, reachedMax) {
        const isSelected = selected.has(item.value);
        const isDisabled = item.disabled || (reachedMax && !isSelected);
        const optionClasses = this.getItemClasses(isSelected, isDisabled);
        return html `
<div
class="${optionClasses}"
role="option"
aria-selected="${isSelected ? 'true' : 'false'}"
aria-disabled="${isDisabled ? 'true' : 'false'}"
data-option
@mousedown=${(e) => e.preventDefault()}
@click=${() => this.handleItemToggle(item)}
.tabIndex=${this.activeIndex === item.index ? 0 : -1}
>
<span class="${this.getItemMarkerClasses(isSelected)}">${isSelected ? '✓' : ''}</span>
<span class="${this.getItemLabelClasses(isDisabled)}">${unsafeHTML(item.label)}</span>
</div>
`;
    }
    renderEmptyState() {
        const content = this.hasSlot('Empty') ? this.getSlotContent('Empty') : this.msg.empty;
        return html `<div class="${this.getEmptyClasses()}">${unsafeHTML(content)}</div>`;
    }
    renderViewMode() {
        const selected = this.getSelectedSet();
        const items = this.getFlatItems().filter(item => selected.has(item.value));
        return html `
<div class="${cn('w-full', this.cssClass)}">
${items.length === 0
            ? nothing
            : html `
<div class="${this.getViewContainerClasses()}">
${items.map(item => html `<span class="${this.getViewTagClasses()}">${unsafeHTML(item.label)}</span>`)}
</div>
`}
</div>
`;
    }
    // ===========================================================================
    // DATA HELPERS
    // ==========================================================================
    getSelectedSet() {
        const raw = String(this.value ?? '').trim();
        if (!raw)
            return new Set();
        return new Set(raw.split(',').map(v => v.trim()).filter(Boolean));
    }
    getFlatItems() {
        return this.getGroupedItems().flatMap(group => group.items);
    }
    getGroupedItems() {
        const groups = [];
        const children = Array.from(this.children);
        let currentUngrouped = null;
        let index = 0;
        for (const child of children) {
            const tag = child.tagName.toUpperCase();
            if (tag === 'GROUP') {
                const label = child.getAttribute('label') || '';
                const group = { label, items: [] };
                const items = Array.from(child.children);
                for (const itemEl of items) {
                    if (itemEl.tagName.toUpperCase() !== 'ITEM')
                        continue;
                    const parsed = this.parseItemElement(itemEl, index++);
                    if (parsed)
                        group.items.push(parsed);
                }
                if (group.items.length > 0)
                    groups.push(group);
                currentUngrouped = null;
            }
            else if (tag === 'ITEM') {
                if (!currentUngrouped) {
                    currentUngrouped = { label: null, items: [] };
                    groups.push(currentUngrouped);
                }
                const parsed = this.parseItemElement(child, index++);
                if (parsed)
                    currentUngrouped.items.push(parsed);
            }
        }
        return groups;
    }
    getGroupedItemsFiltered() {
        const query = this.searchQuery.trim().toLowerCase();
        if (!query)
            return this.getGroupedItems();
        const groups = this.getGroupedItems();
        const filtered = [];
        for (const group of groups) {
            const items = group.items.filter(item => this.getPlainText(item.label).toLowerCase().includes(query));
            if (items.length > 0) {
                filtered.push({ label: group.label, items });
            }
        }
        return filtered;
    }
    getFlatItemsFiltered() {
        return this.getGroupedItemsFiltered().flatMap(group => group.items);
    }
    parseItemElement(el, index) {
        const value = el.getAttribute('value') || '';
        if (!value)
            return null;
        const disabled = el.hasAttribute('disabled');
        const label = el.innerHTML || '';
        return { value, label, disabled, index };
    }
    getPlainText(content) {
        const div = document.createElement('div');
        div.innerHTML = content;
        return div.textContent || '';
    }
    getErrorText(selectedCount) {
        if (!this.isEditing)
            return '';
        if (this.error)
            return String(this.error);
        const minRequired = Math.max(this.minSelection || 0, this.required ? 1 : 0);
        if (minRequired > 0 && selectedCount < minRequired) {
            return this.msg.minSelection.replace('{count}', String(minRequired));
        }
        return '';
    }
    // ===========================================================================
    // FOCUS + NAVIGATION
    // ==========================================================================
    updateActiveIndexForItems() {
        const items = this.getFlatItemsFiltered();
        if (items.length === 0) {
            this.activeIndex = -1;
            return;
        }
        const current = items.find(item => item.index === this.activeIndex && !item.disabled);
        if (current)
            return;
        const firstEnabled = items.find(item => !item.disabled);
        this.activeIndex = firstEnabled ? firstEnabled.index : -1;
    }
    moveActive(delta) {
        const items = this.getFlatItemsFiltered();
        if (items.length === 0)
            return;
        const currentIndex = items.findIndex(item => item.index === this.activeIndex);
        let nextIndex = currentIndex;
        for (let i = 0; i < items.length; i++) {
            nextIndex = (nextIndex + delta + items.length) % items.length;
            if (!items[nextIndex].disabled)
                break;
        }
        this.activeIndex = items[nextIndex]?.index ?? -1;
    }
    focusActiveItem() {
        const container = this.portalContainer || this;
        const options = container.querySelectorAll('[data-option]');
        const target = Array.from(options).find(el => Number(el.tabIndex) === 0);
        if (target)
            target.focus();
    }
    focusTrigger() {
        const trigger = this.querySelector('button[role="combobox"]');
        if (trigger)
            trigger.focus();
    }
    // ===========================================================================
    // CLASS HELPERS
    // ==========================================================================
    getTriggerClasses(hasError, hasSelection) {
        return [
            'w-full flex items-center justify-between gap-2 px-3 py-2',
            'ml-msd-trigger',
            hasError ? 'ml-msd-trigger-error' : '',
            this.disabled || this.readonly ? 'ml-disabled' : 'cursor-pointer',
            hasSelection ? 'ml-msd-trigger-has-value' : '',
        ].filter(Boolean).join(' ');
    }
    getPanelClasses() {
        return [
            'w-full max-h-64 overflow-auto rounded-md p-2',
            'ml-msd-panel',
        ].filter(Boolean).join(' ');
    }
    getItemClasses(isSelected, isDisabled) {
        return [
            'flex w-full items-center gap-2 px-3 py-2 rounded-md',
            'ml-msd-item',
            isSelected ? 'ml-msd-item-selected' : '',
            isDisabled ? 'ml-disabled ml-msd-item-disabled' : 'cursor-pointer',
        ].filter(Boolean).join(' ');
    }
    getItemMarkerClasses(isSelected) {
        return [
            'flex h-4 w-4 items-center justify-center',
            'ml-msd-item-marker',
            isSelected ? 'ml-msd-item-marker-selected' : 'ml-msd-item-marker-empty',
        ].filter(Boolean).join(' ');
    }
    getItemLabelClasses(isDisabled) {
        return [
            'flex-1 truncate',
            'ml-text',
            isDisabled ? 'ml-text-muted' : '',
        ].filter(Boolean).join(' ');
    }
    getGroupLabelClasses() {
        return [
            'px-3 py-1 text-xs',
            'ml-msd-group-label',
        ].filter(Boolean).join(' ');
    }
    getSearchWrapperClasses() {
        return [
            'px-2 pb-2',
            'ml-msd-search-wrapper',
        ].filter(Boolean).join(' ');
    }
    getSearchInputClasses() {
        return [
            'w-full px-3 py-2 text-sm',
            'ml-msd-search-input',
        ].filter(Boolean).join(' ');
    }
    getEmptyClasses() {
        return [
            'px-3 py-2 text-sm',
            'ml-msd-empty',
        ].filter(Boolean).join(' ');
    }
    getLoadingClasses() {
        return [
            'flex items-center gap-2 px-3 py-2 rounded-md',
            'ml-msd-loading',
        ].filter(Boolean).join(' ');
    }
    getViewContainerClasses() {
        return [
            'flex flex-wrap gap-2',
            'ml-msd-view',
        ].filter(Boolean).join(' ');
    }
    getViewTagClasses() {
        return [
            'px-2 py-1 rounded-full text-xs',
            'ml-msd-tag',
        ].filter(Boolean).join(' ');
    }
};
__decorate([
    propertyDataSource({ type: String })
], MlMultiSelectDropdownTestTwoMolecule.prototype, "value", void 0);
__decorate([
    propertyDataSource({ type: String })
], MlMultiSelectDropdownTestTwoMolecule.prototype, "error", void 0);
__decorate([
    propertyDataSource({ type: String })
], MlMultiSelectDropdownTestTwoMolecule.prototype, "name", void 0);
__decorate([
    propertyDataSource({ type: String })
], MlMultiSelectDropdownTestTwoMolecule.prototype, "placeholder", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MlMultiSelectDropdownTestTwoMolecule.prototype, "searchable", void 0);
__decorate([
    propertyDataSource({ type: Number, attribute: 'min-selection' })
], MlMultiSelectDropdownTestTwoMolecule.prototype, "minSelection", void 0);
__decorate([
    propertyDataSource({ type: Number, attribute: 'max-selection' })
], MlMultiSelectDropdownTestTwoMolecule.prototype, "maxSelection", void 0);
__decorate([
    propertyDataSource({ type: Boolean, attribute: 'is-editing' })
], MlMultiSelectDropdownTestTwoMolecule.prototype, "isEditing", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MlMultiSelectDropdownTestTwoMolecule.prototype, "disabled", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MlMultiSelectDropdownTestTwoMolecule.prototype, "readonly", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MlMultiSelectDropdownTestTwoMolecule.prototype, "required", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MlMultiSelectDropdownTestTwoMolecule.prototype, "loading", void 0);
__decorate([
    state()
], MlMultiSelectDropdownTestTwoMolecule.prototype, "isOpen", void 0);
__decorate([
    state()
], MlMultiSelectDropdownTestTwoMolecule.prototype, "searchQuery", void 0);
__decorate([
    state()
], MlMultiSelectDropdownTestTwoMolecule.prototype, "activeIndex", void 0);
MlMultiSelectDropdownTestTwoMolecule = __decorate([
    customElement('groupselectmany--ml-multi-select-dropdown-test-two')
], MlMultiSelectDropdownTestTwoMolecule);
export { MlMultiSelectDropdownTestTwoMolecule };
