var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102053_/l2/molecules/groupselectmany/ml-multi-checkbox-list-glass.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// MULTI CHECKBOX LIST — GLASSMORPHISM (mls-102053)
// =============================================================================
// Skill Group: groupSelectMany
// Casca (estratégia D): herda tudo de MlMultiCheckboxListMolecule (mls-102040),
// inclusive render() — o markup base emite classes semânticas ml-*; a aparência
// vem do .less irmão, escopado sob esta tag.
// This molecule does NOT contain business logic.
import { customElement } from 'lit/decorators.js';
import { MlMultiCheckboxListMolecule } from '/_102040_/l2/molecules/groupselectmany/ml-multi-checkbox-list.js';
let MlMultiCheckboxListMoleculeGlass = class MlMultiCheckboxListMoleculeGlass extends MlMultiCheckboxListMolecule {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(`groupselectmany--ml-multi-checkbox-list-glass {
  --ml-font-family: 'Inter', system-ui, sans-serif;
  --ml-font-weight-medium: 600;
  --ml-radius-sm: 12px;
  --ml-radius-md: 12px;
  --ml-radius-lg: 14px;
  --ml-border-width: 1px;
  --ml-outline-variant: rgba(255, 255, 255, 0.25);
  --ml-outline-focus: rgba(199, 210, 254, 0.9);
  --ml-outline-error: rgba(255, 120, 120, 0.85);
  --ml-primary: rgba(99, 102, 241, 0.55);
  --ml-on-primary: #ffffff;
  --ml-surface: rgba(255, 255, 255, 0.1);
  --ml-surface-dim: rgba(30, 27, 75, 0.55);
  --ml-on-surface: rgba(255, 255, 255, 0.95);
  --ml-on-surface-muted: rgba(255, 255, 255, 0.55);
  --ml-error: #ffb4ab;
  --ml-shadow-1: 0 4px 18px rgba(0, 0, 0, 0.18);
  --ml-shadow-2: 0 6px 24px rgba(0, 0, 0, 0.26);
  --ml-transition: 250ms ease;
  --ml-focus-ring-width: 3px;
  --ml-focus-ring-color: rgba(199, 210, 254, 0.3);
  --ml-disabled-opacity: 0.5;
  --ml-backdrop-blur: 10px;
  --ml-backdrop-blur-strong: 18px;
}
groupselectmany--ml-multi-checkbox-list-glass .ml-label {
  font-family: var(--ml-font-family, 'Inter', system-ui, sans-serif);
  font-weight: var(--ml-font-weight-medium, 600);
  color: var(--ml-on-surface, rgba(255, 255, 255, 0.95));
}
groupselectmany--ml-multi-checkbox-list-glass .ml-helper {
  font-family: var(--ml-font-family, 'Inter', system-ui, sans-serif);
  color: var(--ml-on-surface-muted, rgba(255, 255, 255, 0.55));
}
groupselectmany--ml-multi-checkbox-list-glass .ml-error-text {
  font-family: var(--ml-font-family, 'Inter', system-ui, sans-serif);
  color: var(--ml-error, #ffb4ab);
}
groupselectmany--ml-multi-checkbox-list-glass .ml-text {
  font-family: var(--ml-font-family, 'Inter', system-ui, sans-serif);
  color: var(--ml-on-surface, rgba(255, 255, 255, 0.95));
}
groupselectmany--ml-multi-checkbox-list-glass .ml-text-muted {
  font-family: var(--ml-font-family, 'Inter', system-ui, sans-serif);
  color: var(--ml-on-surface-muted, rgba(255, 255, 255, 0.55));
}
groupselectmany--ml-multi-checkbox-list-glass .ml-disabled {
  opacity: var(--ml-disabled-opacity, 0.5);
  cursor: not-allowed;
  pointer-events: none;
}
groupselectmany--ml-multi-checkbox-list-glass .ml-checkbox-container {
  position: relative;
  border-radius: var(--ml-radius-md, 12px);
  border: var(--ml-border-width, 1px) solid var(--ml-outline-variant, rgba(255, 255, 255, 0.25));
  background: var(--ml-surface, rgba(255, 255, 255, 0.1));
  backdrop-filter: blur(var(--ml-backdrop-blur, 10px));
  -webkit-backdrop-filter: blur(var(--ml-backdrop-blur, 10px));
  box-shadow: var(--ml-shadow-1, 0 4px 18px rgba(0, 0, 0, 0.18));
  transition: border-color var(--ml-transition, 250ms ease), box-shadow var(--ml-transition, 250ms ease);
}
groupselectmany--ml-multi-checkbox-list-glass .ml-checkbox-container::before {
  content: '';
  position: absolute;
  inset: 0;
  border-radius: inherit;
  border-top: 1px solid rgba(255, 255, 255, 0.5);
  border-left: 1px solid rgba(255, 255, 255, 0.25);
  pointer-events: none;
}
groupselectmany--ml-multi-checkbox-list-glass .ml-checkbox-container-error {
  border-color: var(--ml-outline-error, rgba(255, 120, 120, 0.85));
  box-shadow: 0 0 0 var(--ml-focus-ring-width, 3px) rgba(255, 120, 120, 0.2), var(--ml-shadow-1, 0 4px 18px rgba(0, 0, 0, 0.18));
}
groupselectmany--ml-multi-checkbox-list-glass .ml-checkbox-item {
  font-family: var(--ml-font-family, 'Inter', system-ui, sans-serif);
  font-weight: var(--ml-font-weight-medium, 600);
  background: rgba(255, 255, 255, 0.06);
  border: var(--ml-border-width, 1px) solid var(--ml-outline-variant, rgba(255, 255, 255, 0.25));
  color: var(--ml-on-surface, rgba(255, 255, 255, 0.95));
  border-radius: var(--ml-radius-sm, 12px);
  transition: background var(--ml-transition, 250ms ease), border-color var(--ml-transition, 250ms ease), box-shadow var(--ml-transition, 250ms ease);
}
groupselectmany--ml-multi-checkbox-list-glass .ml-checkbox-item-checked {
  font-family: var(--ml-font-family, 'Inter', system-ui, sans-serif);
  font-weight: var(--ml-font-weight-medium, 600);
  background: rgba(99, 102, 241, 0.22);
  border: var(--ml-border-width, 1px) solid rgba(99, 102, 241, 0.65);
  color: var(--ml-on-surface, rgba(255, 255, 255, 0.95));
  border-radius: var(--ml-radius-sm, 12px);
  transition: background var(--ml-transition, 250ms ease), border-color var(--ml-transition, 250ms ease), box-shadow var(--ml-transition, 250ms ease);
}
groupselectmany--ml-multi-checkbox-list-glass .ml-checkbox-item-hover:hover {
  background: rgba(255, 255, 255, 0.12);
  border-color: rgba(255, 255, 255, 0.4);
  box-shadow: var(--ml-shadow-2, 0 6px 24px rgba(0, 0, 0, 0.26));
}
groupselectmany--ml-multi-checkbox-list-glass .ml-checkbox-focus:focus {
  outline: none;
  box-shadow: 0 0 0 var(--ml-focus-ring-width, 3px) var(--ml-focus-ring-color, rgba(199, 210, 254, 0.3));
}
groupselectmany--ml-multi-checkbox-list-glass .ml-checkbox-indicator {
  border-color: var(--ml-outline-variant, rgba(255, 255, 255, 0.25));
  background: rgba(255, 255, 255, 0.06);
  color: transparent;
  border-radius: 4px;
  transition: border-color var(--ml-transition, 250ms ease), background var(--ml-transition, 250ms ease);
}
groupselectmany--ml-multi-checkbox-list-glass .ml-checkbox-indicator-checked {
  border-color: rgba(99, 102, 241, 0.8);
  background: rgba(99, 102, 241, 0.55);
  color: var(--ml-on-primary, #ffffff);
  border-radius: 4px;
  transition: border-color var(--ml-transition, 250ms ease), background var(--ml-transition, 250ms ease);
}
groupselectmany--ml-multi-checkbox-list-glass .ml-checkbox-indicator-blocked {
  opacity: var(--ml-disabled-opacity, 0.5);
}
groupselectmany--ml-multi-checkbox-list-glass .ml-checkbox-search {
  font-family: var(--ml-font-family, 'Inter', system-ui, sans-serif);
  border: var(--ml-border-width, 1px) solid var(--ml-outline-variant, rgba(255, 255, 255, 0.25));
  border-radius: var(--ml-radius-sm, 12px);
  background: rgba(255, 255, 255, 0.08);
  backdrop-filter: blur(var(--ml-backdrop-blur, 10px));
  -webkit-backdrop-filter: blur(var(--ml-backdrop-blur, 10px));
  color: var(--ml-on-surface, rgba(255, 255, 255, 0.95));
  transition: border-color var(--ml-transition, 250ms ease), box-shadow var(--ml-transition, 250ms ease);
}
groupselectmany--ml-multi-checkbox-list-glass .ml-checkbox-search::placeholder {
  color: var(--ml-on-surface-muted, rgba(255, 255, 255, 0.55));
}
groupselectmany--ml-multi-checkbox-list-glass .ml-checkbox-search:focus {
  outline: none;
  border-color: var(--ml-outline-focus, rgba(199, 210, 254, 0.9));
  box-shadow: 0 0 0 var(--ml-focus-ring-width, 3px) var(--ml-focus-ring-color, rgba(199, 210, 254, 0.3));
}
`);
    }
};
MlMultiCheckboxListMoleculeGlass = __decorate([
    customElement('groupselectmany--ml-multi-checkbox-list-glass')
], MlMultiCheckboxListMoleculeGlass);
export { MlMultiCheckboxListMoleculeGlass };
