var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102053_/l2/molecules/groupnavigatesteps/ml-compact-step-indicator-glass.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// COMPACT STEP INDICATOR — GLASSMORPHISM (mls-102053)
// =============================================================================
// Skill Group: groupNavigateSteps
// Casca (estratégia D): herda tudo de CompactStepIndicatorMolecule (mls-102040),
// inclusive render() — o markup base emite classes semânticas ml-*; a aparência
// vem do .less irmão, escopado sob esta tag.
// This molecule does NOT contain business logic.
import { customElement } from 'lit/decorators.js';
import { CompactStepIndicatorMolecule } from '/_102040_/l2/molecules/groupnavigatesteps/ml-compact-step-indicator.js';
let CompactStepIndicatorMoleculeGlass = class CompactStepIndicatorMoleculeGlass extends CompactStepIndicatorMolecule {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(`groupnavigatesteps--ml-compact-step-indicator-glass {
  --ml-font-family: 'Inter', system-ui, sans-serif;
  --ml-font-weight-medium: 600;
  --ml-radius-sm: 12px;
  --ml-border-width: 1px;
  --ml-outline-variant: rgba(255, 255, 255, 0.25);
  --ml-outline-focus: rgba(199, 210, 254, 0.9);
  --ml-primary: rgba(99, 102, 241, 0.55);
  --ml-on-primary: #ffffff;
  --ml-surface: rgba(255, 255, 255, 0.1);
  --ml-on-surface: rgba(255, 255, 255, 0.95);
  --ml-on-surface-muted: rgba(255, 255, 255, 0.55);
  --ml-error: #ffb4ab;
  --ml-shadow-1: 0 4px 18px rgba(0, 0, 0, 0.18);
  --ml-transition: 250ms ease;
  --ml-disabled-opacity: 0.5;
  --ml-backdrop-blur: 10px;
}
groupnavigatesteps--ml-compact-step-indicator-glass .ml-label {
  font-family: var(--ml-font-family, 'Inter', system-ui, sans-serif);
  font-weight: var(--ml-font-weight-medium, 600);
  color: var(--ml-on-surface, rgba(255, 255, 255, 0.95));
}
groupnavigatesteps--ml-compact-step-indicator-glass .ml-text {
  font-family: var(--ml-font-family, 'Inter', system-ui, sans-serif);
  color: var(--ml-on-surface, rgba(255, 255, 255, 0.95));
}
groupnavigatesteps--ml-compact-step-indicator-glass .ml-text-muted {
  font-family: var(--ml-font-family, 'Inter', system-ui, sans-serif);
  color: var(--ml-on-surface-muted, rgba(255, 255, 255, 0.55));
}
groupnavigatesteps--ml-compact-step-indicator-glass .ml-error-text {
  font-family: var(--ml-font-family, 'Inter', system-ui, sans-serif);
  color: var(--ml-error, #ffb4ab);
}
groupnavigatesteps--ml-compact-step-indicator-glass .ml-step-number {
  font-family: var(--ml-font-family, 'Inter', system-ui, sans-serif);
  font-weight: var(--ml-font-weight-medium, 600);
  background-color: var(--ml-surface, rgba(255, 255, 255, 0.1));
  color: var(--ml-on-surface-muted, rgba(255, 255, 255, 0.55));
  border-color: var(--ml-outline-variant, rgba(255, 255, 255, 0.25));
  backdrop-filter: blur(var(--ml-backdrop-blur, 10px));
  -webkit-backdrop-filter: blur(var(--ml-backdrop-blur, 10px));
  box-shadow: var(--ml-shadow-1, 0 4px 18px rgba(0, 0, 0, 0.18));
  transition: background-color var(--ml-transition, 250ms ease), border-color var(--ml-transition, 250ms ease), box-shadow var(--ml-transition, 250ms ease), color var(--ml-transition, 250ms ease);
  outline: none;
}
groupnavigatesteps--ml-compact-step-indicator-glass .ml-step-number:focus-visible {
  box-shadow: 0 0 0 3px rgba(199, 210, 254, 0.3), var(--ml-shadow-1, 0 4px 18px rgba(0, 0, 0, 0.18));
  border-color: var(--ml-outline-focus, rgba(199, 210, 254, 0.9));
}
groupnavigatesteps--ml-compact-step-indicator-glass .ml-step-number:not(.ml-disabled):not(.ml-step-active):not(.ml-step-completed):hover {
  background-color: rgba(255, 255, 255, 0.18);
  border-color: rgba(255, 255, 255, 0.45);
  color: var(--ml-on-surface, rgba(255, 255, 255, 0.95));
}
groupnavigatesteps--ml-compact-step-indicator-glass .ml-step-number:not(.ml-disabled):active {
  transform: scale(0.93);
}
groupnavigatesteps--ml-compact-step-indicator-glass .ml-step-active {
  background-color: rgba(99, 102, 241, 0.3);
  color: rgba(199, 210, 254, 0.95);
  border-color: rgba(99, 102, 241, 0.75);
  box-shadow: 0 0 0 2px rgba(99, 102, 241, 0.35), var(--ml-shadow-1, 0 4px 18px rgba(0, 0, 0, 0.18));
}
groupnavigatesteps--ml-compact-step-indicator-glass .ml-step-completed {
  background-color: rgba(99, 102, 241, 0.22);
  color: rgba(199, 210, 254, 0.9);
  border-color: rgba(99, 102, 241, 0.55);
}
groupnavigatesteps--ml-compact-step-indicator-glass .ml-step-completed:not(.ml-disabled):hover {
  background-color: rgba(99, 102, 241, 0.35);
  border-color: rgba(99, 102, 241, 0.8);
}
groupnavigatesteps--ml-compact-step-indicator-glass .ml-step-loading-dot {
  background-color: rgba(199, 210, 254, 0.7);
}
groupnavigatesteps--ml-compact-step-indicator-glass .ml-disabled {
  opacity: var(--ml-disabled-opacity, 0.5);
  cursor: not-allowed;
  pointer-events: none;
}
`);
    }
};
CompactStepIndicatorMoleculeGlass = __decorate([
    customElement('groupnavigatesteps--ml-compact-step-indicator-glass')
], CompactStepIndicatorMoleculeGlass);
export { CompactStepIndicatorMoleculeGlass };
