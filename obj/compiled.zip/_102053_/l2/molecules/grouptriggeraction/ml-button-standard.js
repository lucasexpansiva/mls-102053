var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102053_/l2/molecules/grouptriggeraction/ml-button-standard.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// BUTTON STANDARD MOLECULE
// =============================================================================
// Skill Group: groupTriggerAction
// This molecule does NOT contain business logic.
import { html, nothing, svg } from 'lit';
import { customElement } from 'lit/decorators.js';
import { unsafeHTML } from 'lit/directives/unsafe-html.js';
import { propertyDataSource } from '/_102029_/l2/collabDecorators.js';
import { MoleculeAuraElement } from '/_102033_/l2/moleculeBase.js';
import { cn } from '/_102033_/l2/cn.js';
let ButtonStandardMolecule = class ButtonStandardMolecule extends MoleculeAuraElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`grouptriggeraction--ml-button-standard .ml-button {
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
  font-weight: var(--ml-font-weight-medium, 500);
  border-radius: var(--ml-radius-sm, 6px);
  transition: background var(--ml-transition, 200ms ease), box-shadow var(--ml-transition, 200ms ease), border-color var(--ml-transition, 200ms ease);
  cursor: pointer;
}
grouptriggeraction--ml-button-standard .ml-button:focus {
  outline: none;
  box-shadow: 0 0 0 var(--ml-focus-ring-width, 2px) var(--ml-focus-ring-color, rgba(59, 130, 246, 0.4));
}
grouptriggeraction--ml-button-standard .ml-button-primary {
  background: var(--ml-primary, #3b82f6);
  color: var(--ml-on-primary, #ffffff);
  border: var(--ml-border-width, 1px) var(--ml-border-style, solid) var(--ml-primary, #3b82f6);
  box-shadow: var(--ml-shadow-1, 0 1px 3px rgba(0, 0, 0, 0.1));
}
grouptriggeraction--ml-button-standard .ml-button-primary:hover {
  filter: brightness(1.1);
  box-shadow: var(--ml-shadow-2, 0 4px 6px rgba(0, 0, 0, 0.1));
}
grouptriggeraction--ml-button-standard .ml-button-primary:active {
  filter: brightness(0.9);
  box-shadow: var(--ml-shadow-0, none);
}
grouptriggeraction--ml-button-standard .ml-button-secondary {
  background: var(--ml-surface, #ffffff);
  color: var(--ml-on-surface, #1c1b1f);
  border: var(--ml-border-width, 1px) var(--ml-border-style, solid) var(--ml-outline-variant, #e2e8f0);
}
grouptriggeraction--ml-button-standard .ml-button-secondary:hover {
  background: var(--ml-surface-dim, #f5f5f5);
}
grouptriggeraction--ml-button-standard .ml-button-secondary:active {
  filter: brightness(0.95);
}
grouptriggeraction--ml-button-standard .ml-button-danger {
  background: var(--ml-error, #ef4444);
  color: var(--ml-on-error, #ffffff);
  border: var(--ml-border-width, 1px) var(--ml-border-style, solid) var(--ml-error, #ef4444);
  box-shadow: var(--ml-shadow-1, 0 1px 3px rgba(0, 0, 0, 0.1));
}
grouptriggeraction--ml-button-standard .ml-button-danger:hover {
  filter: brightness(1.1);
  box-shadow: var(--ml-shadow-2, 0 4px 6px rgba(0, 0, 0, 0.1));
}
grouptriggeraction--ml-button-standard .ml-button-danger:active {
  filter: brightness(0.9);
  box-shadow: var(--ml-shadow-0, none);
}
grouptriggeraction--ml-button-standard .ml-button-ghost {
  background: transparent;
  color: var(--ml-on-surface, #1c1b1f);
  border: var(--ml-border-width, 1px) var(--ml-border-style, solid) transparent;
}
grouptriggeraction--ml-button-standard .ml-button-ghost:hover {
  background: var(--ml-surface-dim, #f5f5f5);
}
grouptriggeraction--ml-button-standard .ml-button-ghost:active {
  filter: brightness(0.95);
}
grouptriggeraction--ml-button-standard .ml-button-link {
  background: transparent;
  color: var(--ml-primary, #3b82f6);
  border: var(--ml-border-width, 1px) var(--ml-border-style, solid) transparent;
}
grouptriggeraction--ml-button-standard .ml-button-link:hover {
  text-decoration: underline;
}
grouptriggeraction--ml-button-standard .ml-button-link:active {
  filter: brightness(0.9);
}
grouptriggeraction--ml-button-standard .ml-disabled {
  opacity: var(--ml-disabled-opacity, 0.5);
  cursor: not-allowed;
  pointer-events: none;
}
`);
        // ==========================================================================
        // SLOT TAGS
        // ==========================================================================
        this.slotTags = ['Label', 'Icon'];
        // ==========================================================================
        // PROPERTIES — From Contract
        // ==========================================================================
        this.cssClass = '';
        this.size = 'md';
        this.type = 'button';
        this.iconPosition = 'start';
        this.disabled = false;
        this.loading = false;
    }
    // ==========================================================================
    // EVENT HANDLERS
    // ==========================================================================
    handleActionClick(e) {
        const isDisabled = this.isDisabled();
        if (isDisabled) {
            e.preventDefault();
            e.stopPropagation();
            return;
        }
        this.dispatchEvent(new CustomEvent('action', {
            bubbles: true,
            composed: true,
            detail: {},
        }));
    }
    // ==========================================================================
    // HELPERS
    // ==========================================================================
    isDisabled() {
        return this.disabled || this.loading;
    }
    getVariant() {
        const variant = (this.getAttribute('data-variant') || 'primary').toLowerCase();
        if (variant === 'secondary' || variant === 'danger' || variant === 'ghost' || variant === 'link') {
            return variant;
        }
        return 'primary';
    }
    getSizeKey() {
        if (this.size === 'xs' || this.size === 'sm' || this.size === 'lg')
            return this.size;
        return 'md';
    }
    getSizeClasses(hasLabel) {
        const sizeKey = this.getSizeKey();
        const iconOnly = !hasLabel;
        const paddingMap = {
            xs: iconOnly ? 'p-1.5' : 'px-2 py-1',
            sm: iconOnly ? 'p-2' : 'px-3 py-1.5',
            md: iconOnly ? 'p-2.5' : 'px-4 py-2',
            lg: iconOnly ? 'p-3' : 'px-5 py-2.5',
        };
        const iconMap = {
            xs: 'h-3 w-3',
            sm: 'h-4 w-4',
            md: 'h-5 w-5',
            lg: 'h-6 w-6',
        };
        const gapMap = {
            xs: 'gap-1.5 text-xs',
            sm: 'gap-2 text-sm',
            md: 'gap-2 text-sm',
            lg: 'gap-2.5 text-base',
        };
        return {
            button: paddingMap[sizeKey],
            icon: iconMap[sizeKey],
            spinner: iconMap[sizeKey],
            gap: gapMap[sizeKey],
        };
    }
    getVariantClasses(variant) {
        const baseMap = {
            primary: 'ml-button-primary',
            secondary: 'ml-button-secondary',
            danger: 'ml-button-danger',
            ghost: 'ml-button-ghost',
            link: 'ml-button-link',
        };
        return baseMap[variant] || baseMap.primary;
    }
    getButtonClasses(hasLabel) {
        const isDisabled = this.isDisabled();
        const variant = this.getVariant();
        const sizeClasses = this.getSizeClasses(hasLabel);
        return [
            'inline-flex items-center justify-center',
            'ml-button',
            sizeClasses.button,
            sizeClasses.gap,
            this.getVariantClasses(variant),
            isDisabled ? 'ml-disabled' : 'cursor-pointer',
        ].filter(Boolean).join(' ');
    }
    getSlotClass(tag) {
        return this.getSlotAttr(tag, 'data-class') || '';
    }
    getIconClasses(sizeClass) {
        return [
            'inline-flex items-center justify-center',
            sizeClass,
        ].join(' ');
    }
    renderSpinner(sizeClass) {
        return html `
      <svg
        class="animate-spin ${sizeClass}"
        viewBox="0 0 24 24"
        fill="none"
        aria-hidden="true"
      >
        ${svg `<circle cx="12" cy="12" r="10" stroke="currentColor" stroke-opacity="0.25" stroke-width="4"></circle>`}
        ${svg `<path d="M22 12a10 10 0 0 1-10 10" stroke="currentColor" stroke-width="4" stroke-linecap="round"></path>`}
      </svg>
    `;
    }
    // ==========================================================================
    // RENDER
    // ==========================================================================
    render() {
        const labelContent = (this.getSlotContent('Label') || '').trim();
        const iconContent = (this.getSlotContent('Icon') || '').trim();
        const hasLabel = labelContent.length > 0;
        const hasIcon = iconContent.length > 0;
        const isDisabled = this.isDisabled();
        const sizeClasses = this.getSizeClasses(hasLabel);
        const iconPosition = this.iconPosition === 'end' ? 'end' : 'start';
        const ariaLabel = !hasLabel && hasIcon ? labelContent : undefined;
        const iconTemplate = hasIcon
            ? html `<span class="${cn(this.getIconClasses(sizeClasses.icon), this.getSlotClass('Icon'))}">${unsafeHTML(iconContent)}</span>`
            : nothing;
        const spinnerTemplate = html `<span class="${this.getIconClasses(sizeClasses.spinner)}">${this.renderSpinner(sizeClasses.spinner)}</span>`;
        const labelTemplate = hasLabel
            ? html `<span class="${cn(this.loading && !hasIcon ? 'opacity-0' : '', this.getSlotClass('Label'))}">${unsafeHTML(labelContent)}</span>`
            : nothing;
        const labelWithSpinner = html `
      <span class="relative inline-flex items-center justify-center">
        ${labelTemplate}
        ${this.loading && !hasIcon ? html `<span class="absolute">${spinnerTemplate}</span>` : nothing}
      </span>
    `;
        const contentTemplate = html `
      ${iconPosition === 'start'
            ? html `
            ${this.loading && hasIcon ? spinnerTemplate : iconTemplate}
            ${labelWithSpinner}
          `
            : html `
            ${labelWithSpinner}
            ${this.loading && hasIcon ? spinnerTemplate : iconTemplate}
          `}
    `;
        return html `
      <button
        class="${cn(this.getButtonClasses(hasLabel), this.cssClass)}"
        type="${this.type}"
        ?disabled=${isDisabled}
        aria-busy=${this.loading ? 'true' : 'false'}
        aria-disabled=${isDisabled ? 'true' : 'false'}
        aria-label=${ariaLabel || nothing}
        @click=${this.handleActionClick}
      >
        ${contentTemplate}
      </button>
    `;
    }
};
__decorate([
    propertyDataSource({ type: String, attribute: 'data-class' })
], ButtonStandardMolecule.prototype, "cssClass", void 0);
__decorate([
    propertyDataSource({ type: String })
], ButtonStandardMolecule.prototype, "size", void 0);
__decorate([
    propertyDataSource({ type: String })
], ButtonStandardMolecule.prototype, "type", void 0);
__decorate([
    propertyDataSource({ type: String, attribute: 'icon-position' })
], ButtonStandardMolecule.prototype, "iconPosition", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], ButtonStandardMolecule.prototype, "disabled", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], ButtonStandardMolecule.prototype, "loading", void 0);
ButtonStandardMolecule = __decorate([
    customElement('grouptriggeraction--ml-button-standard')
], ButtonStandardMolecule);
export { ButtonStandardMolecule };
