var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102053_/l2/molecules/groupenterdate/index.ts" enhancement="_102020_/l2/enhancementAura"/>
import { html } from 'lit';
import { customElement } from 'lit/decorators.js';
import { StateLitElement } from '/_102029_/l2/stateLitElement.js';
// Registra as moléculas do grupo (side-effect import)
import '/_102053_/l2/molecules/groupenterdate/ml-compact-calendar-glass';
let GroupEnterDateIndex = class GroupEnterDateIndex extends StateLitElement {
    render() {
        return html `
      <div style="min-height:100vh; padding:2rem; background: linear-gradient(135deg, #0f172a 0%, #312e81 45%, #7e22ce 100%);">
        <h1>groupEnterDate · glass · 102053</h1>
        <groupenterdate--ml-compact-calendar-glass></groupenterdate--ml-compact-calendar-glass>
      </div>
    `;
    }
};
GroupEnterDateIndex = __decorate([
    customElement('molecules--groupenterdate--index-102053')
], GroupEnterDateIndex);
export { GroupEnterDateIndex };
