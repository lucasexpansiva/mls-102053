var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102053_/l2/molecules/groupenterdate/ml-compact-calendar-glass.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// COMPACT CALENDAR — GLASSMORPHISM (mls-102053)
// =============================================================================
// Skill Group: groupEnterDate
// Casca (estratégia D): herda tudo de MlCompactCalendarMolecule (mls-102040),
// inclusive render() — o markup base emite classes semânticas ml-*; a aparência
// vem do .less irmão, escopado sob esta tag.
// This molecule does NOT contain business logic.
import { customElement } from 'lit/decorators.js';
import { MlCompactCalendarMolecule } from '/_102040_/l2/molecules/groupenterdate/ml-compact-calendar.js';
let MlCompactCalendarMoleculeGlass = class MlCompactCalendarMoleculeGlass extends MlCompactCalendarMolecule {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(`groupenterdate--ml-compact-calendar-glass {
  --ml-font-family: 'Inter', system-ui, sans-serif;
  --ml-font-weight-medium: 600;
  --ml-radius-sm: 12px;
  --ml-radius-md: 12px;
  --ml-radius-lg: 14px;
  --ml-border-width: 1px;
  --ml-outline-variant: rgba(255, 255, 255, 0.25);
  --ml-outline-focus: rgba(199, 210, 254, 0.9);
  --ml-outline-error: rgba(255, 120, 120, 0.85);
  --ml-primary: rgba(99, 102, 241, 0.55);
  --ml-on-primary: #ffffff;
  --ml-surface: rgba(255, 255, 255, 0.1);
  --ml-surface-dim: rgba(30, 27, 75, 0.55);
  --ml-on-surface: rgba(255, 255, 255, 0.95);
  --ml-on-surface-muted: rgba(255, 255, 255, 0.55);
  --ml-on-surface-faint: rgba(255, 255, 255, 0.35);
  --ml-error: #ffb4ab;
  --ml-error-bg: rgba(244, 63, 94, 0.55);
  --ml-shadow-1: 0 4px 18px rgba(0, 0, 0, 0.18);
  --ml-shadow-2: 0 6px 24px rgba(0, 0, 0, 0.26);
  --ml-transition: 250ms ease;
  --ml-focus-ring-width: 3px;
  --ml-focus-ring-color: rgba(199, 210, 254, 0.3);
  --ml-disabled-opacity: 0.5;
  --ml-backdrop-blur: 10px;
  --ml-backdrop-blur-strong: 18px;
}
groupenterdate--ml-compact-calendar-glass .ml-label {
  font-family: var(--ml-font-family, 'Inter', system-ui, sans-serif);
  font-weight: var(--ml-font-weight-medium, 600);
  color: var(--ml-on-surface, rgba(255, 255, 255, 0.95));
}
groupenterdate--ml-compact-calendar-glass .ml-helper {
  color: var(--ml-on-surface-muted, rgba(255, 255, 255, 0.55));
  font-family: var(--ml-font-family, 'Inter', system-ui, sans-serif);
}
groupenterdate--ml-compact-calendar-glass .ml-error-text {
  color: var(--ml-error, #ffb4ab);
  font-family: var(--ml-font-family, 'Inter', system-ui, sans-serif);
}
groupenterdate--ml-compact-calendar-glass .ml-text {
  color: var(--ml-on-surface, rgba(255, 255, 255, 0.95));
  font-family: var(--ml-font-family, 'Inter', system-ui, sans-serif);
}
groupenterdate--ml-compact-calendar-glass .ml-text-muted {
  color: var(--ml-on-surface-muted, rgba(255, 255, 255, 0.55));
  font-family: var(--ml-font-family, 'Inter', system-ui, sans-serif);
}
groupenterdate--ml-compact-calendar-glass .ml-disabled {
  opacity: var(--ml-disabled-opacity, 0.5);
  cursor: not-allowed;
  pointer-events: none;
}
groupenterdate--ml-compact-calendar-glass .ml-calendar-container {
  position: relative;
  overflow: hidden;
  background-color: var(--ml-surface, rgba(255, 255, 255, 0.1));
  border-radius: var(--ml-radius-md, 12px);
  border: var(--ml-border-width, 1px) solid var(--ml-outline-variant, rgba(255, 255, 255, 0.25));
  backdrop-filter: blur(var(--ml-backdrop-blur, 10px));
  -webkit-backdrop-filter: blur(var(--ml-backdrop-blur, 10px));
  box-shadow: var(--ml-shadow-1, 0 4px 18px rgba(0, 0, 0, 0.18));
  transition: border-color var(--ml-transition, 250ms ease), box-shadow var(--ml-transition, 250ms ease);
}
groupenterdate--ml-compact-calendar-glass .ml-calendar-container::before {
  content: '';
  position: absolute;
  inset: 0;
  border-radius: inherit;
  border-top: 1px solid rgba(255, 255, 255, 0.5);
  border-left: 1px solid rgba(255, 255, 255, 0.25);
  pointer-events: none;
  z-index: 1;
}
groupenterdate--ml-compact-calendar-glass .ml-calendar-container--error {
  border-color: var(--ml-outline-error, rgba(255, 120, 120, 0.85));
  box-shadow: 0 0 0 var(--ml-focus-ring-width, 3px) rgba(255, 120, 120, 0.2), var(--ml-shadow-1, 0 4px 18px rgba(0, 0, 0, 0.18));
}
groupenterdate--ml-compact-calendar-glass .ml-calendar-header-clear {
  font-family: var(--ml-font-family, 'Inter', system-ui, sans-serif);
  color: var(--ml-on-surface-muted, rgba(255, 255, 255, 0.55));
  background: transparent;
  border: none;
  cursor: pointer;
  transition: color var(--ml-transition, 250ms ease);
}
groupenterdate--ml-compact-calendar-glass .ml-calendar-header-clear:hover {
  color: var(--ml-on-surface, rgba(255, 255, 255, 0.95));
}
groupenterdate--ml-compact-calendar-glass .ml-calendar-nav-btn {
  background-color: rgba(255, 255, 255, 0.08);
  border: var(--ml-border-width, 1px) solid var(--ml-outline-variant, rgba(255, 255, 255, 0.25));
  border-radius: var(--ml-radius-sm, 12px);
  color: var(--ml-on-surface, rgba(255, 255, 255, 0.95));
  font-family: var(--ml-font-family, 'Inter', system-ui, sans-serif);
  cursor: pointer;
  transition: background-color var(--ml-transition, 250ms ease), border-color var(--ml-transition, 250ms ease);
}
groupenterdate--ml-compact-calendar-glass .ml-calendar-nav-btn--enabled:hover {
  background-color: rgba(255, 255, 255, 0.16);
  border-color: rgba(255, 255, 255, 0.4);
}
groupenterdate--ml-compact-calendar-glass .ml-calendar-day {
  background-color: transparent;
  color: var(--ml-on-surface, rgba(255, 255, 255, 0.95));
  font-family: var(--ml-font-family, 'Inter', system-ui, sans-serif);
  border-radius: var(--ml-radius-sm, 12px);
  border-color: transparent;
  cursor: pointer;
  transition: background-color var(--ml-transition, 250ms ease), border-color var(--ml-transition, 250ms ease), color var(--ml-transition, 250ms ease);
}
groupenterdate--ml-compact-calendar-glass .ml-calendar-day--hoverable:hover {
  background-color: rgba(255, 255, 255, 0.12);
  border-color: rgba(255, 255, 255, 0.2);
}
groupenterdate--ml-compact-calendar-glass .ml-calendar-day-outside {
  color: var(--ml-on-surface-faint, rgba(255, 255, 255, 0.35));
}
groupenterdate--ml-compact-calendar-glass .ml-calendar-day-selected {
  background-color: rgba(99, 102, 241, 0.65);
  color: var(--ml-on-primary, #ffffff);
  border-color: rgba(99, 102, 241, 0.85);
}
groupenterdate--ml-compact-calendar-glass .ml-calendar-day-today {
  border-color: rgba(199, 210, 254, 0.7);
}
groupenterdate--ml-compact-calendar-glass .ml-calendar-day-disabled {
  opacity: var(--ml-disabled-opacity, 0.5);
  cursor: not-allowed;
}
`);
    }
};
MlCompactCalendarMoleculeGlass = __decorate([
    customElement('groupenterdate--ml-compact-calendar-glass')
], MlCompactCalendarMoleculeGlass);
export { MlCompactCalendarMoleculeGlass };
