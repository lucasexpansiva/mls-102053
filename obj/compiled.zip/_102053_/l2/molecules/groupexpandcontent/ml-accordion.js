/// <mls fileReference="_102053_/l2/molecules/groupexpandcontent/ml-accordion.ts" enhancement="_102020_/l2/enhancementAura" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
// =============================================================================
// ML ACCORDION MOLECULE
// =============================================================================
// Skill Group: expand + content
// This molecule does NOT contain business logic.
import { html } from 'lit';
import { unsafeHTML } from 'lit/directives/unsafe-html.js';
import { customElement, state } from 'lit/decorators.js';
import { propertyDataSource } from '/_102029_/l2/collabDecorators';
import { MoleculeAuraElement } from '/_102033_/l2/moleculeBase.js';
import { cn } from '/_102033_/l2/cn.js';
/// **collab_i18n_start**
const message_en = {
    loading: 'Loading...',
    empty: 'No sections available',
};
const messages = {
    en: message_en,
    pt: {
        loading: 'Carregando...',
        empty: 'Nenhuma seção disponível',
    },
};
/// **collab_i18n_end**
let MlAccordionMolecule = class MlAccordionMolecule extends MoleculeAuraElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`groupexpandcontent--ml-accordion .ml-label {
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
  font-weight: var(--ml-font-weight-medium, 500);
  color: var(--ml-on-surface, #1c1b1f);
}
groupexpandcontent--ml-accordion .ml-text-muted {
  color: var(--ml-on-surface-muted, #49454f);
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
}
groupexpandcontent--ml-accordion .ml-accordion-header {
  background: var(--ml-surface, #ffffff);
  color: var(--ml-on-surface, #1c1b1f);
  border: var(--ml-border-width, 1px) var(--ml-border-style, solid) var(--ml-outline-variant, #e2e8f0);
  border-radius: var(--ml-radius-sm, 6px);
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
  font-weight: var(--ml-font-weight-medium, 500);
  transition: background var(--ml-transition, 200ms ease), border-color var(--ml-transition, 200ms ease), box-shadow var(--ml-transition, 200ms ease);
}
groupexpandcontent--ml-accordion .ml-accordion-header:hover {
  background: var(--ml-surface-dim, #f5f5f5);
}
groupexpandcontent--ml-accordion .ml-accordion-header:focus {
  outline: none;
  box-shadow: 0 0 0 var(--ml-focus-ring-width, 2px) var(--ml-focus-ring-color, rgba(59, 130, 246, 0.4));
}
groupexpandcontent--ml-accordion .ml-accordion-header-open {
  border-color: var(--ml-primary, #3b82f6);
  background: var(--ml-surface, #ffffff);
}
groupexpandcontent--ml-accordion .ml-accordion-content {
  color: var(--ml-on-surface, #1c1b1f);
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
}
groupexpandcontent--ml-accordion .ml-accordion-chevron {
  color: var(--ml-on-surface-muted, #49454f);
  transition: transform var(--ml-transition, 200ms ease), color var(--ml-transition, 200ms ease);
}
groupexpandcontent--ml-accordion .ml-accordion-chevron-open {
  color: var(--ml-primary, #3b82f6);
}
groupexpandcontent--ml-accordion .ml-skeleton {
  background: var(--ml-surface-dim, #f5f5f5);
  border-radius: var(--ml-radius-sm, 6px);
}
groupexpandcontent--ml-accordion .ml-disabled {
  opacity: var(--ml-disabled-opacity, 0.5);
  cursor: not-allowed;
  pointer-events: none;
}
`);
        this.msg = messages.en;
        // ===========================================================================
        // SLOT TAGS
        // ===========================================================================
        this.slotTags = ['Label', 'Section'];
        // ===========================================================================
        // PROPERTIES — From Contract
        // ===========================================================================
        this.cssClass = '';
        this.multiple = true;
        this.disabled = false;
        this.loading = false;
        // ===========================================================================
        // INTERNAL STATE
        // ===========================================================================
        this.openSections = new Set();
    }
    // ===========================================================================
    // LIFECYCLE
    // ===========================================================================
    firstUpdated() {
        const sections = this.getSlots('Section');
        const initialOpen = new Set();
        sections.forEach((el, index) => {
            if (el.hasAttribute('expanded')) {
                if (!this.multiple && initialOpen.size > 0)
                    return;
                initialOpen.add(index);
            }
        });
        this.openSections = new Set(initialOpen);
        this.requestUpdate();
    }
    // ===========================================================================
    // EVENT HANDLERS
    // ===========================================================================
    handleToggle(index, title, isDisabled) {
        if (this.disabled || this.loading || isDisabled)
            return;
        const next = new Set(this.openSections);
        const isOpen = next.has(index);
        if (isOpen) {
            next.delete(index);
        }
        else {
            if (!this.multiple) {
                next.clear();
            }
            next.add(index);
        }
        this.openSections = new Set(next);
        this.dispatchEvent(new CustomEvent('toggle', {
            bubbles: true,
            composed: true,
            detail: { index, title, expanded: !isOpen }
        }));
    }
    handleHeaderKeydown(event, index, title, isDisabled) {
        if (this.disabled || this.loading)
            return;
        const target = event.currentTarget;
        if (!target)
            return;
        const key = event.key;
        if (key === 'Enter' || key === ' ') {
            event.preventDefault();
            this.handleToggle(index, title, isDisabled);
            return;
        }
        if (key === 'ArrowDown' || key === 'ArrowUp') {
            event.preventDefault();
            const headers = Array.from(this.querySelectorAll('[data-accordion-header="true"]'));
            const currentIndex = headers.indexOf(target);
            if (currentIndex === -1)
                return;
            const direction = key === 'ArrowDown' ? 1 : -1;
            const nextHeader = this.findNextEnabledHeader(headers, currentIndex, direction);
            nextHeader?.focus();
        }
    }
    findNextEnabledHeader(headers, startIndex, direction) {
        const total = headers.length;
        for (let i = 1; i <= total; i += 1) {
            const idx = (startIndex + direction * i + total) % total;
            const el = headers[idx];
            if (el && el.getAttribute('aria-disabled') !== 'true') {
                return el;
            }
        }
        return null;
    }
    getSectionContent(el) {
        const template = el.querySelector(':scope > template');
        return template ? template.innerHTML : el.innerHTML;
    }
    getHeaderClasses(isOpen, isDisabled) {
        return [
            'w-full flex items-center justify-between gap-3 px-4 py-3 text-sm',
            'ml-accordion-header',
            isOpen ? 'ml-accordion-header-open' : '',
            (this.disabled || isDisabled) ? 'ml-disabled' : 'cursor-pointer',
        ].filter(Boolean).join(' ');
    }
    getContentClasses(isOpen) {
        return [
            'overflow-hidden transition-all duration-200 ml-accordion-content',
            isOpen ? 'max-h-[1000px] opacity-100' : 'max-h-0 opacity-0',
        ].filter(Boolean).join(' ');
    }
    getChevronClasses(isOpen) {
        return [
            'flex items-center justify-center transition-transform duration-200 ml-accordion-chevron',
            isOpen ? 'rotate-180 ml-accordion-chevron-open' : 'rotate-0',
        ].filter(Boolean).join(' ');
    }
    // ===========================================================================
    // RENDER
    // ===========================================================================
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        return html `
<div class="${cn('w-full', this.cssClass)}">
${this.renderLabel()}
${this.loading ? this.renderLoading() : this.renderSections()}
</div>
`;
    }
    renderLabel() {
        if (!this.hasSlot('Label'))
            return html ``;
        return html `
<div class="${cn('mb-2 text-sm ml-label', this.getSlotClass('Label'))}">
${unsafeHTML(this.getSlotContent('Label'))}
</div>
`;
    }
    renderLoading() {
        return html `
<div class="space-y-2">
<div class="h-10 w-full ml-skeleton animate-pulse"></div>
<div class="h-10 w-full ml-skeleton animate-pulse"></div>
<div class="text-xs ml-text-muted">${this.msg.loading}</div>
</div>
`;
    }
    renderSections() {
        const sectionElements = this.getSlots('Section');
        if (sectionElements.length === 0) {
            return html `
<div class="text-sm ml-text-muted">${this.msg.empty}</div>
`;
        }
        return html `
<div class="space-y-2">
${sectionElements.map((el, index) => this.renderSection(el, index))}
</div>
`;
    }
    renderSection(el, index) {
        const title = el.getAttribute('title') || '';
        const isDisabled = el.hasAttribute('disabled');
        const isOpen = this.openSections.has(index);
        const headerId = `accordion-header-${index}`;
        const contentId = `accordion-content-${index}`;
        const content = this.getSectionContent(el);
        return html `
<div>
<div
id=${headerId}
data-accordion-header="true"
role="button"
aria-expanded=${String(isOpen)}
aria-controls=${contentId}
aria-disabled=${String(this.disabled || isDisabled)}
class=${this.getHeaderClasses(isOpen, isDisabled)}
tabindex=${this.disabled || isDisabled ? -1 : 0}
@click=${() => this.handleToggle(index, title, isDisabled)}
@keydown=${(e) => this.handleHeaderKeydown(e, index, title, isDisabled)}
>
<span class="truncate">${title}</span>
<span class=${this.getChevronClasses(isOpen)} aria-hidden="true">
<svg class="h-4 w-4" viewBox="0 0 20 20" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
<path fill-rule="evenodd" d="M5.23 7.21a.75.75 0 011.06.02L10 10.94l3.71-3.71a.75.75 0 111.06 1.06l-4.24 4.24a.75.75 0 01-1.06 0L5.21 8.27a.75.75 0 01.02-1.06z" clip-rule="evenodd" />
</svg>
</span>
</div>
<div
id=${contentId}
role="region"
aria-labelledby=${headerId}
class=${this.getContentClasses(isOpen)}
>
<div class="px-4 pb-4 pt-2 text-sm ml-accordion-content">
${unsafeHTML(content)}
</div>
</div>
</div>
`;
    }
};
__decorate([
    propertyDataSource({ type: String, attribute: 'data-class' })
], MlAccordionMolecule.prototype, "cssClass", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MlAccordionMolecule.prototype, "multiple", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MlAccordionMolecule.prototype, "disabled", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MlAccordionMolecule.prototype, "loading", void 0);
__decorate([
    state()
], MlAccordionMolecule.prototype, "openSections", void 0);
MlAccordionMolecule = __decorate([
    customElement('groupexpandcontent--ml-accordion')
], MlAccordionMolecule);
export { MlAccordionMolecule };
