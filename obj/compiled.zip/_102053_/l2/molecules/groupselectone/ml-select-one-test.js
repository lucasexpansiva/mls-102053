var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102053_/l2/molecules/groupselectone/ml-select-one-test.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// ML SELECT ONE TEST MOLECULE
// =============================================================================
// Skill Group: groupSelectOne
// This molecule does NOT contain business logic.
import { html, nothing } from 'lit';
import { customElement, state } from 'lit/decorators.js';
import { unsafeHTML } from 'lit/directives/unsafe-html.js';
import { render as litRender } from 'lit';
import { propertyDataSource } from '/_102029_/l2/collabDecorators.js';
import { MoleculeAuraElement } from '/_102033_/l2/moleculeBase.js';
import { cn } from '/_102033_/l2/cn.js';
/// **collab_i18n_start**
const message_en = {
    placeholder: 'Select an option',
    empty: '—',
    noResults: 'No results found',
    loading: 'Loading...',
    required: 'Selection required',
    searchPlaceholder: 'Search...',
};
const messages = {
    en: message_en,
};
/// **collab_i18n_end**
let MlSelectOneTestMolecule = class MlSelectOneTestMolecule extends MoleculeAuraElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`groupselectone--ml-select-one-test,
div[data-widget="groupselectone--ml-select-one-test"] {
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
}
groupselectone--ml-select-one-test .ml-label,
div[data-widget="groupselectone--ml-select-one-test"] .ml-label {
  color: var(--ml-on-surface, #1c1b1f);
  font-weight: var(--ml-font-weight-medium, 500);
}
groupselectone--ml-select-one-test .ml-trigger,
div[data-widget="groupselectone--ml-select-one-test"] .ml-trigger {
  background: var(--ml-surface, #ffffff);
  border: var(--ml-border-width, 1px) var(--ml-border-style, solid) var(--ml-outline-variant, #e2e8f0);
  border-radius: var(--ml-radius-sm, 6px);
  color: var(--ml-on-surface, #1c1b1f);
  transition: border-color var(--ml-transition, 200ms ease), box-shadow var(--ml-transition, 200ms ease);
}
groupselectone--ml-select-one-test .ml-trigger:hover:not(.ml-disabled),
div[data-widget="groupselectone--ml-select-one-test"] .ml-trigger:hover:not(.ml-disabled) {
  border-color: var(--ml-outline-focus, #3b82f6);
}
groupselectone--ml-select-one-test .ml-trigger:focus-visible,
div[data-widget="groupselectone--ml-select-one-test"] .ml-trigger:focus-visible {
  outline: none;
  border-color: var(--ml-outline-focus, #3b82f6);
  box-shadow: 0 0 0 var(--ml-focus-ring-width, 2px) var(--ml-focus-ring-color, rgba(59, 130, 246, 0.4));
}
groupselectone--ml-select-one-test .ml-trigger-error,
div[data-widget="groupselectone--ml-select-one-test"] .ml-trigger-error {
  border-color: var(--ml-outline-error, #ef4444) !important;
}
groupselectone--ml-select-one-test .ml-icon,
div[data-widget="groupselectone--ml-select-one-test"] .ml-icon {
  color: var(--ml-on-surface-muted, #49454f);
  transition: transform var(--ml-transition, 200ms ease);
}
groupselectone--ml-select-one-test .ml-panel,
div[data-widget="groupselectone--ml-select-one-test"] .ml-panel {
  background: var(--ml-surface, #ffffff);
  border: var(--ml-border-width, 1px) var(--ml-border-style, solid) var(--ml-outline-variant, #e2e8f0);
  border-radius: var(--ml-radius-sm, 6px);
  box-shadow: var(--ml-shadow-2, 0 4px 6px rgba(0, 0, 0, 0.1));
  overflow: hidden;
}
groupselectone--ml-select-one-test .ml-search,
div[data-widget="groupselectone--ml-select-one-test"] .ml-search {
  background: var(--ml-surface, #ffffff);
  border: var(--ml-border-width, 1px) var(--ml-border-style, solid) var(--ml-outline-variant, #e2e8f0);
  border-radius: var(--ml-radius-sm, 6px);
  color: var(--ml-on-surface, #1c1b1f);
  transition: border-color var(--ml-transition, 200ms ease), box-shadow var(--ml-transition, 200ms ease);
}
groupselectone--ml-select-one-test .ml-search::placeholder,
div[data-widget="groupselectone--ml-select-one-test"] .ml-search::placeholder {
  color: var(--ml-on-surface-faint, #79747e);
}
groupselectone--ml-select-one-test .ml-search:focus,
div[data-widget="groupselectone--ml-select-one-test"] .ml-search:focus {
  outline: none;
  border-color: var(--ml-outline-focus, #3b82f6);
  box-shadow: 0 0 0 var(--ml-focus-ring-width, 2px) var(--ml-focus-ring-color, rgba(59, 130, 246, 0.4));
}
groupselectone--ml-select-one-test .ml-option,
div[data-widget="groupselectone--ml-select-one-test"] .ml-option {
  color: var(--ml-on-surface, #1c1b1f);
  transition: background-color var(--ml-transition, 200ms ease);
}
groupselectone--ml-select-one-test .ml-option:hover:not(.ml-disabled):not(.ml-option-selected),
div[data-widget="groupselectone--ml-select-one-test"] .ml-option:hover:not(.ml-disabled):not(.ml-option-selected) {
  background: var(--ml-surface-dim, #f5f5f5);
}
groupselectone--ml-select-one-test .ml-option-selected,
div[data-widget="groupselectone--ml-select-one-test"] .ml-option-selected {
  background: var(--ml-primary, #3b82f6);
  color: var(--ml-on-primary, #ffffff);
}
groupselectone--ml-select-one-test .ml-option-selected:hover:not(.ml-disabled),
div[data-widget="groupselectone--ml-select-one-test"] .ml-option-selected:hover:not(.ml-disabled) {
  background: var(--ml-primary, #3b82f6);
}
groupselectone--ml-select-one-test .ml-inline-item,
div[data-widget="groupselectone--ml-select-one-test"] .ml-inline-item {
  color: var(--ml-on-surface, #1c1b1f);
  border: var(--ml-border-width, 1px) var(--ml-border-style, solid) transparent;
  border-radius: var(--ml-radius-sm, 6px);
  transition: background-color var(--ml-transition, 200ms ease), border-color var(--ml-transition, 200ms ease), color var(--ml-transition, 200ms ease);
}
groupselectone--ml-select-one-test .ml-inline-item:hover:not(.ml-disabled):not(.ml-inline-item-selected),
div[data-widget="groupselectone--ml-select-one-test"] .ml-inline-item:hover:not(.ml-disabled):not(.ml-inline-item-selected) {
  background: var(--ml-surface-dim, #f5f5f5);
}
groupselectone--ml-select-one-test .ml-inline-item-selected,
div[data-widget="groupselectone--ml-select-one-test"] .ml-inline-item-selected {
  background: var(--ml-primary, #3b82f6);
  border-color: var(--ml-primary, #3b82f6);
  color: var(--ml-on-primary, #ffffff);
}
groupselectone--ml-select-one-test .ml-inline-item-selected:hover:not(.ml-disabled),
div[data-widget="groupselectone--ml-select-one-test"] .ml-inline-item-selected:hover:not(.ml-disabled) {
  background: var(--ml-primary, #3b82f6);
}
groupselectone--ml-select-one-test .ml-table-wrapper,
div[data-widget="groupselectone--ml-select-one-test"] .ml-table-wrapper {
  background: var(--ml-surface, #ffffff);
  border: var(--ml-border-width, 1px) var(--ml-border-style, solid) var(--ml-outline-variant, #e2e8f0);
  border-radius: var(--ml-radius-sm, 6px);
  overflow: hidden;
}
groupselectone--ml-select-one-test .ml-table,
div[data-widget="groupselectone--ml-select-one-test"] .ml-table {
  border-collapse: collapse;
}
groupselectone--ml-select-one-test .ml-table th,
div[data-widget="groupselectone--ml-select-one-test"] .ml-table th,
groupselectone--ml-select-one-test .ml-table td,
div[data-widget="groupselectone--ml-select-one-test"] .ml-table td {
  padding: 0.5rem 0.75rem;
  text-align: left;
}
groupselectone--ml-select-one-test .ml-table th,
div[data-widget="groupselectone--ml-select-one-test"] .ml-table th {
  background: var(--ml-surface-dim, #f5f5f5);
  color: var(--ml-on-surface-muted, #49454f);
  font-weight: var(--ml-font-weight-medium, 500);
  font-size: 0.75rem;
  text-transform: uppercase;
  letter-spacing: 0.05em;
}
groupselectone--ml-select-one-test .ml-table tbody tr,
div[data-widget="groupselectone--ml-select-one-test"] .ml-table tbody tr {
  border-top: var(--ml-border-width, 1px) var(--ml-border-style, solid) var(--ml-outline-variant, #e2e8f0);
}
groupselectone--ml-select-one-test .ml-table tbody td,
div[data-widget="groupselectone--ml-select-one-test"] .ml-table tbody td {
  color: var(--ml-on-surface, #1c1b1f);
}
groupselectone--ml-select-one-test .ml-text,
div[data-widget="groupselectone--ml-select-one-test"] .ml-text {
  color: var(--ml-on-surface, #1c1b1f);
}
groupselectone--ml-select-one-test .ml-text-muted,
div[data-widget="groupselectone--ml-select-one-test"] .ml-text-muted {
  color: var(--ml-on-surface-muted, #49454f);
}
groupselectone--ml-select-one-test .ml-text-faint,
div[data-widget="groupselectone--ml-select-one-test"] .ml-text-faint {
  color: var(--ml-on-surface-faint, #79747e);
}
groupselectone--ml-select-one-test .ml-helper,
div[data-widget="groupselectone--ml-select-one-test"] .ml-helper {
  color: var(--ml-on-surface-muted, #49454f);
}
groupselectone--ml-select-one-test .ml-error-text,
div[data-widget="groupselectone--ml-select-one-test"] .ml-error-text {
  color: var(--ml-error, #ef4444);
}
groupselectone--ml-select-one-test .ml-disabled,
div[data-widget="groupselectone--ml-select-one-test"] .ml-disabled {
  opacity: var(--ml-disabled-opacity, 0.5);
  cursor: not-allowed;
  pointer-events: none;
}
`);
        this.msg = messages.en;
        // ===========================================================================
        // SLOT TAGS
        // ==========================================================================
        this.slotTags = ['Label', 'Helper', 'Trigger', 'Item', 'Cell', 'Column', 'Group', 'Empty'];
        // ===========================================================================
        // PROPERTIES — From Contract
        // ==========================================================================
        this.value = null;
        this.error = '';
        this.name = '';
        this.variant = 'dropdown';
        this.placeholder = '';
        this.searchable = false;
        this.isEditing = true;
        this.disabled = false;
        this.readonly = false;
        this.required = false;
        this.loading = false;
        // ===========================================================================
        // INTERNAL STATE
        // ==========================================================================
        this.isOpen = false;
        this.searchQuery = '';
        this.isFocused = false;
        this.uid = `ml-select-one-${Math.random().toString(36).slice(2)}`;
        // ===========================================================================
        // PORTAL SUPPORT
        // ==========================================================================
        this.portalContainer = null;
        this.portalWidgetName = 'groupselectone--ml-select-one-test';
        this.boundOutsideClick = (e) => {
            if (!this.isOpen)
                return;
            const path = e.composedPath();
            if (!path.includes(this) && (!this.portalContainer || !path.includes(this.portalContainer))) {
                this.closePanel();
            }
        };
        this.boundUpdatePosition = () => this.updatePanelPosition();
    }
    // ===========================================================================
    // LIFECYCLE
    // ==========================================================================
    connectedCallback() {
        super.connectedCallback();
        document.addEventListener('click', this.boundOutsideClick, true);
    }
    disconnectedCallback() {
        document.removeEventListener('click', this.boundOutsideClick, true);
        this.destroyPortal();
        super.disconnectedCallback();
    }
    updated(changedProps) {
        if (changedProps.has('variant') && this.variant !== 'dropdown' && this.isOpen) {
            this.closePanel();
        }
        if (changedProps.has('disabled') || changedProps.has('readonly') || changedProps.has('loading')) {
            if ((this.disabled || this.readonly || this.loading) && this.isOpen) {
                this.closePanel();
            }
        }
        if (this.isOpen && this.portalContainer) {
            this.renderPortalContent();
            this.updatePanelPosition();
        }
    }
    // ===========================================================================
    // PORTAL METHODS
    // ==========================================================================
    createPortal() {
        if (this.portalContainer)
            return;
        this.portalContainer = document.createElement('div');
        if (this.portalWidgetName)
            this.portalContainer.setAttribute('data-widget', this.portalWidgetName);
        document.body.appendChild(this.portalContainer);
        this.updatePanelPosition();
        this.renderPortalContent();
        window.addEventListener('scroll', this.boundUpdatePosition, true);
        window.addEventListener('resize', this.boundUpdatePosition);
    }
    destroyPortal() {
        if (!this.portalContainer)
            return;
        window.removeEventListener('scroll', this.boundUpdatePosition, true);
        window.removeEventListener('resize', this.boundUpdatePosition);
        this.portalContainer.remove();
        this.portalContainer = null;
    }
    updatePanelPosition() {
        if (!this.portalContainer)
            return;
        const trigger = this.querySelector('button[role="combobox"]');
        if (!trigger)
            return;
        const rect = trigger.getBoundingClientRect();
        Object.assign(this.portalContainer.style, {
            position: 'fixed',
            top: `${rect.bottom + 8}px`,
            left: `${rect.left}px`,
            width: `${rect.width}px`,
            zIndex: '9999',
        });
    }
    renderPortalContent() {
        if (!this.portalContainer)
            return;
        litRender(this.getPortalTemplate(), this.portalContainer);
    }
    // ===========================================================================
    // EVENT HANDLERS
    // ==========================================================================
    handleFocusIn() {
        if (this.isFocused)
            return;
        this.isFocused = true;
        this.dispatchEvent(new CustomEvent('focus', { bubbles: true, composed: true }));
    }
    handleFocusOut(e) {
        const next = e.relatedTarget;
        if (next && (this.contains(next) || (this.portalContainer && this.portalContainer.contains(next)))) {
            return;
        }
        if (!this.isFocused)
            return;
        this.isFocused = false;
        this.dispatchEvent(new CustomEvent('blur', { bubbles: true, composed: true }));
    }
    handleTriggerClick() {
        if (this.disabled || this.readonly || this.loading)
            return;
        if (this.isOpen) {
            this.closePanel();
        }
        else {
            this.openPanel();
        }
    }
    handleTriggerKeyDown(e) {
        if (this.disabled || this.readonly || this.loading)
            return;
        if (e.key === 'Escape') {
            this.closePanel();
            return;
        }
        if (e.key === 'ArrowDown' || e.key === 'ArrowUp') {
            e.preventDefault();
            if (!this.isOpen)
                this.openPanel();
            this.selectNextItem(e.key === 'ArrowDown' ? 1 : -1);
        }
        if (e.key === 'Enter' && !this.isOpen) {
            this.openPanel();
        }
    }
    handlePanelKeyDown(e) {
        if (e.key === 'Escape') {
            this.closePanel();
            return;
        }
        if (e.key === 'ArrowDown' || e.key === 'ArrowUp') {
            e.preventDefault();
            this.selectNextItem(e.key === 'ArrowDown' ? 1 : -1);
        }
        if (e.key === 'Enter') {
            e.preventDefault();
            this.selectCurrentItem();
        }
    }
    handleInlineKeyDown(e) {
        if (this.disabled || this.readonly)
            return;
        if (['ArrowDown', 'ArrowUp', 'ArrowLeft', 'ArrowRight'].includes(e.key)) {
            e.preventDefault();
            const step = e.key === 'ArrowUp' || e.key === 'ArrowLeft' ? -1 : 1;
            this.selectNextItem(step);
        }
        if (e.key === 'Enter' || e.key === ' ') {
            e.preventDefault();
            this.selectCurrentItem();
        }
    }
    handleItemSelect(item) {
        if (this.disabled || this.readonly || item.disabled)
            return;
        this.value = item.value;
        this.dispatchEvent(new CustomEvent('change', {
            bubbles: true,
            composed: true,
            detail: { value: this.value },
        }));
        if (this.variant === 'dropdown') {
            this.closePanel();
        }
    }
    handleRowSelect(item) {
        if (this.disabled || this.readonly || item.disabled)
            return;
        this.value = item.value;
        this.dispatchEvent(new CustomEvent('change', {
            bubbles: true,
            composed: true,
            detail: { value: this.value },
        }));
    }
    handleSearchInput(e) {
        e.stopPropagation();
        const input = e.target;
        this.searchQuery = input.value;
    }
    handleRadioChange(e, item) {
        e.stopPropagation();
        this.handleRowSelect(item);
    }
    // ===========================================================================
    // OPEN/CLOSE
    // ==========================================================================
    openPanel() {
        if (this.isOpen || this.variant !== 'dropdown')
            return;
        this.isOpen = true;
        this.createPortal();
    }
    closePanel() {
        if (!this.isOpen)
            return;
        this.destroyPortal();
        this.isOpen = false;
    }
    // ===========================================================================
    // DATA HELPERS
    // ==========================================================================
    parseItems() {
        const itemEls = this.getSlots('Item');
        return itemEls
            .map((el) => {
            const value = el.getAttribute('value') || '';
            const disabled = el.hasAttribute('disabled');
            const cells = Array.from(el.querySelectorAll('Cell')).map((c) => c.innerHTML);
            const label = cells.length > 0 ? cells[0] : el.innerHTML;
            const groupEl = el.parentElement && el.parentElement.tagName === 'GROUP' ? el.parentElement : null;
            const groupLabel = groupEl?.getAttribute('label') || '';
            return { value, disabled, label, cells, groupLabel };
        })
            .filter((item) => item.value !== '');
    }
    getFilteredItems(items) {
        if (!this.searchable || !this.searchQuery.trim())
            return items;
        const query = this.searchQuery.trim().toLowerCase();
        return items.filter((item) => {
            const labelText = this.stripHtml(item.label).toLowerCase();
            const cellText = item.cells.map((c) => this.stripHtml(c)).join(' ').toLowerCase();
            return `${labelText} ${cellText}`.includes(query);
        });
    }
    getGroupedItems(items) {
        const groups = {};
        const ungrouped = [];
        for (const item of items) {
            if (item.groupLabel) {
                if (!groups[item.groupLabel])
                    groups[item.groupLabel] = [];
                groups[item.groupLabel].push(item);
            }
            else {
                ungrouped.push(item);
            }
        }
        const grouped = Object.keys(groups).map((label) => ({ label, items: groups[label] }));
        if (ungrouped.length > 0)
            grouped.unshift({ label: '', items: ungrouped });
        return grouped;
    }
    getSelectedItem(items) {
        if (!this.value)
            return null;
        return items.find((item) => item.value === this.value) || null;
    }
    stripHtml(htmlContent) {
        const div = document.createElement('div');
        div.innerHTML = htmlContent;
        return div.textContent || '';
    }
    selectNextItem(step) {
        const items = this.getFilteredItems(this.parseItems()).filter((i) => !i.disabled);
        if (items.length === 0)
            return;
        const currentIndex = items.findIndex((i) => i.value === this.value);
        const nextIndex = currentIndex === -1 ? 0 : (currentIndex + step + items.length) % items.length;
        const nextItem = items[nextIndex];
        this.value = nextItem.value;
        this.dispatchEvent(new CustomEvent('change', { bubbles: true, composed: true, detail: { value: this.value } }));
    }
    selectCurrentItem() {
        const items = this.getFilteredItems(this.parseItems()).filter((i) => !i.disabled);
        if (items.length === 0)
            return;
        const current = items.find((i) => i.value === this.value) || items[0];
        this.handleItemSelect(current);
    }
    // ===========================================================================
    // CLASS HELPERS
    // ==========================================================================
    getTriggerClasses(hasError) {
        return [
            'flex w-full items-center justify-between gap-2 px-3 py-2 text-sm',
            'ml-trigger',
            hasError ? 'ml-trigger-error' : '',
            this.disabled ? 'ml-disabled' : 'cursor-pointer',
        ]
            .filter(Boolean)
            .join(' ');
    }
    getOptionClasses(item, selected) {
        return [
            'flex w-full items-center justify-between gap-2 px-3 py-2 text-sm',
            'ml-option',
            selected ? 'ml-option-selected' : '',
            item.disabled ? 'ml-disabled' : 'cursor-pointer',
        ]
            .filter(Boolean)
            .join(' ');
    }
    getInlineItemClasses(item, selected) {
        return [
            'flex items-center gap-2 px-3 py-2 text-sm',
            'ml-inline-item',
            selected ? 'ml-inline-item-selected' : '',
            item.disabled ? 'ml-disabled' : 'cursor-pointer',
        ]
            .filter(Boolean)
            .join(' ');
    }
    getContainerClasses() {
        return [
            'flex w-full flex-col gap-1',
            'ml-container',
            this.disabled ? 'ml-disabled' : '',
        ]
            .filter(Boolean)
            .join(' ');
    }
    // ===========================================================================
    // RENDER HELPERS
    // ==========================================================================
    renderLabel() {
        if (!this.hasSlot('Label'))
            return html ``;
        return html `
<div class="${cn('mb-1 text-sm ml-label', this.getSlotClass('Label'))}">
${unsafeHTML(this.getSlotContent('Label'))}
</div>
`;
    }
    renderHelperOrError(hasError) {
        if (hasError) {
            const message = this.error || this.msg.required;
            return html `<div class="${cn('mt-1 text-xs ml-error-text')}">${unsafeHTML(String(message))}</div>`;
        }
        if (this.hasSlot('Helper')) {
            return html `
<div class="${cn('mt-1 text-xs ml-helper', this.getSlotClass('Helper'))}">
${unsafeHTML(this.getSlotContent('Helper'))}
</div>
`;
        }
        return html ``;
    }
    renderEmpty() {
        const content = this.getSlotContent('Empty') || this.msg.noResults;
        return html `<div class="px-3 py-2 text-sm ml-text-faint">${unsafeHTML(content)}</div>`;
    }
    renderTriggerContent(selected) {
        if (selected) {
            return html `<span class="ml-text">${unsafeHTML(selected.label)}</span>`;
        }
        if (this.hasSlot('Trigger')) {
            return html `${unsafeHTML(this.getSlotContent('Trigger'))}`;
        }
        const placeholder = this.placeholder || this.msg.placeholder;
        return html `<span class="ml-text-faint">${placeholder}</span>`;
    }
    renderSearchInput() {
        if (!this.searchable)
            return html ``;
        return html `
<div class="px-3 pt-3">
<input
type="text"
class="w-full px-3 py-2 text-sm ml-search"
placeholder="${this.msg.searchPlaceholder}"
.value=${this.searchQuery}
@input=${this.handleSearchInput}
@change=${(e) => e.stopPropagation()}
/>
</div>
`;
    }
    renderDropdownPanel(items) {
        if (this.loading) {
            return html `<div class="px-3 py-2 text-sm ml-text-muted">${this.msg.loading}</div>`;
        }
        if (items.length === 0)
            return this.renderEmpty();
        const grouped = this.getGroupedItems(items);
        return html `
<div
class="ml-panel"
role="listbox"
id="${this.uid}-listbox"
@keydown=${this.handlePanelKeyDown}
>
${this.renderSearchInput()}
<div class="py-2">
${grouped.map((group) => this.renderGroup(group))}
</div>
</div>
`;
    }
    renderGroup(group) {
        return html `
${group.label
            ? html `<div class="px-3 py-1 text-xs ml-text-muted">${group.label}</div>`
            : html ``}
${group.items.map((item) => this.renderOption(item))}
`;
    }
    renderOption(item) {
        const selected = this.value === item.value;
        return html `
<div
class="${this.getOptionClasses(item, selected)}"
role="option"
aria-selected="${selected}"
aria-disabled="${item.disabled}"
@click=${() => this.handleItemSelect(item)}
>
<span>${unsafeHTML(item.label)}</span>
</div>
`;
    }
    renderInlineOptions(items, layout) {
        if (this.loading) {
            return html `<div class="px-3 py-2 text-sm ml-text-muted">${this.msg.loading}</div>`;
        }
        if (items.length === 0)
            return this.renderEmpty();
        const grouped = this.getGroupedItems(items);
        const containerClasses = [
            'flex w-full',
            layout === 'segmented' ? 'flex-wrap gap-2' : 'flex-col gap-1',
            'ml-inline-container',
        ]
            .filter(Boolean)
            .join(' ');
        return html `
${this.renderSearchInput()}
<div class="${containerClasses}" role="radiogroup" @keydown=${this.handleInlineKeyDown}>
${grouped.map((group) => html `
${group.label
            ? html `<div class="px-3 py-1 text-xs ml-text-muted">${group.label}</div>`
            : html ``}
${group.items.map((item) => this.renderInlineItem(item, layout))}
`)}
</div>
`;
    }
    renderInlineItem(item, layout) {
        const selected = this.value === item.value;
        const classes = this.getInlineItemClasses(item, selected);
        const role = 'radio';
        return html `
<div
class="${classes}"
role="${role}"
aria-checked="${selected}"
aria-disabled="${item.disabled}"
@click=${() => this.handleItemSelect(item)}
>
<span>${unsafeHTML(item.label)}</span>
</div>
`;
    }
    renderTable(items) {
        if (this.loading) {
            return html `<div class="px-3 py-2 text-sm ml-text-muted">${this.msg.loading}</div>`;
        }
        if (items.length === 0)
            return this.renderEmpty();
        const columns = this.getSlots('Column').map((col) => col.innerHTML);
        return html `
${this.renderSearchInput()}
<div class="ml-table-wrapper" role="radiogroup" @keydown=${this.handleInlineKeyDown}>
<table class="w-full ml-table">
${columns.length > 0
            ? html `
<thead>
<tr>
<th scope="col"></th>
${columns.map((col) => html `<th scope="col">${unsafeHTML(col)}</th>`)}
</tr>
</thead>
`
            : html ``}
<tbody>
${items.map((item) => this.renderTableRow(item, columns.length))}
</tbody>
</table>
</div>
`;
    }
    renderTableRow(item, columnCount) {
        const selected = this.value === item.value;
        const cells = item.cells.length > 0 ? item.cells : [item.label];
        return html `
<tr
class="${this.getInlineItemClasses(item, selected)}"
role="radio"
aria-checked="${selected}"
aria-disabled="${item.disabled}"
@click=${() => this.handleRowSelect(item)}
>
<td>
<input
type="radio"
name="${this.uid}"
.checked=${selected}
?disabled=${item.disabled || this.disabled || this.readonly}
@input=${(e) => e.stopPropagation()}
@change=${(e) => this.handleRadioChange(e, item)}
/>
</td>
${cells.map((cell) => html `<td>${unsafeHTML(cell)}</td>`)}
${columnCount > cells.length
            ? Array.from({ length: columnCount - cells.length }).map(() => html `<td></td>`)
            : html ``}
</tr>
`;
    }
    renderViewMode(items) {
        const selected = this.getSelectedItem(items);
        const placeholder = this.placeholder || this.msg.empty;
        if (!selected) {
            return html `<div class="text-sm ml-text-faint">${placeholder}</div>`;
        }
        if (this.variant === 'table' && selected.cells.length > 0) {
            return html `
<div class="flex flex-col gap-1">
${selected.cells.map((cell) => html `<div class="text-sm ml-text">${unsafeHTML(cell)}</div>`)}
</div>
`;
        }
        return html `<div class="text-sm ml-text">${unsafeHTML(selected.label)}</div>`;
    }
    getPortalTemplate() {
        const items = this.getFilteredItems(this.parseItems());
        return this.renderDropdownPanel(items);
    }
    // ===========================================================================
    // RENDER
    // ==========================================================================
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        const items = this.getFilteredItems(this.parseItems());
        const selected = this.getSelectedItem(items);
        const hasError = !!this.error || (this.required && !this.value);
        const rootClasses = cn(this.getContainerClasses(), this.cssClass); // Error styling is limited to the trigger only.
        const ariaInvalid = hasError ? 'true' : 'false';
        const ariaRequired = this.required ? 'true' : 'false';
        const labelId = `${this.uid}-label`;
        const errorId = `${this.uid}-error`;
        return html `
<div class="${rootClasses}" @focusin=${this.handleFocusIn} @focusout=${this.handleFocusOut}>
${this.hasSlot('Label')
            ? html `<div id="${labelId}">${this.renderLabel()}</div>`
            : html ``}
${this.isEditing
            ? html `
${this.variant === 'dropdown'
                ? html `
<button
class="${this.getTriggerClasses(hasError)}"
role="combobox"
aria-expanded="${this.isOpen}"
aria-haspopup="listbox"
aria-controls="${this.uid}-listbox"
aria-labelledby="${this.hasSlot('Label') ? labelId : nothing}"
aria-invalid="${ariaInvalid}"
aria-required="${ariaRequired}"
@click=${this.handleTriggerClick}
@keydown=${this.handleTriggerKeyDown}
>
<span class="flex-1 text-left">${this.renderTriggerContent(selected)}</span>
<span class="ml-icon">▾</span>
</button>
`
                : nothing}
${this.variant === 'radio'
                ? this.renderInlineOptions(items, 'radio')
                : this.variant === 'segmented'
                    ? this.renderInlineOptions(items, 'segmented')
                    : this.variant === 'list'
                        ? this.renderInlineOptions(items, 'list')
                        : this.variant === 'table'
                            ? this.renderTable(items)
                            : html ``}
${this.renderHelperOrError(hasError)}
`
            : html `
${this.renderViewMode(items)}
`}
${hasError ? html `<div id="${errorId}" class="sr-only"></div>` : html ``}
</div>
`;
    }
};
__decorate([
    propertyDataSource({ type: String })
], MlSelectOneTestMolecule.prototype, "value", void 0);
__decorate([
    propertyDataSource({ type: String })
], MlSelectOneTestMolecule.prototype, "error", void 0);
__decorate([
    propertyDataSource({ type: String })
], MlSelectOneTestMolecule.prototype, "name", void 0);
__decorate([
    propertyDataSource({ type: String })
], MlSelectOneTestMolecule.prototype, "variant", void 0);
__decorate([
    propertyDataSource({ type: String })
], MlSelectOneTestMolecule.prototype, "placeholder", void 0);
__decorate([
    propertyDataSource({ type: Boolean, attribute: 'searchable' })
], MlSelectOneTestMolecule.prototype, "searchable", void 0);
__decorate([
    propertyDataSource({ type: Boolean, attribute: 'is-editing' })
], MlSelectOneTestMolecule.prototype, "isEditing", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MlSelectOneTestMolecule.prototype, "disabled", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MlSelectOneTestMolecule.prototype, "readonly", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MlSelectOneTestMolecule.prototype, "required", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MlSelectOneTestMolecule.prototype, "loading", void 0);
__decorate([
    state()
], MlSelectOneTestMolecule.prototype, "isOpen", void 0);
__decorate([
    state()
], MlSelectOneTestMolecule.prototype, "searchQuery", void 0);
__decorate([
    state()
], MlSelectOneTestMolecule.prototype, "isFocused", void 0);
MlSelectOneTestMolecule = __decorate([
    customElement('groupselectone--ml-select-one-test')
], MlSelectOneTestMolecule);
export { MlSelectOneTestMolecule };
