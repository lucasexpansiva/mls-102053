var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102053_/l2/molecules/groupselectone/ml-discrete-slider-glass.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// DISCRETE SLIDER — GLASSMORPHISM (mls-102053)
// =============================================================================
// Skill Group: groupSelectOne
// Casca (estratégia D): herda tudo de MlDiscreteSliderMolecule (mls-102040),
// inclusive render() — o markup base emite classes semânticas ml-*; a aparência
// vem do .less irmão, escopado sob esta tag.
// This molecule does NOT contain business logic.
import { customElement } from 'lit/decorators.js';
import { MlDiscreteSliderMolecule } from '/_102040_/l2/molecules/groupselectone/ml-discrete-slider.js';
let MlDiscreteSliderMoleculeGlass = class MlDiscreteSliderMoleculeGlass extends MlDiscreteSliderMolecule {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(`groupselectone--ml-discrete-slider-glass {
  --ml-font-family: 'Inter', system-ui, sans-serif;
  --ml-font-weight-medium: 600;
  --ml-radius-sm: 12px;
  --ml-radius-md: 12px;
  --ml-radius-lg: 14px;
  --ml-border-width: 1px;
  --ml-outline-variant: rgba(255, 255, 255, 0.25);
  --ml-outline-focus: rgba(199, 210, 254, 0.9);
  --ml-outline-error: rgba(255, 120, 120, 0.85);
  --ml-primary: rgba(99, 102, 241, 0.55);
  --ml-on-primary: #ffffff;
  --ml-surface: rgba(255, 255, 255, 0.1);
  --ml-surface-dim: rgba(30, 27, 75, 0.55);
  --ml-on-surface: rgba(255, 255, 255, 0.95);
  --ml-on-surface-muted: rgba(255, 255, 255, 0.55);
  --ml-error: #ffb4ab;
  --ml-error-bg: rgba(244, 63, 94, 0.55);
  --ml-shadow-1: 0 4px 18px rgba(0, 0, 0, 0.18);
  --ml-shadow-2: 0 6px 24px rgba(0, 0, 0, 0.26);
  --ml-transition: 250ms ease;
  --ml-focus-ring-width: 3px;
  --ml-focus-ring-color: rgba(199, 210, 254, 0.3);
  --ml-disabled-opacity: 0.5;
  --ml-backdrop-blur: 10px;
  --ml-backdrop-blur-strong: 18px;
}
groupselectone--ml-discrete-slider-glass .ml-label {
  font-family: var(--ml-font-family, 'Inter', system-ui, sans-serif);
  font-weight: var(--ml-font-weight-medium, 600);
  color: var(--ml-on-surface, rgba(255, 255, 255, 0.95));
}
groupselectone--ml-discrete-slider-glass .ml-helper {
  font-family: var(--ml-font-family, 'Inter', system-ui, sans-serif);
  color: var(--ml-on-surface-muted, rgba(255, 255, 255, 0.55));
}
groupselectone--ml-discrete-slider-glass .ml-error-text {
  font-family: var(--ml-font-family, 'Inter', system-ui, sans-serif);
  color: var(--ml-error, #ffb4ab);
}
groupselectone--ml-discrete-slider-glass .ml-text {
  font-family: var(--ml-font-family, 'Inter', system-ui, sans-serif);
  color: var(--ml-on-surface, rgba(255, 255, 255, 0.95));
}
groupselectone--ml-discrete-slider-glass .ml-text-muted {
  font-family: var(--ml-font-family, 'Inter', system-ui, sans-serif);
  color: var(--ml-on-surface-muted, rgba(255, 255, 255, 0.55));
}
groupselectone--ml-discrete-slider-glass .ml-disabled {
  opacity: var(--ml-disabled-opacity, 0.5);
  cursor: not-allowed;
  pointer-events: none;
}
groupselectone--ml-discrete-slider-glass .ml-slider-track {
  background-color: rgba(255, 255, 255, 0.12);
  border: var(--ml-border-width, 1px) solid var(--ml-outline-variant, rgba(255, 255, 255, 0.25));
  backdrop-filter: blur(var(--ml-backdrop-blur, 10px));
  -webkit-backdrop-filter: blur(var(--ml-backdrop-blur, 10px));
  box-shadow: var(--ml-shadow-1, 0 4px 18px rgba(0, 0, 0, 0.18));
  transition: background-color var(--ml-transition, 250ms ease), border-color var(--ml-transition, 250ms ease);
}
groupselectone--ml-discrete-slider-glass .ml-slider-track-error {
  background-color: rgba(244, 63, 94, 0.18);
  border-color: var(--ml-outline-error, rgba(255, 120, 120, 0.85));
}
groupselectone--ml-discrete-slider-glass .ml-slider-filled {
  background: linear-gradient(90deg, rgba(99, 102, 241, 0.75) 0%, rgba(139, 92, 246, 0.65) 100%);
  transition: width var(--ml-transition, 250ms ease);
}
groupselectone--ml-discrete-slider-glass .ml-slider-mark {
  background-color: rgba(255, 255, 255, 0.12);
  border-color: var(--ml-outline-variant, rgba(255, 255, 255, 0.25));
  backdrop-filter: blur(var(--ml-backdrop-blur, 10px));
  -webkit-backdrop-filter: blur(var(--ml-backdrop-blur, 10px));
  box-shadow: var(--ml-shadow-1, 0 4px 18px rgba(0, 0, 0, 0.18));
  transition: background-color var(--ml-transition, 250ms ease), border-color var(--ml-transition, 250ms ease), box-shadow var(--ml-transition, 250ms ease), transform var(--ml-transition, 250ms ease);
  position: relative;
}
groupselectone--ml-discrete-slider-glass .ml-slider-mark::before {
  content: '';
  position: absolute;
  inset: 0;
  border-radius: inherit;
  border-top: 1px solid rgba(255, 255, 255, 0.5);
  border-left: 1px solid rgba(255, 255, 255, 0.25);
  pointer-events: none;
}
groupselectone--ml-discrete-slider-glass .ml-slider-mark-active {
  background-color: rgba(99, 102, 241, 0.75);
  border-color: rgba(139, 92, 246, 0.9);
  box-shadow: 0 0 0 2px rgba(99, 102, 241, 0.35), var(--ml-shadow-1, 0 4px 18px rgba(0, 0, 0, 0.18));
  transition: background-color var(--ml-transition, 250ms ease), border-color var(--ml-transition, 250ms ease), box-shadow var(--ml-transition, 250ms ease), transform var(--ml-transition, 250ms ease);
  position: relative;
}
groupselectone--ml-discrete-slider-glass .ml-slider-mark-active::before {
  content: '';
  position: absolute;
  inset: 0;
  border-radius: inherit;
  border-top: 1px solid rgba(255, 255, 255, 0.5);
  border-left: 1px solid rgba(255, 255, 255, 0.25);
  pointer-events: none;
}
groupselectone--ml-discrete-slider-glass .ml-slider-mark-focus {
  box-shadow: 0 0 0 var(--ml-focus-ring-width, 3px) var(--ml-focus-ring-color, rgba(199, 210, 254, 0.3)), var(--ml-shadow-1, 0 4px 18px rgba(0, 0, 0, 0.18));
  border-color: var(--ml-outline-focus, rgba(199, 210, 254, 0.9));
}
groupselectone--ml-discrete-slider-glass .ml-slider-drag-thumb {
  background-color: rgba(99, 102, 241, 0.85);
  border-color: rgba(199, 210, 254, 0.9);
  box-shadow: 0 0 0 9px rgba(99, 102, 241, 0.18), var(--ml-shadow-2, 0 6px 24px rgba(0, 0, 0, 0.26));
}
groupselectone--ml-discrete-slider-glass .ml-slider-thumb {
  font-family: var(--ml-font-family, 'Inter', system-ui, sans-serif);
  font-weight: var(--ml-font-weight-medium, 600);
  background-color: rgba(99, 102, 241, 0.65);
  color: var(--ml-on-primary, #ffffff);
  border: var(--ml-border-width, 1px) solid rgba(255, 255, 255, 0.25);
  border-radius: var(--ml-radius-sm, 12px);
  backdrop-filter: blur(var(--ml-backdrop-blur, 10px));
  -webkit-backdrop-filter: blur(var(--ml-backdrop-blur, 10px));
  box-shadow: var(--ml-shadow-1, 0 4px 18px rgba(0, 0, 0, 0.18));
  transition: left var(--ml-transition, 250ms ease), background-color var(--ml-transition, 250ms ease);
  position: relative;
}
groupselectone--ml-discrete-slider-glass .ml-slider-thumb::before {
  content: '';
  position: absolute;
  inset: 0;
  border-radius: inherit;
  border-top: 1px solid rgba(255, 255, 255, 0.5);
  border-left: 1px solid rgba(255, 255, 255, 0.25);
  pointer-events: none;
}
groupselectone--ml-discrete-slider-glass .ml-slider-thumb-arrow::after {
  border-top-color: rgba(99, 102, 241, 0.65);
}
groupselectone--ml-discrete-slider-glass .ml-slider-indicator-idle {
  font-family: var(--ml-font-family, 'Inter', system-ui, sans-serif);
  font-weight: var(--ml-font-weight-medium, 600);
  background-color: var(--ml-surface-dim, rgba(30, 27, 75, 0.55));
  color: var(--ml-on-surface-muted, rgba(255, 255, 255, 0.55));
  border: var(--ml-border-width, 1px) solid var(--ml-outline-variant, rgba(255, 255, 255, 0.25));
  border-radius: var(--ml-radius-sm, 12px);
  backdrop-filter: blur(var(--ml-backdrop-blur-strong, 18px));
  -webkit-backdrop-filter: blur(var(--ml-backdrop-blur-strong, 18px));
  box-shadow: var(--ml-shadow-1, 0 4px 18px rgba(0, 0, 0, 0.18));
}
groupselectone--ml-discrete-slider-glass .ml-slider-label {
  font-family: var(--ml-font-family, 'Inter', system-ui, sans-serif);
  color: var(--ml-on-surface-muted, rgba(255, 255, 255, 0.55));
  transition: color var(--ml-transition, 250ms ease), font-weight var(--ml-transition, 250ms ease);
}
groupselectone--ml-discrete-slider-glass .ml-slider-label-active {
  font-family: var(--ml-font-family, 'Inter', system-ui, sans-serif);
  color: var(--ml-on-surface, rgba(255, 255, 255, 0.95));
  font-weight: var(--ml-font-weight-medium, 600);
}
groupselectone--ml-discrete-slider-glass .ml-slider-label-disabled {
  opacity: var(--ml-disabled-opacity, 0.5);
}
`);
    }
};
MlDiscreteSliderMoleculeGlass = __decorate([
    customElement('groupselectone--ml-discrete-slider-glass')
], MlDiscreteSliderMoleculeGlass);
export { MlDiscreteSliderMoleculeGlass };
