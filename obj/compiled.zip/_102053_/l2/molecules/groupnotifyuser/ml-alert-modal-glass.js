var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102053_/l2/molecules/groupnotifyuser/ml-alert-modal-glass.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// ALERT MODAL — GLASSMORPHISM (mls-102053)
// =============================================================================
// Skill Group: groupNotifyUser
// Casca (estratégia D): herda tudo de MlAlertModalMolecule (mls-102040),
// inclusive render() — o markup base emite classes semânticas ml-*; a aparência
// vem do .less irmão, escopado sob esta tag.
// This molecule does NOT contain business logic.
import { customElement } from 'lit/decorators.js';
import { MlAlertModalMolecule } from '/_102040_/l2/molecules/groupnotifyuser/ml-alert-modal.js';
let MlAlertModalMoleculeGlass = class MlAlertModalMoleculeGlass extends MlAlertModalMolecule {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(`groupnotifyuser--ml-alert-modal-glass {
  --ml-font-family: 'Inter', system-ui, sans-serif;
  --ml-font-weight-medium: 600;
  --ml-radius-sm: 12px;
  --ml-radius-lg: 14px;
  --ml-border-width: 1px;
  --ml-outline-variant: rgba(255, 255, 255, 0.25);
  --ml-outline-focus: rgba(199, 210, 254, 0.9);
  --ml-outline-error: rgba(255, 120, 120, 0.85);
  --ml-primary: rgba(99, 102, 241, 0.55);
  --ml-on-primary: #ffffff;
  --ml-surface: rgba(255, 255, 255, 0.1);
  --ml-surface-dim: rgba(30, 27, 75, 0.55);
  --ml-on-surface: rgba(255, 255, 255, 0.95);
  --ml-on-surface-muted: rgba(255, 255, 255, 0.55);
  --ml-on-surface-faint: rgba(255, 255, 255, 0.35);
  --ml-error: #ffb4ab;
  --ml-error-bg: rgba(244, 63, 94, 0.55);
  --ml-shadow-1: 0 4px 18px rgba(0, 0, 0, 0.18);
  --ml-shadow-2: 0 6px 24px rgba(0, 0, 0, 0.26);
  --ml-transition: 250ms ease;
  --ml-focus-ring-width: 3px;
  --ml-focus-ring-color: rgba(199, 210, 254, 0.3);
  --ml-disabled-opacity: 0.5;
  --ml-backdrop-blur: 10px;
  --ml-backdrop-blur-strong: 18px;
  --ml-info-border: rgba(147, 197, 253, 0.45);
  --ml-success-border: rgba(110, 231, 183, 0.45);
  --ml-warning-border: rgba(252, 211, 77, 0.45);
  --ml-success: rgba(110, 231, 183, 0.95);
  --ml-success-dim: rgba(16, 185, 129, 0.18);
  --ml-warning: rgba(252, 211, 77, 0.95);
  --ml-warning-dim: rgba(217, 119, 6, 0.18);
}
groupnotifyuser--ml-alert-modal-glass .ml-surface-bg {
  background: var(--ml-surface-dim, rgba(30, 27, 75, 0.55));
}
groupnotifyuser--ml-alert-modal-glass [role="alert"],
groupnotifyuser--ml-alert-modal-glass [role="status"] {
  position: relative;
  background: rgba(255, 255, 255, 0.08) !important;
  backdrop-filter: blur(var(--ml-backdrop-blur-strong, 18px));
  -webkit-backdrop-filter: blur(var(--ml-backdrop-blur-strong, 18px));
  border-radius: var(--ml-radius-lg, 14px);
  border: var(--ml-border-width, 1px) solid var(--ml-outline-variant, rgba(255, 255, 255, 0.25));
  box-shadow: 0 16px 44px rgba(0, 0, 0, 0.4), inset 0 1px 0 rgba(255, 255, 255, 0.35);
  transition: box-shadow var(--ml-transition, 250ms ease);
}
groupnotifyuser--ml-alert-modal-glass [role="alert"]::before,
groupnotifyuser--ml-alert-modal-glass [role="status"]::before {
  content: '';
  position: absolute;
  inset: 0;
  border-radius: inherit;
  border-top: 1px solid rgba(255, 255, 255, 0.5);
  border-left: 1px solid rgba(255, 255, 255, 0.25);
  pointer-events: none;
}
groupnotifyuser--ml-alert-modal-glass .ml-text {
  color: var(--ml-on-surface, rgba(255, 255, 255, 0.95));
  font-family: var(--ml-font-family, 'Inter', system-ui, sans-serif);
}
groupnotifyuser--ml-alert-modal-glass .ml-text-muted {
  color: var(--ml-on-surface-muted, rgba(255, 255, 255, 0.55));
  font-family: var(--ml-font-family, 'Inter', system-ui, sans-serif);
  transition: color var(--ml-transition, 250ms ease);
}
groupnotifyuser--ml-alert-modal-glass .ml-text-faint {
  color: var(--ml-on-surface-faint, rgba(255, 255, 255, 0.35));
  font-family: var(--ml-font-family, 'Inter', system-ui, sans-serif);
}
groupnotifyuser--ml-alert-modal-glass .ml-label {
  font-family: var(--ml-font-family, 'Inter', system-ui, sans-serif);
  font-weight: var(--ml-font-weight-medium, 600);
  color: var(--ml-on-surface, rgba(255, 255, 255, 0.95));
}
groupnotifyuser--ml-alert-modal-glass .ml-helper {
  color: var(--ml-on-surface-muted, rgba(255, 255, 255, 0.55));
  font-family: var(--ml-font-family, 'Inter', system-ui, sans-serif);
}
groupnotifyuser--ml-alert-modal-glass .ml-error-text {
  color: var(--ml-error, #ffb4ab);
  font-family: var(--ml-font-family, 'Inter', system-ui, sans-serif);
}
groupnotifyuser--ml-alert-modal-glass .ml-primary-text {
  color: rgba(199, 210, 254, 0.95);
  font-family: var(--ml-font-family, 'Inter', system-ui, sans-serif);
}
groupnotifyuser--ml-alert-modal-glass .ml-success-text {
  color: var(--ml-success, rgba(110, 231, 183, 0.95));
}
groupnotifyuser--ml-alert-modal-glass .ml-warning-text {
  color: var(--ml-warning, rgba(252, 211, 77, 0.95));
}
groupnotifyuser--ml-alert-modal-glass .ml-surface-dim-bg {
  background: var(--ml-surface-dim, rgba(30, 27, 75, 0.55));
}
groupnotifyuser--ml-alert-modal-glass .ml-primary-bg {
  background: var(--ml-primary, rgba(99, 102, 241, 0.55));
  color: var(--ml-on-primary, #ffffff);
}
groupnotifyuser--ml-alert-modal-glass .ml-primary-dim-bg {
  background: rgba(99, 102, 241, 0.22);
}
groupnotifyuser--ml-alert-modal-glass .ml-error-dim-bg {
  background: rgba(244, 63, 94, 0.22);
}
groupnotifyuser--ml-alert-modal-glass .ml-success-dim-bg {
  background: var(--ml-success-dim, rgba(16, 185, 129, 0.18));
}
groupnotifyuser--ml-alert-modal-glass .ml-warning-dim-bg {
  background: var(--ml-warning-dim, rgba(217, 119, 6, 0.18));
}
groupnotifyuser--ml-alert-modal-glass .ml-hover-bg {
  background: rgba(255, 255, 255, 0.12);
}
groupnotifyuser--ml-alert-modal-glass .ml-border {
  border-color: var(--ml-outline-variant, rgba(255, 255, 255, 0.25));
}
groupnotifyuser--ml-alert-modal-glass .ml-border-focus {
  border-color: var(--ml-outline-focus, rgba(199, 210, 254, 0.9));
}
groupnotifyuser--ml-alert-modal-glass .ml-border-error {
  border-color: var(--ml-outline-error, rgba(255, 120, 120, 0.85));
}
groupnotifyuser--ml-alert-modal-glass .ml-border-info {
  border-color: var(--ml-info-border, rgba(147, 197, 253, 0.45));
}
groupnotifyuser--ml-alert-modal-glass .ml-border-success {
  border-color: var(--ml-success-border, rgba(110, 231, 183, 0.45));
}
groupnotifyuser--ml-alert-modal-glass .ml-border-warning {
  border-color: var(--ml-warning-border, rgba(252, 211, 77, 0.45));
}
groupnotifyuser--ml-alert-modal-glass .ml-focus-ring {
  box-shadow: 0 0 0 var(--ml-focus-ring-width, 3px) var(--ml-focus-ring-color, rgba(199, 210, 254, 0.3));
}
groupnotifyuser--ml-alert-modal-glass .hover\:ml-text:hover {
  color: var(--ml-on-surface, rgba(255, 255, 255, 0.95));
  transition: color var(--ml-transition, 250ms ease);
}
groupnotifyuser--ml-alert-modal-glass .ml-disabled {
  opacity: var(--ml-disabled-opacity, 0.5);
  cursor: not-allowed;
  pointer-events: none;
}
`);
    }
};
MlAlertModalMoleculeGlass = __decorate([
    customElement('groupnotifyuser--ml-alert-modal-glass')
], MlAlertModalMoleculeGlass);
export { MlAlertModalMoleculeGlass };
