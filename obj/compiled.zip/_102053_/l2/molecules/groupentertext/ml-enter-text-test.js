var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102053_/l2/molecules/groupentertext/ml-enter-text-test.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// ML ENTER TEXT TEST MOLECULE
// =============================================================================
// Skill Group: groupEnterText
// This molecule does NOT contain business logic.
import { html } from 'lit';
import { customElement, state } from 'lit/decorators.js';
import { unsafeHTML } from 'lit/directives/unsafe-html.js';
import { propertyDataSource } from '/_102029_/l2/collabDecorators.js';
import { MoleculeAuraElement } from '/_102033_/l2/moleculeBase.js';
import { cn } from '/_102033_/l2/cn.js';
/// **collab_i18n_start**
const message_en = {
    emptyValue: '—',
    passwordMask: '••••••••',
};
const messages = {
    en: message_en,
};
/// **collab_i18n_end**
let MlEnterTextTestMolecule = class MlEnterTextTestMolecule extends MoleculeAuraElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`groupentertext--ml-enter-text-test .ml-input-container {
  background: var(--ml-surface, #ffffff);
  border: var(--ml-border-width, 1px) var(--ml-border-style, solid) var(--ml-outline-variant, #e2e8f0);
  border-radius: var(--ml-radius-sm, 6px);
  transition: border-color var(--ml-transition, 200ms ease), box-shadow var(--ml-transition, 200ms ease);
}
groupentertext--ml-enter-text-test .ml-input-container:focus-within {
  border-color: var(--ml-outline-focus, #3b82f6);
  box-shadow: 0 0 0 var(--ml-focus-ring-width, 2px) var(--ml-focus-ring-color, rgba(59, 130, 246, 0.4));
}
groupentertext--ml-enter-text-test .ml-input-container-error {
  border-color: var(--ml-outline-error, #ef4444) !important;
}
groupentertext--ml-enter-text-test .ml-input-container-error:focus-within {
  border-color: var(--ml-outline-error, #ef4444) !important;
  box-shadow: 0 0 0 var(--ml-focus-ring-width, 2px) var(--ml-focus-ring-color, rgba(59, 130, 246, 0.4));
}
groupentertext--ml-enter-text-test .ml-input {
  color: var(--ml-on-surface, #1c1b1f);
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
}
groupentertext--ml-enter-text-test .ml-input::placeholder {
  color: var(--ml-on-surface-faint, #79747e);
}
groupentertext--ml-enter-text-test .ml-label {
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
  font-weight: var(--ml-font-weight-medium, 500);
  color: var(--ml-on-surface, #1c1b1f);
}
groupentertext--ml-enter-text-test .ml-text {
  color: var(--ml-on-surface, #1c1b1f);
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
}
groupentertext--ml-enter-text-test .ml-text-muted {
  color: var(--ml-on-surface-muted, #49454f);
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
}
groupentertext--ml-enter-text-test .ml-error-text {
  color: var(--ml-error, #ef4444);
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
}
groupentertext--ml-enter-text-test .ml-helper {
  color: var(--ml-on-surface-muted, #49454f);
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
}
groupentertext--ml-enter-text-test .ml-disabled {
  opacity: var(--ml-disabled-opacity, 0.5);
  cursor: not-allowed;
  pointer-events: none;
}
groupentertext--ml-enter-text-test .ml-spinner {
  width: 1rem;
  height: 1rem;
  border: 2px solid var(--ml-outline-variant, #e2e8f0);
  border-top-color: var(--ml-primary, #3b82f6);
  border-radius: 50%;
  box-sizing: border-box;
}
`);
        this.msg = messages.en;
        // ===========================================================================
        // SLOT TAGS
        // ===========================================================================
        this.slotTags = ['Label', 'Helper', 'Prefix', 'Suffix'];
        // ===========================================================================
        // PROPERTIES — From Contract
        // ===========================================================================
        this.value = '';
        this.error = '';
        this.name = '';
        this.placeholder = '';
        this.maxLength = null;
        this.minLength = null;
        this.rows = 1;
        this.autocomplete = '';
        this.inputType = 'text';
        this.mask = '';
        this.isEditing = true;
        this.disabled = false;
        this.readonly = false;
        this.required = false;
        this.loading = false;
        // ===========================================================================
        // INTERNAL STATE
        // ===========================================================================
        this.rawDisplay = '';
        this.uid = `ml-enter-text-${Math.random().toString(36).slice(2)}`;
    }
    // ===========================================================================
    // STATE CHANGE HANDLER — derived state from value/mask
    // ===========================================================================
    handleIcaStateChange(key, value) {
        const valueAttr = this.getAttribute('value');
        const maskAttr = this.getAttribute('mask');
        const rowsAttr = this.getAttribute('rows');
        const inputTypeAttr = this.getAttribute('input-type');
        if (valueAttr === `{{${key}}}` ||
            maskAttr === `{{${key}}}` ||
            rowsAttr === `{{${key}}}` ||
            inputTypeAttr === `{{${key}}}`) {
            this.rawDisplay = this.hasMask()
                ? this.formatWithMask(String(value ?? ''))
                : '';
        }
        this.requestUpdate();
    }
    updated(changedProps) {
        if (changedProps.has('value') ||
            changedProps.has('mask') ||
            changedProps.has('rows') ||
            changedProps.has('inputType')) {
            if (this.hasMask()) {
                const formatted = this.formatWithMask(this.getValueString());
                if (this.rawDisplay !== formatted) {
                    this.rawDisplay = formatted;
                }
            }
            else if (this.rawDisplay !== '') {
                this.rawDisplay = '';
            }
        }
    }
    // ===========================================================================
    // EVENT HANDLERS
    // ===========================================================================
    handleInput(e) {
        e.stopPropagation();
        if (this.disabled || this.readonly || this.loading)
            return;
        const input = e.target;
        const current = String(input.value ?? '');
        if (this.hasMask()) {
            let raw = this.extractRaw(current, this.mask);
            raw = this.applyMaxLength(raw);
            this.value = raw;
            this.rawDisplay = this.formatWithMask(raw);
            input.value = this.rawDisplay;
        }
        else {
            let next = current;
            const max = this.getMaxLength();
            if (max !== null && next.length > max) {
                next = next.slice(0, max);
                input.value = next;
            }
            this.value = next;
        }
        this.dispatchEvent(new CustomEvent('input', {
            bubbles: true,
            composed: true,
            detail: { value: this.getValueString() }
        }));
    }
    handleTextareaInput(e) {
        e.stopPropagation();
        if (this.disabled || this.readonly || this.loading)
            return;
        const textarea = e.target;
        let next = String(textarea.value ?? '');
        const max = this.getMaxLength();
        if (max !== null && next.length > max) {
            next = next.slice(0, max);
            textarea.value = next;
        }
        this.value = next;
        this.dispatchEvent(new CustomEvent('input', {
            bubbles: true,
            composed: true,
            detail: { value: this.getValueString() }
        }));
    }
    handleChange(e) {
        e.stopPropagation();
        if (this.disabled || this.readonly || this.loading)
            return;
        this.dispatchEvent(new CustomEvent('change', {
            bubbles: true,
            composed: true,
            detail: { value: this.getValueString() }
        }));
    }
    handleFocus() {
        this.dispatchEvent(new CustomEvent('focus', {
            bubbles: true,
            composed: true,
        }));
    }
    handleBlur() {
        this.dispatchEvent(new CustomEvent('blur', {
            bubbles: true,
            composed: true,
        }));
    }
    // ===========================================================================
    // HELPERS
    // ===========================================================================
    getValueString() {
        return String(this.value ?? '');
    }
    getRowsValue() {
        const rows = Number(this.rows ?? 1);
        return Number.isNaN(rows) ? 1 : rows;
    }
    getMaxLength() {
        const max = this.maxLength;
        return typeof max === 'number' && !Number.isNaN(max) ? max : null;
    }
    getMinLength() {
        const min = this.minLength;
        return typeof min === 'number' && !Number.isNaN(min) ? min : null;
    }
    hasMask() {
        const rows = this.getRowsValue();
        return Boolean(this.mask) && rows <= 1 && this.inputType !== 'password';
    }
    applyMaxLength(raw) {
        const max = this.getMaxLength();
        if (max !== null && raw.length > max) {
            return raw.slice(0, max);
        }
        return raw;
    }
    isErrorState(valueString) {
        if (!this.isEditing)
            return false;
        const min = this.getMinLength();
        const minInvalid = min !== null && valueString.length < min;
        const requiredInvalid = this.required && valueString.length === 0;
        return Boolean(this.error) || minInvalid || requiredInvalid;
    }
    formatWithMask(raw) {
        if (!this.mask)
            return raw;
        const value = String(raw ?? '');
        let output = '';
        let rawIndex = 0;
        for (const maskChar of this.mask) {
            const isToken = maskChar === '#' || maskChar === 'A' || maskChar === '*';
            if (isToken) {
                if (rawIndex >= value.length)
                    break;
                output += value[rawIndex];
                rawIndex += 1;
            }
            else {
                if (value.length === 0)
                    break;
                output += maskChar;
            }
        }
        return output;
    }
    extractRaw(input, mask) {
        const tokens = Array.from(mask).filter((c) => c === '#' || c === 'A' || c === '*');
        let result = '';
        let tokenIndex = 0;
        for (const char of input) {
            if (tokenIndex >= tokens.length)
                break;
            const token = tokens[tokenIndex];
            const isValid = (token === '#' && /\d/.test(char)) ||
                (token === 'A' && /[a-zA-Z]/.test(char)) ||
                (token === '*' && /[\s\S]/.test(char));
            if (isValid) {
                result += char;
                tokenIndex += 1;
            }
        }
        return result;
    }
    getViewText(valueString) {
        if (!valueString)
            return this.msg.emptyValue;
        if (this.inputType === 'password')
            return this.msg.passwordMask;
        return valueString;
    }
    getInputContainerClasses(isError) {
        return [
            'relative flex w-full items-center gap-2 px-3 py-2',
            'ml-input-container',
            isError ? 'ml-input-container-error' : '',
            (this.disabled || this.loading) ? 'ml-disabled' : '',
        ].filter(Boolean).join(' ');
    }
    getViewContainerClasses() {
        return [
            'flex w-full items-center gap-2 px-3 py-2',
            'ml-text',
            (this.disabled || this.loading) ? 'ml-disabled' : '',
        ].filter(Boolean).join(' ');
    }
    getInputClasses() {
        return [
            'w-full bg-transparent outline-none',
            'ml-input',
        ].filter(Boolean).join(' ');
    }
    // ===========================================================================
    // RENDER
    // ===========================================================================
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        const valueString = this.getValueString();
        const isError = this.isErrorState(valueString);
        const rows = this.getRowsValue();
        const rootClasses = cn('flex w-full flex-col gap-1', this.cssClass);
        return html `
<div class="${rootClasses}">
${this.renderLabel()}
${this.isEditing
            ? html `
<div class="${this.getInputContainerClasses(isError)}">
${this.renderPrefix()}
${rows > 1 ? this.renderTextarea(valueString, isError) : this.renderInput(valueString, isError)}
${this.renderSuffix()}
${this.loading
                ? html `<div class="ml-spinner absolute right-3 top-1/2 -translate-y-1/2"></div>`
                : html ``}
</div>
${this.renderFeedback(isError)}
${rows > 1 ? this.renderCounter(valueString) : html ``}
`
            : html `
<div class="${this.getViewContainerClasses()}">
${this.renderPrefix()}
<span class="ml-text">${this.getViewText(valueString)}</span>
${this.renderSuffix()}
</div>
`}
</div>
`;
    }
    renderLabel() {
        if (!this.hasSlot('Label'))
            return html ``;
        return html `
<label
id="${this.uid}-label"
class="${cn('ml-label', this.getSlotClass('Label'))}"
>
${unsafeHTML(this.getSlotContent('Label'))}
</label>
`;
    }
    renderPrefix() {
        if (!this.hasSlot('Prefix'))
            return html ``;
        return html `
<div class="${cn('ml-text-muted', this.getSlotClass('Prefix'))}">
${unsafeHTML(this.getSlotContent('Prefix'))}
</div>
`;
    }
    renderSuffix() {
        if (!this.hasSlot('Suffix'))
            return html ``;
        return html `
<div class="${cn('ml-text-muted', this.getSlotClass('Suffix'))}">
${unsafeHTML(this.getSlotContent('Suffix'))}
</div>
`;
    }
    renderInput(valueString, isError) {
        const describedBy = this.getDescribedBy(isError);
        const displayValue = this.hasMask() ? this.rawDisplay : valueString;
        const max = this.getMaxLength();
        const shouldSetMax = !this.hasMask() && max !== null ? max : undefined;
        return html `
<input
class="${this.getInputClasses()}"
.type="${this.inputType}"
.value="${displayValue}"
.name="${this.name}"
.placeholder="${this.placeholder ?? ''}"
.autocomplete="${this.autocomplete ?? ''}"
?disabled="${this.disabled || this.loading}"
?readonly="${this.readonly}"
?required="${this.required}"
maxlength="${shouldSetMax !== undefined ? String(shouldSetMax) : ''}"
aria-labelledby="${this.hasSlot('Label') ? `${this.uid}-label` : ''}"
aria-describedby="${describedBy}"
aria-invalid="${isError ? 'true' : 'false'}"
aria-required="${this.required ? 'true' : 'false'}"
@input="${this.handleInput}"
@change="${this.handleChange}"
@focus="${this.handleFocus}"
@blur="${this.handleBlur}"
/>
`;
    }
    renderTextarea(valueString, isError) {
        const describedBy = this.getDescribedBy(isError, true);
        const max = this.getMaxLength();
        return html `
<textarea
class="${this.getInputClasses()}"
.rows="${String(this.getRowsValue())}"
.name="${this.name}"
.placeholder="${this.placeholder ?? ''}"
.autocomplete="${this.autocomplete ?? ''}"
?disabled="${this.disabled || this.loading}"
?readonly="${this.readonly}"
?required="${this.required}"
maxlength="${max !== null ? String(max) : ''}"
aria-labelledby="${this.hasSlot('Label') ? `${this.uid}-label` : ''}"
aria-describedby="${describedBy}"
aria-invalid="${isError ? 'true' : 'false'}"
aria-required="${this.required ? 'true' : 'false'}"
@input="${this.handleTextareaInput}"
@change="${this.handleChange}"
@focus="${this.handleFocus}"
@blur="${this.handleBlur}"
>${valueString}</textarea>
`;
    }
    renderFeedback(isError) {
        if (isError && this.error) {
            return html `
<p id="${this.uid}-error" class="${cn('text-xs ml-error-text')}">
${unsafeHTML(String(this.error))}
</p>
`;
        }
        if (!isError && this.hasSlot('Helper')) {
            return html `
<p id="${this.uid}-helper" class="${cn('text-xs ml-helper', this.getSlotClass('Helper'))}">
${unsafeHTML(this.getSlotContent('Helper'))}
</p>
`;
        }
        return html ``;
    }
    renderCounter(valueString) {
        const max = this.getMaxLength();
        if (max === null)
            return html ``;
        const count = valueString.length;
        return html `
<p
id="${this.uid}-counter"
class="${cn('text-xs ml-text-muted')}"
aria-live="polite"
>
${count} / ${max}
</p>
`;
    }
    getDescribedBy(isError, isTextarea = false) {
        if (!this.isEditing)
            return '';
        const ids = [];
        if (isError && this.error)
            ids.push(`${this.uid}-error`);
        if (!isError && this.hasSlot('Helper'))
            ids.push(`${this.uid}-helper`);
        if (isTextarea && this.getMaxLength() !== null)
            ids.push(`${this.uid}-counter`);
        return ids.join(' ');
    }
};
__decorate([
    propertyDataSource({ type: String })
], MlEnterTextTestMolecule.prototype, "value", void 0);
__decorate([
    propertyDataSource({ type: String })
], MlEnterTextTestMolecule.prototype, "error", void 0);
__decorate([
    propertyDataSource({ type: String })
], MlEnterTextTestMolecule.prototype, "name", void 0);
__decorate([
    propertyDataSource({ type: String })
], MlEnterTextTestMolecule.prototype, "placeholder", void 0);
__decorate([
    propertyDataSource({ type: Number, attribute: 'max-length' })
], MlEnterTextTestMolecule.prototype, "maxLength", void 0);
__decorate([
    propertyDataSource({ type: Number, attribute: 'min-length' })
], MlEnterTextTestMolecule.prototype, "minLength", void 0);
__decorate([
    propertyDataSource({ type: Number })
], MlEnterTextTestMolecule.prototype, "rows", void 0);
__decorate([
    propertyDataSource({ type: String })
], MlEnterTextTestMolecule.prototype, "autocomplete", void 0);
__decorate([
    propertyDataSource({ type: String, attribute: 'input-type' })
], MlEnterTextTestMolecule.prototype, "inputType", void 0);
__decorate([
    propertyDataSource({ type: String })
], MlEnterTextTestMolecule.prototype, "mask", void 0);
__decorate([
    propertyDataSource({ type: Boolean, attribute: 'is-editing' })
], MlEnterTextTestMolecule.prototype, "isEditing", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MlEnterTextTestMolecule.prototype, "disabled", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MlEnterTextTestMolecule.prototype, "readonly", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MlEnterTextTestMolecule.prototype, "required", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MlEnterTextTestMolecule.prototype, "loading", void 0);
__decorate([
    state()
], MlEnterTextTestMolecule.prototype, "rawDisplay", void 0);
__decorate([
    state()
], MlEnterTextTestMolecule.prototype, "uid", void 0);
MlEnterTextTestMolecule = __decorate([
    customElement('groupentertext--ml-enter-text-test')
], MlEnterTextTestMolecule);
export { MlEnterTextTestMolecule };
