var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102053_/l2/glassshowcase2/demolotee.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// GLASS SHOWCASE 2 (mls-102055 por herança) — DEMO LOTE E (navegação)
// =============================================================================
import { html } from 'lit';
import { customElement, state } from 'lit/decorators.js';
import { StateLitElement } from '/_102029_/l2/stateLitElement.js';
import '/_102055_/l2/molecules/groupnavigatesection/ml-tabs-glass';
import '/_102055_/l2/molecules/groupnavigatesection/ml-navigate-pills-glass';
import '/_102055_/l2/molecules/groupnavigatesection/ml-breadcrumb-trail-glass';
import '/_102055_/l2/molecules/groupnavigatemain/ml-sidebar-nav-glass';
import '/_102055_/l2/molecules/groupnavigatesteps/ml-horizontal-stepper-glass';
import '/_102055_/l2/molecules/groupnavigatesteps/ml-wizard-steps-glass';
let GlassShowcase2DemoLoteE = class GlassShowcase2DemoLoteE extends StateLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`@font-face {
  font-family: 'Inter';
  font-style: normal;
  font-weight: 400;
  font-display: swap;
  src: url(https://fonts.gstatic.com/s/inter/v20/UcCO3FwrK3iLTeHuS_nVMrMxCp50SjIw2boKoduKmMEVuLyfMZg.ttf) format('truetype');
}
@font-face {
  font-family: 'Inter';
  font-style: normal;
  font-weight: 500;
  font-display: swap;
  src: url(https://fonts.gstatic.com/s/inter/v20/UcCO3FwrK3iLTeHuS_nVMrMxCp50SjIw2boKoduKmMEVuI6fMZg.ttf) format('truetype');
}
@font-face {
  font-family: 'Inter';
  font-style: normal;
  font-weight: 600;
  font-display: swap;
  src: url(https://fonts.gstatic.com/s/inter/v20/UcCO3FwrK3iLTeHuS_nVMrMxCp50SjIw2boKoduKmMEVuGKYMZg.ttf) format('truetype');
}
@font-face {
  font-family: 'Inter';
  font-style: normal;
  font-weight: 700;
  font-display: swap;
  src: url(https://fonts.gstatic.com/s/inter/v20/UcCO3FwrK3iLTeHuS_nVMrMxCp50SjIw2boKoduKmMEVuFuYMZg.ttf) format('truetype');
}
glassshowcase2--demolotee-102053 {
  display: block;
  font-family: 'Inter', system-ui, sans-serif;
}
glassshowcase2--demolotee-102053 .page {
  min-height: 100vh;
  padding: 2.5rem 2rem;
  background: radial-gradient(circle at 15% 15%, #4c1d95 0%, transparent 55%), radial-gradient(circle at 85% 85%, #be185d 0%, transparent 50%), linear-gradient(135deg, #0b1220 0%, #1e1b4b 100%);
  background-attachment: fixed;
}
glassshowcase2--demolotee-102053 .shell {
  max-width: 40rem;
  margin: 0 auto;
}
glassshowcase2--demolotee-102053 .head {
  text-align: center;
  margin-bottom: 2.5rem;
}
glassshowcase2--demolotee-102053 .brand {
  color: #c7d2fe;
  font-weight: 700;
  letter-spacing: 0.05em;
  margin-bottom: 0.5rem;
}
glassshowcase2--demolotee-102053 .title {
  color: #fff;
  font-size: 1.625rem;
  font-weight: 700;
  margin-bottom: 0.25rem;
}
glassshowcase2--demolotee-102053 .subtitle {
  color: rgba(255, 255, 255, 0.65);
  font-size: 0.8125rem;
}
glassshowcase2--demolotee-102053 .block {
  margin-bottom: 2rem;
  background: rgba(255, 255, 255, 0.05);
  border: 1px solid rgba(255, 255, 255, 0.12);
  border-radius: 16px;
  padding: 1.5rem;
  backdrop-filter: blur(6px);
  -webkit-backdrop-filter: blur(6px);
}
glassshowcase2--demolotee-102053 .block-title {
  color: rgba(255, 255, 255, 0.55);
  font-size: 0.75rem;
  font-weight: 600;
  text-transform: uppercase;
  letter-spacing: 0.08em;
  margin-bottom: 0.75rem;
}
`);
        this.bc = 'eletronicos';
        this.pill = 'overview';
        this.tab = 'details';
        this.navItem = 'dashboard';
        this.stepper = 1;
        this.wizard = 1;
    }
    render() {
        return html `
      <div class="page">
        <div class="shell">
          <header class="head">
            <div class="brand">◆ Aurora · 102055</div>
            <h1 class="title">Lote E — Navegação (por herança)</h1>
            <p class="subtitle">tabs · pills · breadcrumb · sidebar · stepper · wizard</p>
          </header>

          <section class="block">
            <h2 class="block-title">Breadcrumb</h2>
            <groupnavigatesection--ml-breadcrumb-trail-glass
              .value=${this.bc}
              @change=${(e) => { this.bc = e.detail.value; }}
            >
              <Tab value="home" title="Início">Página inicial.</Tab>
              <Tab value="catalogo" title="Catálogo">Lista de categorias.</Tab>
              <Tab value="eletronicos" title="Eletrônicos">Categoria de eletrônicos.</Tab>
              <Tab value="produto" title="Notebook Pro">Detalhes do produto atual.</Tab>
            </groupnavigatesection--ml-breadcrumb-trail-glass>
          </section>

          <section class="block">
            <h2 class="block-title">Pills</h2>
            <groupnavigatesection--ml-navigate-pills-glass
              .value=${this.pill}
              @change=${(e) => { this.pill = e.detail.value; }}
            >
              <Label>Seções</Label>
              <Tab value="overview" title="Visão geral">Resumo do projeto.</Tab>
              <Tab value="timeline" title="Cronograma">Marcos e entregas.</Tab>
              <Tab value="team" title="Equipe">Pessoas envolvidas.</Tab>
            </groupnavigatesection--ml-navigate-pills-glass>
          </section>

          <section class="block">
            <h2 class="block-title">Tabs</h2>
            <groupnavigatesection--ml-tabs-glass
              .value=${this.tab}
              @change=${(e) => { this.tab = e.detail.value; }}
            >
              <Label>Produto</Label>
              <Tab value="details" title="Detalhes">Especificações do produto.</Tab>
              <Tab value="reviews" title="Avaliações">Comentários dos clientes.</Tab>
              <Tab value="shipping" title="Entrega">Prazos e custos.</Tab>
            </groupnavigatesection--ml-tabs-glass>
          </section>

          <section class="block">
            <h2 class="block-title">Sidebar</h2>
            <div style="height:22rem; border-radius:14px; overflow:hidden; display:flex;">
              <groupnavigatemain--ml-sidebar-nav-glass
                .value=${this.navItem}
                @change=${(e) => { this.navItem = e.detail.value; }}
              >
                <Label>Aurora</Label>
                <Item value="dashboard" icon="▦">Dashboard</Item>
                <Item value="projects" icon="▤" badge="3">Projetos</Item>
                <Group label="Workspace">
                  <Item value="tasks" icon="✓">Tarefas</Item>
                  <Item value="calendar" icon="▣">Calendário</Item>
                </Group>
                <Footer>
                  <Item value="settings" icon="⚙">Configurações</Item>
                </Footer>
              </groupnavigatemain--ml-sidebar-nav-glass>
            </div>
          </section>

          <section class="block">
            <h2 class="block-title">Horizontal Stepper</h2>
            <groupnavigatesteps--ml-horizontal-stepper-glass
              .value=${this.stepper}
              @change=${(e) => { this.stepper = e.detail.value; }}
            >
              <Label>Cadastro</Label>
              <Step title="Conta" description="Dados de acesso"></Step>
              <Step title="Perfil" description="Informações pessoais"></Step>
              <Step title="Pagamento" description="Plano e cobrança"></Step>
              <Step title="Pronto" description="Revisão final"></Step>
            </groupnavigatesteps--ml-horizontal-stepper-glass>
          </section>

          <section class="block">
            <h2 class="block-title">Wizard Steps</h2>
            <groupnavigatesteps--ml-wizard-steps-glass
              .value=${this.wizard}
              .linear=${false}
              @change=${(e) => { this.wizard = e.detail.value; }}
            >
              <Label>Onboarding</Label>
              <Step title="Conta" description="Acesso" completed></Step>
              <Step title="Perfil" description="Dados pessoais"></Step>
              <Step title="Plano" description="Escolha do plano"></Step>
            </groupnavigatesteps--ml-wizard-steps-glass>
          </section>
        </div>
      </div>
    `;
    }
};
__decorate([
    state()
], GlassShowcase2DemoLoteE.prototype, "bc", void 0);
__decorate([
    state()
], GlassShowcase2DemoLoteE.prototype, "pill", void 0);
__decorate([
    state()
], GlassShowcase2DemoLoteE.prototype, "tab", void 0);
__decorate([
    state()
], GlassShowcase2DemoLoteE.prototype, "navItem", void 0);
__decorate([
    state()
], GlassShowcase2DemoLoteE.prototype, "stepper", void 0);
__decorate([
    state()
], GlassShowcase2DemoLoteE.prototype, "wizard", void 0);
GlassShowcase2DemoLoteE = __decorate([
    customElement('glassshowcase2--demolotee-102053')
], GlassShowcase2DemoLoteE);
export { GlassShowcase2DemoLoteE };
