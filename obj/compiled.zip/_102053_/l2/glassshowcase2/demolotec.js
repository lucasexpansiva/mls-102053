var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102053_/l2/glassshowcase2/demolotec.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// GLASS SHOWCASE 2 (mls-102055 por herança) — DEMO LOTE C (pickers data/hora)
// =============================================================================
import { html } from 'lit';
import { customElement, state } from 'lit/decorators.js';
import { StateLitElement } from '/_102029_/l2/stateLitElement.js';
import '/_102055_/l2/molecules/groupenterdatetime/ml-datetime-picker-glass';
import '/_102055_/l2/molecules/groupentertime/ml-clock-time-picker-glass';
let GlassShowcase2DemoLoteC = class GlassShowcase2DemoLoteC extends StateLitElement {
    constructor() {
        super(...arguments);
        this.dt = '2026-06-18T14:30:00';
        this.time = '14:30';
    }
    render() {
        return html `
      <div class="page">
        <div class="shell">
          <header class="head">
            <div class="brand">◆ Aurora · 102055</div>
            <h1 class="title">Lote C — Pickers de data/hora (por herança)</h1>
            <p class="subtitle">datetime-picker · clock-time-picker</p>
          </header>

          <section class="block">
            <h2 class="block-title">Datetime Picker</h2>
            <groupenterdatetime--ml-datetime-picker-glass
              .value=${this.dt}
              locale="pt-BR"
              minute-step="15"
              @change=${(e) => { this.dt = e.detail.value; }}
            >
              <Label>Agendamento</Label>
              <Helper>Selecionado: ${this.dt ?? '—'}</Helper>
            </groupenterdatetime--ml-datetime-picker-glass>
          </section>

          <section class="block">
            <h2 class="block-title">Clock Time Picker</h2>
            <groupentertime--ml-clock-time-picker-glass
              .value=${this.time}
              locale="pt-BR"
              minute-step="5"
              @change=${(e) => { this.time = e.detail.value; }}
            >
              <Label>Horário</Label>
              <Helper>Selecionado: ${this.time ?? '—'}</Helper>
            </groupentertime--ml-clock-time-picker-glass>
          </section>
        </div>
      </div>
    `;
    }
};
__decorate([
    state()
], GlassShowcase2DemoLoteC.prototype, "dt", void 0);
__decorate([
    state()
], GlassShowcase2DemoLoteC.prototype, "time", void 0);
GlassShowcase2DemoLoteC = __decorate([
    customElement('glassshowcase2--demolotec-102053')
], GlassShowcase2DemoLoteC);
export { GlassShowcase2DemoLoteC };
