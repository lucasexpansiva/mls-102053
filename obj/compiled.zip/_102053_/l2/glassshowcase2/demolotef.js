var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102053_/l2/glassshowcase2/demolotef.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// GLASS SHOWCASE 2 (mls-102055 por herança) — DEMO LOTE F (expand / notify)
// =============================================================================
import { html } from 'lit';
import { customElement, state } from 'lit/decorators.js';
import { StateLitElement } from '/_102029_/l2/stateLitElement.js';
import '/_102055_/l2/molecules/groupexpandcontent/ml-accordion-glass';
import '/_102055_/l2/molecules/groupexpandcontent/ml-collapsible-panel-glass';
import '/_102055_/l2/molecules/groupexpandcontent/ml-reveal-overlay-glass';
import '/_102055_/l2/molecules/groupnotifyuser/ml-alert-modal-glass';
import '/_102055_/l2/molecules/groupnotifyuser/ml-notify-banner-glass';
import '/_102055_/l2/molecules/groupnotifyuser/ml-toast-notification-glass';
let GlassShowcase2DemoLoteF = class GlassShowcase2DemoLoteF extends StateLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`@font-face {
  font-family: 'Inter';
  font-style: normal;
  font-weight: 400;
  font-display: swap;
  src: url(https://fonts.gstatic.com/s/inter/v20/UcCO3FwrK3iLTeHuS_nVMrMxCp50SjIw2boKoduKmMEVuLyfMZg.ttf) format('truetype');
}
@font-face {
  font-family: 'Inter';
  font-style: normal;
  font-weight: 500;
  font-display: swap;
  src: url(https://fonts.gstatic.com/s/inter/v20/UcCO3FwrK3iLTeHuS_nVMrMxCp50SjIw2boKoduKmMEVuI6fMZg.ttf) format('truetype');
}
@font-face {
  font-family: 'Inter';
  font-style: normal;
  font-weight: 600;
  font-display: swap;
  src: url(https://fonts.gstatic.com/s/inter/v20/UcCO3FwrK3iLTeHuS_nVMrMxCp50SjIw2boKoduKmMEVuGKYMZg.ttf) format('truetype');
}
@font-face {
  font-family: 'Inter';
  font-style: normal;
  font-weight: 700;
  font-display: swap;
  src: url(https://fonts.gstatic.com/s/inter/v20/UcCO3FwrK3iLTeHuS_nVMrMxCp50SjIw2boKoduKmMEVuFuYMZg.ttf) format('truetype');
}
glassshowcase2--demolotef-102053 {
  display: block;
  font-family: 'Inter', system-ui, sans-serif;
}
glassshowcase2--demolotef-102053 .page {
  min-height: 100vh;
  padding: 2.5rem 2rem;
  background: radial-gradient(circle at 15% 15%, #4c1d95 0%, transparent 55%), radial-gradient(circle at 85% 85%, #be185d 0%, transparent 50%), linear-gradient(135deg, #0b1220 0%, #1e1b4b 100%);
  background-attachment: fixed;
}
glassshowcase2--demolotef-102053 .shell {
  max-width: 40rem;
  margin: 0 auto;
}
glassshowcase2--demolotef-102053 .head {
  text-align: center;
  margin-bottom: 2.5rem;
}
glassshowcase2--demolotef-102053 .brand {
  color: #c7d2fe;
  font-weight: 700;
  letter-spacing: 0.05em;
  margin-bottom: 0.5rem;
}
glassshowcase2--demolotef-102053 .title {
  color: #fff;
  font-size: 1.625rem;
  font-weight: 700;
  margin-bottom: 0.25rem;
}
glassshowcase2--demolotef-102053 .subtitle {
  color: rgba(255, 255, 255, 0.65);
  font-size: 0.8125rem;
}
glassshowcase2--demolotef-102053 .block {
  margin-bottom: 2rem;
  background: rgba(255, 255, 255, 0.05);
  border: 1px solid rgba(255, 255, 255, 0.12);
  border-radius: 16px;
  padding: 1.5rem;
  backdrop-filter: blur(6px);
  -webkit-backdrop-filter: blur(6px);
}
glassshowcase2--demolotef-102053 .block-title {
  color: rgba(255, 255, 255, 0.55);
  font-size: 0.75rem;
  font-weight: 600;
  text-transform: uppercase;
  letter-spacing: 0.08em;
  margin-bottom: 0.75rem;
}
`);
        this.bannerVisible = true;
        this.toastVisible = true;
        this.modalOpen = false;
    }
    render() {
        return html `
      <div class="page">
        <div class="shell">
          <header class="head">
            <div class="brand">◆ Aurora · 102055</div>
            <h1 class="title">Lote F — Expand / Notify (por herança)</h1>
            <p class="subtitle">accordion · collapsible · reveal · alert-modal · banner · toast</p>
          </header>

          <section class="block">
            <h2 class="block-title">Accordion</h2>
            <groupexpandcontent--ml-accordion-glass multiple="true">
              <Label>Project details</Label>
              <Section title="Overview" expanded>Share the project scope and expected outcomes.</Section>
              <Section title="Timeline">Milestones are due every Friday.</Section>
              <Section title="Risks">Track vendor delays closely.</Section>
            </groupexpandcontent--ml-accordion-glass>
          </section>

          <section class="block">
            <h2 class="block-title">Collapsible Panel</h2>
            <groupexpandcontent--ml-collapsible-panel-glass>
              <Label>Perguntas frequentes</Label>
              <Section title="Como começar?" subtitle="Primeiros passos" icon="🚀" expanded>
                Crie a conta e siga o onboarding.
              </Section>
              <Section title="Posso cancelar?" subtitle="Assinatura">Sim, a qualquer momento.</Section>
            </groupexpandcontent--ml-collapsible-panel-glass>
          </section>

          <section class="block">
            <h2 class="block-title">Reveal Overlay</h2>
            <groupexpandcontent--ml-reveal-overlay-glass multiple="true">
              <Label>Conteúdo oculto até revelar</Label>
              <Section title="Chave de API">sk-live-9f8a7b6c5d4e3f2a1b0c9d8e7f6a5b4c</Section>
              <Section title="Token">eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...</Section>
            </groupexpandcontent--ml-reveal-overlay-glass>
          </section>

          <section class="block">
            <h2 class="block-title">Notify Banner</h2>
            <groupnotifyuser--ml-notify-banner-glass
              type="info"
              .visible=${this.bannerVisible}
              @dismiss=${() => {
            this.bannerVisible = false;
        }}
            >
              <Title>Atualização disponível</Title>
              <Message>Uma nova versão está pronta para instalar.</Message>
              <Action>Atualizar</Action>
            </groupnotifyuser--ml-notify-banner-glass>
            ${!this.bannerVisible
            ? html `<button
                  style="margin-top:0.75rem; padding:0.4rem 0.9rem; border-radius:10px; border:1px solid rgba(255,255,255,0.25); background:rgba(255,255,255,0.1); color:#fff; cursor:pointer; font-size:0.8125rem;"
                  @click=${() => {
                this.bannerVisible = true;
            }}
                >
                  Mostrar banner
                </button>`
            : html ``}
          </section>

          <section class="block">
            <h2 class="block-title">Toast Notification</h2>
            <groupnotifyuser--ml-toast-notification-glass
              type="success"
              .visible=${this.toastVisible}
              @dismiss=${() => {
            this.toastVisible = false;
        }}
            >
              <Title>Salvo!</Title>
              <Message>Suas alterações foram salvas.</Message>
            </groupnotifyuser--ml-toast-notification-glass>
            ${!this.toastVisible
            ? html `<button
                  style="margin-top:0.75rem; padding:0.4rem 0.9rem; border-radius:10px; border:1px solid rgba(255,255,255,0.25); background:rgba(255,255,255,0.1); color:#fff; cursor:pointer; font-size:0.8125rem;"
                  @click=${() => {
                this.toastVisible = true;
            }}
                >
                  Mostrar toast
                </button>`
            : html ``}
          </section>

          <section class="block">
            <h2 class="block-title">Alert Modal</h2>
            <button
              style="padding:0.5rem 1rem; border-radius:10px; border:1px solid rgba(255,255,255,0.25); background:rgba(255,255,255,0.12); color:#fff; cursor:pointer;"
              @click=${() => {
            this.modalOpen = true;
        }}
            >
              Abrir modal
            </button>
          </section>
        </div>

        <groupnotifyuser--ml-alert-modal-glass
          type="warning"
          .visible=${this.modalOpen}
          @dismiss=${() => {
            this.modalOpen = false;
        }}
        >
          <Title>Confirmar ação</Title>
          <Message>O scrim desfoca esta página atrás do modal.</Message>
        </groupnotifyuser--ml-alert-modal-glass>
      </div>
    `;
    }
};
__decorate([
    state()
], GlassShowcase2DemoLoteF.prototype, "bannerVisible", void 0);
__decorate([
    state()
], GlassShowcase2DemoLoteF.prototype, "toastVisible", void 0);
__decorate([
    state()
], GlassShowcase2DemoLoteF.prototype, "modalOpen", void 0);
GlassShowcase2DemoLoteF = __decorate([
    customElement('glassshowcase2--demolotef-102053')
], GlassShowcase2DemoLoteF);
export { GlassShowcase2DemoLoteF };
