declare module "_102027_/l2/collabImport" {
    interface CollabImportOptions {
        project: number;
        shortName: string;
        folder: string;
        extension?: '.defs.ts' | '.ts' | '.test.ts';
    }
    export function collabImport(opts: CollabImportOptions): Promise<any>;
}
declare module "_102027_/l2/utils" {
    export function getPath(widget: string): mls.stor.IFileInfoBase | undefined;
    export function convertTagToFileName(tag: string): {
        shortName: string;
        project: number;
        folder: string;
    } | undefined;
    export function convertFileNameToTag(info: {
        shortName: string;
        project: number;
        folder?: string;
    }): string;
    export function setErrorOnModel(model: monaco.editor.ITextModel, line: number, startColumn: number, endColumn: number, message: string, severity: monaco.MarkerSeverity): void;
}
declare module "_102027_/l2/libCompile" {
    export const getDependenciesByHtmlFile: (file: mls.stor.IFileInfo, html: string, theme: string, withCss?: boolean) => Promise<IJSONDependence>;
    export const getDependenciesByHtml: (models: mls.editor.IModels, html: string, theme: string, withCss?: boolean) => Promise<IJSONDependence>;
    export const getDependenciesByMFile: (models: mls.editor.IModels, withCss?: boolean) => Promise<IJSONDependence>;
    export function getAllWebComponentsInSource(source: string): string[];
    export interface IJSONDependence {
        file: string;
        wcComponents: string[];
        importsMap: string[];
        importsJs: string[];
        importsLinks: {
            ref: string;
            rel: string;
        }[];
        tokens: string | undefined;
        globalCss: string;
        dsGlobalCss?: string;
        errors: {
            tag: string;
            error: string;
        }[];
    }
}
declare module "_102027_/l2/libCommom" {
    export function getMyKeysBranch(project: number): {
        branch: string;
        owner: string;
        repo: string;
    };
    export function createPath(project: number, shortName: string, folder: string): string;
    export function generateCompactTimestamp(): string;
    export function getDateFormated(dt: string): string;
    export function changeFavIcon(notification: boolean): void;
    export function checkIfHasLocalProject(): boolean;
    export function getLocalProjectName(): string;
    export function setLocalProjectName(prjName: string): void;
    export function getLocalProjectDependencies(): number[];
    export function setLocalProjectDependencies(dependencies: number[]): void;
    export function deleteLocalProject(): Promise<void>;
    export function isValidProjectName(name: string): boolean;
    export function escapeHTML(str: string): string;
    export function openService(service: string, position: 'left' | 'right', level: number, args?: Record<string, string>): Promise<void>;
    export function selectLevel(level: number): void;
    export function forceServiceInstance(level: number, service: string): Promise<void>;
    export function loadFileHTMLInContainer(el: HTMLElement, shortName: string, project: number): Promise<void>;
    export function convertColorToHex(color: string): string;
    export function getEnhancementName(file: {
        project: number;
        shortName: string;
        folder: string;
        level: number;
    }): Promise<string>;
    export function getStyleEnhancementName(file: {
        project: number;
        shortName: string;
        folder: string;
        level: number;
    }): Promise<string | undefined>;
    export function loadPluginProject(project: number, scope: string, onlyEnabled?: boolean): Promise<mls.plugin.MenuAction[]>;
    export function setProjectDetails(project: number): void;
    export function getProjectDetails(): mls.stor.localStor.IRetProjectDetails | undefined;
    export function calculateTotalStringSize(source: string, limitBase: number): ICalculateTotalStringSize;
    export function getListNewFilesToDeleteByFolder(project: number, folder: string, includeDist?: boolean): Promise<mls.stor.IFileInfo[]>;
    export function deleteAllFilesLocal(filesToDelete: mls.stor.IFileInfo[]): AsyncGenerator<string, void, unknown>;
    export function loadModuleFromProjectOrDependency(name: string, folder: string, ext: string): Promise<any>;
    export function findStorFileInProjectsOrDeps(projectActual: number, level: number, fileName: string, folder: string, extension: string): mls.stor.IFileInfo;
    export function saveOpenedFile(project: number, level: number, file: OpenedFile): void;
    export function getLastOpenedFiles(project: number): UserOpenedFiles;
    export function deleteLastOpenedFiles(project: number): void;
    export function getLastModule(): Record<string, string>;
    export function setLastModule(project: number, moduleName: string): void;
    export function getBaseTemplate(file: IInfoFile, enhancement?: string): Promise<string>;
    export function verifyNeedAddTripleslach(info: mls.stor.IFileInfoBase, src: string, extension: string, enhancement?: string): string;
    export function getInstanceByFile(file: mls.stor.IFileInfo): Promise<Object | undefined>;
    export function isNameValid(project: number, shortName: string, folder: string, level: number, extension: string): boolean;
    export function openElementInServiceDetails(el: HTMLElement): Promise<void>;
    export function clearServiceDetails(): Promise<void>;
    export function getProjectConfig(project: number): Promise<IProjectConfig | undefined>;
    export function getProjectModuleConfig(path: string, project: number): Promise<IProjectModuleConfig | undefined>;
    export function getMessageKey(messages: any): string;
    export type OpenedFile = string | OpenedFileL2;
    export type UserOpenedFiles = Record<number, OpenedFile>;
    export type OpenedFileL2 = {
        left?: string;
        right?: string;
    };
    export interface IProjectModuleConfig {
        theme: string;
        initialPage: string;
        menu: IProjectModuleConfigMenu[];
    }
    export interface IProjectModuleConfigMenu {
        pageName: string;
        title: string;
        auth: string;
        icon?: string;
        target?: string;
    }
    export interface IProjectConfigModules {
        name: string;
        path: string;
        pathServer?: string;
        auth: string;
        icon?: string;
    }
    export interface IProjectConfig {
        masterFrontEnd?: {
            build: string;
            start: string;
            liveView: string;
        };
        masterBackEnd?: {
            build: string;
            start: string;
            serverView: string;
        };
        modules: IProjectConfigModules[];
    }
    interface ICalculateTotalStringSize {
        totalsize: number;
        exceededLimit: boolean;
        sizeFormatted: string;
    }
    interface IInfoFile {
        project: number;
        folder: string;
        shortName: string;
        extension: string;
    }
}
declare module "_102027_/l2/libMindMap" {
    export const allDefs: Record<string, IdefModule>;
    export function getAllDefs(): Promise<Record<string, IdefModule>>;
    export function getDefsByFile(file: mls.stor.IFileInfo): Promise<mls.defs.AsIs | undefined>;
    export function getMindMapByName(file: string): Promise<MindMapData | undefined>;
    export function getMindMapByStorFile(file: mls.stor.IFileInfo): Promise<MindMapData | undefined>;
    export function setMindMapVariable(bread: MindMapNode[]): void;
    export function getMindMapVariable(): MindMapNode[];
    export type MindMapSelected = MindMapSelectedFile | MindMapSelectedPlugin;
    export interface MindMapSelectedBase {
        plugin: Function;
        args: string;
    }
    export interface MindMapSelectedFile extends MindMapSelectedBase {
        type: "file";
        file: mls.stor.IFileInfo;
        organism?: string;
        widget?: string;
        modelType?: mls.editor.ModelType;
    }
    export interface MindMapSelectedPlugin extends MindMapSelectedBase {
        type: "plugin";
        file: mls.stor.IFileInfo;
    }
    export type MindMapNodeType = 'main' | 'asIs' | 'codeInsights' | 'webcomponent' | 'imports' | 'importedBy' | 'language' | 'attributes' | 'file' | 'file_wc' | 'text' | 'findFile' | 'findFile_item';
    export interface MindMapNode {
        id: string;
        label: string;
        type: MindMapNodeType;
        related: string[];
        meta: Record<string, any>;
        description?: string;
        navigate?: boolean;
    }
    export interface MindMapData {
        current: string;
        nodes: MindMapNode[];
    }
    export interface MindMapNodeStyle {
        fill: string;
        stroke: string;
        text: string;
    }
    export type MindMapNodeStyles = Record<string, MindMapNodeStyle>;
    export interface IdefModule {
        file: mls.stor.IFileInfo;
        defs: mls.defs.AsIs;
    }
}
declare module "_102027_/l2/libModel" {
    export function waitModelIdle(model: mls.editor.IModelBase | undefined): Promise<void>;
    export function readProjectTypescriptAndCompile(project: number, shortName: string, needCompile?: boolean): Promise<void>;
    export function readProjectTypescriptAndCompileL1(project: number, shortName: string, needCompile?: boolean): Promise<void>;
    export function createAllModels(storFileBase: mls.stor.IFileInfo, needCompile?: boolean, awaitCompile?: boolean, createStorIfNeed?: boolean): Promise<mls.editor.IModels | undefined>;
    export function createModel(storFile: mls.stor.IFileInfo, needCompile?: boolean, awaitCompile?: boolean): Promise<mls.editor.IModelBase | undefined>;
    export function setErrorOnModel(model: monaco.editor.ITextModel, line: number, startColumn: number, endColumn: number, message: string, severity: monaco.MarkerSeverity): void;
    export function createModelAnyFile(storFile: mls.stor.IFileInfo): Promise<mls.editor.IModelBase>;
    export function setModelEventAny(model: mls.editor.IModelBase, storFile: mls.stor.IFileInfo): void;
    export function _MarkCompileNeed(storFile: mls.stor.IFileInfo): Promise<void>;
    export interface IModelProcessing {
        begin(): void;
        end(): void;
        whenIdle(): Promise<void>;
        isProcessing(): boolean;
    }
    export class ModelProcessing implements IModelProcessing {
        private running;
        private idlePromise;
        private idleResolve;
        begin(): void;
        end(): void;
        whenIdle(): Promise<void>;
        isProcessing(): boolean;
    }
    export interface IModelBase extends mls.editor.IModelBase {
        changeTimeout?: number;
        processing?: IModelProcessing;
    }
}
declare module "_102027_/l2/designSystemBase" {
    export function getTokens(project: number): Promise<IDesignSystemTokens[]>;
    export function getTokensLess(project: number, theme: string): Promise<string>;
    export function getTokensLessByTokensArray(tokens: IDesignSystemTokens[], theme: string): Promise<string>;
    export function getTokensCss(project: number, theme: string): Promise<string>;
    export function getGlobalCss(project: number, theme: string): Promise<string>;
    export function getGlobalLess(project: number): Promise<string>;
    export function compileLess(str: string): Promise<string>;
    export function preCompileLess(project: number, less: string, theme: string): Promise<string>;
    export function preCompileLessAction(lessSource: string, tokens: IDesignSystemTokens[], theme: string): Promise<string>;
    export function preCompileLessByThemeOrDefault(project: number, less: string, theme: string): Promise<string>;
    export function removeTokensFromSource(src: string): string;
    export function removeTokensTheme(project: number, themeName: string): Promise<void>;
    export function replaceTokensBlock(code: string, newContent: string): string;
    export interface IDesignSystemTokens {
        description: string;
        themeName: string;
        color: Record<string, string>;
        global: Record<string, string>;
        typography: Record<string, string>;
    }
    export interface IDesignSystem {
        tokens: IDesignSystemTokens[];
    }
    interface IKeyValueToken {
        [x: string]: string;
    }
    export interface IDarkLight {
        [theme: string]: IKeyValueToken;
    }
}
declare module "_102053_/l2/designSystem" {
    import { IDesignSystemTokens } from "_102027_/l2/designSystemBase";
    export const tokens: IDesignSystemTokens[];
}
declare module "_102053_/l2/project" {
    export const projectConfig: {
        masterFrontEnd: {
            build: string;
            start: string;
            liveView: string;
        };
        masterBackEnd: {
            build: string;
            start: string;
            serverView: string;
        };
        modules: any[];
    };
}
declare module "_102053_/l2/brutalshowcase/testeinicial" {
    import { TemplateResult } from 'lit';
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    import '/_102054_/l2/molecules/grouptriggeraction/ml-button-standard-brutal';
    import '/_102054_/l2/molecules/grouptriggeraction/ml-icon-button-brutal';
    import '/_102054_/l2/molecules/grouptriggeraction/ml-split-button-brutal';
    import '/_102054_/l2/molecules/groupenterboolean/ml-toggle-switch-brutal';
    import '/_102054_/l2/molecules/groupentertext/ml-floating-text-input-brutal';
    import '/_102054_/l2/molecules/groupentertext/ml-password-strength-input-brutal';
    import '/_102054_/l2/molecules/groupentertext/ml-tag-input-brutal';
    import '/_102054_/l2/molecules/groupenternumber/ml-number-stepper-brutal';
    import '/_102054_/l2/molecules/groupenternumber/ml-range-slider-brutal';
    import '/_102054_/l2/molecules/groupentermoney/ml-currency-input-brutal';
    export class BrutalShowcaseTesteInicial extends StateLitElement {
        render(): TemplateResult;
    }
}
declare module "_102053_/l2/demo1/acao-visualizacao" {
    import { TemplateResult } from 'lit';
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    import '/_102040_/l2/molecules/grouptriggeraction/ml-button-standard';
    import '/_102040_/l2/molecules/grouptriggeraction/ml-icon-button';
    import '/_102040_/l2/molecules/grouptriggeraction/ml-split-button';
    import '/_102040_/l2/molecules/groupshowprogress/ml-linear-progress';
    import '/_102040_/l2/molecules/groupshowprogress/ml-circular-progress';
    import '/_102040_/l2/molecules/groupviewcard/ml-profile-card';
    import '/_102040_/l2/molecules/groupviewcard/ml-vertical-card';
    import '/_102040_/l2/molecules/groupviewmetric/ml-metric-card';
    import '/_102040_/l2/molecules/groupviewmetric/ml-metric-big-number';
    export class Demo1AcaoVisualizacao extends StateLitElement {
        render(): TemplateResult;
    }
}
declare module "_102053_/l2/demo1/entrada" {
    import { TemplateResult } from 'lit';
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    import '/_102040_/l2/molecules/groupenterboolean/ml-toggle-switch';
    import '/_102040_/l2/molecules/groupenterdate/ml-date-picker';
    import '/_102040_/l2/molecules/groupenterdatetime/ml-datetime-picker';
    import '/_102040_/l2/molecules/groupentermoney/ml-currency-input';
    import '/_102040_/l2/molecules/groupenternumber/ml-number-stepper';
    import '/_102040_/l2/molecules/groupenternumber/ml-range-slider';
    import '/_102040_/l2/molecules/groupentertext/ml-floating-text-input';
    import '/_102040_/l2/molecules/groupentertext/ml-password-strength-input';
    import '/_102040_/l2/molecules/groupentertext/ml-tag-input';
    import '/_102040_/l2/molecules/groupentertime/ml-clock-time-picker';
    export class Demo1Entrada extends StateLitElement {
        private tgOn;
        private tgOff;
        private date;
        private dt;
        private price;
        private budget;
        private qty;
        private rangeLow;
        private rangeHigh;
        private fullName;
        private username;
        private password;
        private tags;
        private time;
        private upd;
        render(): TemplateResult;
    }
}
declare module "_102053_/l2/demo1/feedback" {
    import { TemplateResult } from 'lit';
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    import '/_102040_/l2/molecules/groupnotifyuser/ml-notify-banner';
    import '/_102040_/l2/molecules/groupnotifyuser/ml-toast-notification';
    import '/_102040_/l2/molecules/groupnotifyuser/ml-alert-modal';
    import '/_102040_/l2/molecules/groupexpandcontent/ml-accordion';
    import '/_102040_/l2/molecules/groupexpandcontent/ml-collapsible-panel';
    import '/_102040_/l2/molecules/groupexpandcontent/ml-reveal-overlay';
    import '/_102040_/l2/molecules/grouprateitem/ml-star-rating';
    import '/_102040_/l2/molecules/grouprateitem/ml-emoji-mood-scale';
    export class Demo1Feedback extends StateLitElement {
        private stars;
        private mood;
        private modalOpen;
        private upd;
        render(): TemplateResult;
    }
}
declare module "_102053_/l2/demo1/navegacao" {
    import { TemplateResult } from 'lit';
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    import '/_102040_/l2/molecules/groupnavigatesection/ml-tabs';
    import '/_102040_/l2/molecules/groupnavigatesection/ml-navigate-pills';
    import '/_102040_/l2/molecules/groupnavigatesection/ml-breadcrumb-trail';
    import '/_102040_/l2/molecules/groupnavigatesteps/ml-horizontal-stepper';
    import '/_102040_/l2/molecules/groupnavigatesteps/ml-wizard-steps';
    import '/_102040_/l2/molecules/groupnavigatemain/ml-sidebar-nav';
    export class Demo1Navegacao extends StateLitElement {
        private main;
        private tab;
        private pill;
        private step;
        private wiz;
        private upd;
        render(): TemplateResult;
    }
}
declare module "_102053_/l2/demo1/selecao" {
    import { TemplateResult } from 'lit';
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    import '/_102040_/l2/molecules/groupselectone/ml-select-dropdown';
    import '/_102040_/l2/molecules/groupselectone/ml-radio-group';
    import '/_102040_/l2/molecules/groupselectone/ml-segmented-control';
    import '/_102040_/l2/molecules/groupselectone/ml-combobox';
    import '/_102040_/l2/molecules/groupselectone/ml-card-selector';
    import '/_102040_/l2/molecules/groupselectmany/ml-multi-select-dropdown';
    import '/_102040_/l2/molecules/groupselectmany/ml-popover-multi-select';
    import '/_102040_/l2/molecules/groupsearchcontent/ml-search-bar';
    import '/_102040_/l2/molecules/groupselectfileforupload/ml-file-upload-dropzone';
    export class Demo1Selecao extends StateLitElement {
        private country;
        private plan;
        private view;
        private fruit;
        private tier;
        private skills;
        private hab;
        private q;
        private upd;
        render(): TemplateResult;
    }
}
declare module "_102053_/l2/demo2/acao-visualizacao" {
    import { TemplateResult } from 'lit';
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    import '/_102054_/l2/molecules/grouptriggeraction/ml-button-standard-brutal';
    import '/_102054_/l2/molecules/grouptriggeraction/ml-icon-button-brutal';
    import '/_102054_/l2/molecules/grouptriggeraction/ml-split-button-brutal';
    import '/_102054_/l2/molecules/groupshowprogress/ml-linear-progress-brutal';
    import '/_102054_/l2/molecules/groupshowprogress/ml-circular-progress-brutal';
    import '/_102054_/l2/molecules/groupviewcard/ml-profile-card-brutal';
    import '/_102054_/l2/molecules/groupviewcard/ml-vertical-card-brutal';
    import '/_102054_/l2/molecules/groupviewmetric/ml-metric-card-brutal';
    import '/_102054_/l2/molecules/groupviewmetric/ml-metric-big-number-brutal';
    export class Demo2AcaoVisualizacao extends StateLitElement {
        render(): TemplateResult;
    }
}
declare module "_102053_/l2/demo2/entrada" {
    import { TemplateResult } from 'lit';
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    import '/_102054_/l2/molecules/groupenterboolean/ml-toggle-switch-brutal';
    import '/_102054_/l2/molecules/groupenterdate/ml-date-picker-brutal';
    import '/_102054_/l2/molecules/groupenterdatetime/ml-datetime-picker-brutal';
    import '/_102054_/l2/molecules/groupentermoney/ml-currency-input-brutal';
    import '/_102054_/l2/molecules/groupenternumber/ml-number-stepper-brutal';
    import '/_102054_/l2/molecules/groupenternumber/ml-range-slider-brutal';
    import '/_102054_/l2/molecules/groupentertext/ml-floating-text-input-brutal';
    import '/_102054_/l2/molecules/groupentertext/ml-password-strength-input-brutal';
    import '/_102054_/l2/molecules/groupentertext/ml-tag-input-brutal';
    import '/_102054_/l2/molecules/groupentertime/ml-clock-time-picker-brutal';
    export class Demo2Entrada extends StateLitElement {
        private tgOn;
        private tgOff;
        private date;
        private dt;
        private price;
        private budget;
        private qty;
        private rangeLow;
        private rangeHigh;
        private fullName;
        private username;
        private password;
        private tags;
        private time;
        private upd;
        render(): TemplateResult;
    }
}
declare module "_102053_/l2/demo2/feedback" {
    import { TemplateResult } from 'lit';
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    import '/_102054_/l2/molecules/groupnotifyuser/ml-notify-banner-brutal';
    import '/_102054_/l2/molecules/groupnotifyuser/ml-toast-notification-brutal';
    import '/_102054_/l2/molecules/groupnotifyuser/ml-alert-modal-brutal';
    import '/_102054_/l2/molecules/groupexpandcontent/ml-accordion-brutal';
    import '/_102054_/l2/molecules/groupexpandcontent/ml-collapsible-panel-brutal';
    import '/_102054_/l2/molecules/groupexpandcontent/ml-reveal-overlay-brutal';
    import '/_102054_/l2/molecules/grouprateitem/ml-star-rating-brutal';
    import '/_102054_/l2/molecules/grouprateitem/ml-emoji-mood-scale-brutal';
    export class Demo2Feedback extends StateLitElement {
        private stars;
        private mood;
        private modalOpen;
        private upd;
        render(): TemplateResult;
    }
}
declare module "_102053_/l2/demo2/navegacao" {
    import { TemplateResult } from 'lit';
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    import '/_102054_/l2/molecules/groupnavigatesection/ml-tabs-brutal';
    import '/_102054_/l2/molecules/groupnavigatesection/ml-navigate-pills-brutal';
    import '/_102054_/l2/molecules/groupnavigatesection/ml-breadcrumb-trail-brutal';
    import '/_102054_/l2/molecules/groupnavigatesteps/ml-horizontal-stepper-brutal';
    import '/_102054_/l2/molecules/groupnavigatesteps/ml-wizard-steps-brutal';
    import '/_102054_/l2/molecules/groupnavigatemain/ml-sidebar-nav-brutal';
    export class Demo2Navegacao extends StateLitElement {
        private main;
        private tab;
        private pill;
        private step;
        private wiz;
        private upd;
        render(): TemplateResult;
    }
}
declare module "_102053_/l2/demo2/selecao" {
    import { TemplateResult } from 'lit';
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    import '/_102054_/l2/molecules/groupselectone/ml-select-dropdown-brutal';
    import '/_102054_/l2/molecules/groupselectone/ml-radio-group-brutal';
    import '/_102054_/l2/molecules/groupselectone/ml-segmented-control-brutal';
    import '/_102054_/l2/molecules/groupselectone/ml-combobox-brutal';
    import '/_102054_/l2/molecules/groupselectone/ml-card-selector-brutal';
    import '/_102054_/l2/molecules/groupselectmany/ml-multi-select-dropdown-brutal';
    import '/_102054_/l2/molecules/groupselectmany/ml-popover-multi-select-brutal';
    import '/_102054_/l2/molecules/groupsearchcontent/ml-search-bar-brutal';
    import '/_102054_/l2/molecules/groupselectfileforupload/ml-file-upload-dropzone-brutal';
    export class Demo2Selecao extends StateLitElement {
        private country;
        private plan;
        private view;
        private fruit;
        private tier;
        private skills;
        private hab;
        private q;
        private upd;
        render(): TemplateResult;
    }
}
declare module "_102053_/l2/demo3/acao-visualizacao" {
    import { TemplateResult } from 'lit';
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    import '/_102055_/l2/molecules/grouptriggeraction/ml-button-standard-glass';
    import '/_102055_/l2/molecules/grouptriggeraction/ml-icon-button-glass';
    import '/_102055_/l2/molecules/grouptriggeraction/ml-split-button-glass';
    import '/_102055_/l2/molecules/groupshowprogress/ml-linear-progress-glass';
    import '/_102055_/l2/molecules/groupshowprogress/ml-circular-progress-glass';
    import '/_102055_/l2/molecules/groupviewcard/ml-profile-card-glass';
    import '/_102055_/l2/molecules/groupviewcard/ml-vertical-card-glass';
    import '/_102055_/l2/molecules/groupviewmetric/ml-metric-card-glass';
    import '/_102055_/l2/molecules/groupviewmetric/ml-metric-big-number-glass';
    export class Demo3AcaoVisualizacao extends StateLitElement {
        render(): TemplateResult;
    }
}
declare module "_102053_/l2/demo3/entrada" {
    import { TemplateResult } from 'lit';
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    import '/_102055_/l2/molecules/groupenterboolean/ml-toggle-switch-glass';
    import '/_102055_/l2/molecules/groupenterdate/ml-date-picker-glass';
    import '/_102055_/l2/molecules/groupenterdatetime/ml-datetime-picker-glass';
    import '/_102055_/l2/molecules/groupentermoney/ml-currency-input-glass';
    import '/_102055_/l2/molecules/groupenternumber/ml-number-stepper-glass';
    import '/_102055_/l2/molecules/groupenternumber/ml-range-slider-glass';
    import '/_102055_/l2/molecules/groupentertext/ml-floating-text-input-glass';
    import '/_102055_/l2/molecules/groupentertext/ml-password-strength-input-glass';
    import '/_102055_/l2/molecules/groupentertext/ml-tag-input-glass';
    import '/_102055_/l2/molecules/groupentertime/ml-clock-time-picker-glass';
    export class Demo3Entrada extends StateLitElement {
        private tgOn;
        private tgOff;
        private date;
        private dt;
        private price;
        private budget;
        private qty;
        private rangeLow;
        private rangeHigh;
        private fullName;
        private username;
        private password;
        private tags;
        private time;
        private upd;
        render(): TemplateResult;
    }
}
declare module "_102053_/l2/demo3/feedback" {
    import { TemplateResult } from 'lit';
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    import '/_102055_/l2/molecules/groupnotifyuser/ml-notify-banner-glass';
    import '/_102055_/l2/molecules/groupnotifyuser/ml-toast-notification-glass';
    import '/_102055_/l2/molecules/groupnotifyuser/ml-alert-modal-glass';
    import '/_102055_/l2/molecules/groupexpandcontent/ml-accordion-glass';
    import '/_102055_/l2/molecules/groupexpandcontent/ml-collapsible-panel-glass';
    import '/_102055_/l2/molecules/groupexpandcontent/ml-reveal-overlay-glass';
    import '/_102055_/l2/molecules/grouprateitem/ml-star-rating-glass';
    import '/_102055_/l2/molecules/grouprateitem/ml-emoji-mood-scale-glass';
    export class Demo3Feedback extends StateLitElement {
        private stars;
        private mood;
        private modalOpen;
        private upd;
        render(): TemplateResult;
    }
}
declare module "_102053_/l2/demo3/navegacao" {
    import { TemplateResult } from 'lit';
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    import '/_102055_/l2/molecules/groupnavigatesection/ml-tabs-glass';
    import '/_102055_/l2/molecules/groupnavigatesection/ml-navigate-pills-glass';
    import '/_102055_/l2/molecules/groupnavigatesection/ml-breadcrumb-trail-glass';
    import '/_102055_/l2/molecules/groupnavigatesteps/ml-horizontal-stepper-glass';
    import '/_102055_/l2/molecules/groupnavigatesteps/ml-wizard-steps-glass';
    import '/_102055_/l2/molecules/groupnavigatemain/ml-sidebar-nav-glass';
    export class Demo3Navegacao extends StateLitElement {
        private main;
        private tab;
        private pill;
        private step;
        private wiz;
        private upd;
        render(): TemplateResult;
    }
}
declare module "_102053_/l2/demo3/selecao" {
    import { TemplateResult } from 'lit';
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    import '/_102055_/l2/molecules/groupselectone/ml-select-dropdown-glass';
    import '/_102055_/l2/molecules/groupselectone/ml-radio-group-glass';
    import '/_102055_/l2/molecules/groupselectone/ml-segmented-control-glass';
    import '/_102055_/l2/molecules/groupselectone/ml-combobox-glass';
    import '/_102055_/l2/molecules/groupselectone/ml-card-selector-glass';
    import '/_102055_/l2/molecules/groupselectmany/ml-multi-select-dropdown-glass';
    import '/_102055_/l2/molecules/groupselectmany/ml-popover-multi-select-glass';
    import '/_102055_/l2/molecules/groupsearchcontent/ml-search-bar-glass';
    import '/_102055_/l2/molecules/groupselectfileforupload/ml-file-upload-dropzone-glass';
    export class Demo3Selecao extends StateLitElement {
        private country;
        private plan;
        private view;
        private fruit;
        private tier;
        private skills;
        private hab;
        private q;
        private upd;
        render(): TemplateResult;
    }
}
declare module "_102053_/l2/molecules/grouptriggeraction/ml-button-standard" {
    import { MoleculeAuraElement } from '_102033_/l2/moleculeBase';
    export class ButtonStandardMolecule extends MoleculeAuraElement {
        slotTags: string[];
        cssClass: string;
        size: 'xs' | 'sm' | 'md' | 'lg';
        type: 'button' | 'submit' | 'reset';
        iconPosition: 'start' | 'end';
        disabled: boolean;
        loading: boolean;
        private handleActionClick;
        private isDisabled;
        private getVariant;
        private getSizeKey;
        private getSizeClasses;
        private getVariantClasses;
        private getButtonClasses;
        private getSlotClass;
        private getIconClasses;
        private renderSpinner;
        render(): any;
    }
}
declare module "_102053_/l2/molecules/groupentertext/ml-floating-text-input" {
    import { MoleculeAuraElement } from '_102033_/l2/moleculeBase';
    export class MlFloatingTextInputMolecule extends MoleculeAuraElement {
        slotTags: string[];
        cssClass: string;
        value: string;
        error: string;
        name: string;
        placeholder: string;
        maxLength: number | null;
        minLength: number | null;
        rows: number;
        autocomplete: string;
        inputType: string;
        mask: string;
        isEditing: boolean;
        disabled: boolean;
        readonly: boolean;
        required: boolean;
        loading: boolean;
        private rawDisplay;
        private isFocused;
        private uid;
        handleIcaStateChange(key: string, value: any): void;
        updated(changedProps: Map<string, unknown>): void;
        private handleInput;
        private handleBlur;
        private handleFocus;
        private shouldUseMask;
        private getMaskedDisplayValue;
        private applyMaskToRaw;
        private extractRawFromInput;
        private isMaskToken;
        private isCharValidForToken;
        private getSlotClass;
        private getLabelText;
        private getInputPlaceholder;
        private getViewValue;
        private renderPrefix;
        private renderSuffix;
        private renderFeedback;
        private renderInlineLabel;
        private renderFloatingLabel;
        private getContainerClasses;
        private getInputClasses;
        render(): any;
    }
}
declare module "_102053_/l2/molecules/groupenterboolean/ml-toggle-switch" {
    import { MoleculeAuraElement } from '_102033_/l2/moleculeBase';
    export class ToggleSwitchMolecule extends MoleculeAuraElement {
        private msg;
        private uid;
        slotTags: string[];
        cssClass: string;
        value: boolean;
        error: string;
        name: string;
        isEditing: boolean;
        disabled: boolean;
        private getSlotClass;
        private handleToggle;
        private handleFocus;
        private handleBlur;
        private handleKeydown;
        private renderLabel;
        private renderHelper;
        private renderError;
        private getToggleButtonClasses;
        private getThumbClasses;
        private renderViewMode;
        render(): any;
    }
}
declare module "_102053_/l2/molecules/groupexpandcontent/ml-accordion" {
    import { MoleculeAuraElement } from '_102033_/l2/moleculeBase';
    export class MlAccordionMolecule extends MoleculeAuraElement {
        private msg;
        slotTags: string[];
        cssClass: string;
        multiple: boolean;
        disabled: boolean;
        loading: boolean;
        private openSections;
        firstUpdated(): void;
        private handleToggle;
        private handleHeaderKeydown;
        private findNextEnabledHeader;
        private getSlotClass;
        private getSectionContent;
        private getHeaderClasses;
        private getContentClasses;
        private getChevronClasses;
        render(): any;
        private renderLabel;
        private renderLoading;
        private renderSections;
        private renderSection;
    }
}
declare module "_102053_/l2/demo4/showcase-fase1-ds" {
    import { TemplateResult } from 'lit';
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    import "_102053_/l2/molecules/grouptriggeraction/ml-button-standard";
    import "_102053_/l2/molecules/groupentertext/ml-floating-text-input";
    import "_102053_/l2/molecules/groupenterboolean/ml-toggle-switch";
    import "_102053_/l2/molecules/groupexpandcontent/ml-accordion";
    export class Demo4ShowcaseFase1Ds extends StateLitElement {
        private toggleOn;
        private toggleOff;
        private handleInput;
        render(): TemplateResult;
    }
}
declare module "_102053_/l2/demo4/showcase-fase1" {
    import { TemplateResult } from 'lit';
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    import "_102053_/l2/molecules/grouptriggeraction/ml-button-standard";
    import "_102053_/l2/molecules/groupentertext/ml-floating-text-input";
    import "_102053_/l2/molecules/groupenterboolean/ml-toggle-switch";
    import "_102053_/l2/molecules/groupexpandcontent/ml-accordion";
    export class Demo4ShowcaseFase1 extends StateLitElement {
        private inputValue;
        private inputError;
        private toggleOn;
        private toggleOff;
        private handleInput;
        render(): TemplateResult;
    }
}
declare module "_102053_/l2/demo4/showcase-fase2" {
    import { TemplateResult } from 'lit';
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    import "_102053_/l2/molecules/grouptriggeraction/ml-button-standard";
    import "_102053_/l2/molecules/groupentertext/ml-floating-text-input";
    import "_102053_/l2/molecules/groupenterboolean/ml-toggle-switch";
    import "_102053_/l2/molecules/groupexpandcontent/ml-accordion";
    export class Demo4ShowcaseFase2 extends StateLitElement {
        private toggleVal;
        render(): TemplateResult;
    }
}
declare module "_102053_/l2/demo4/showcase-fase3" {
    import { TemplateResult } from 'lit';
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    import "_102053_/l2/molecules/grouptriggeraction/ml-button-standard";
    import "_102053_/l2/molecules/groupentertext/ml-floating-text-input";
    import "_102053_/l2/molecules/groupenterboolean/ml-toggle-switch";
    import "_102053_/l2/molecules/groupexpandcontent/ml-accordion";
    export class Demo4ShowcaseFase3 extends StateLitElement {
        private toggleVal;
        render(): TemplateResult;
    }
}
declare module "_102053_/l2/demo4/showcase-fase4" {
    import { TemplateResult } from 'lit';
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    import "_102053_/l2/molecules/grouptriggeraction/ml-button-standard";
    import "_102053_/l2/molecules/groupentertext/ml-floating-text-input";
    import "_102053_/l2/molecules/groupenterboolean/ml-toggle-switch";
    import "_102053_/l2/molecules/groupexpandcontent/ml-accordion";
    export class Demo4ShowcaseFase4 extends StateLitElement {
        private darkMode;
        private toggleVal;
        private toggleOff;
        private toggleDarkMode;
        render(): TemplateResult;
    }
}
declare module "_102053_/l2/demo4/sign-in" {
    import { TemplateResult } from 'lit';
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    import "_102053_/l2/molecules/grouptriggeraction/ml-button-standard";
    import "_102053_/l2/molecules/groupentertext/ml-floating-text-input";
    import "_102053_/l2/molecules/groupenterboolean/ml-toggle-switch";
    export class Demo4SignIn extends StateLitElement {
        private email;
        private password;
        private remember;
        private loading;
        private error;
        private handleSubmit;
        render(): TemplateResult;
    }
}
declare module "_102053_/l2/glassshowcase/checkout" {
    import { TemplateResult } from 'lit';
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    import '/_102054_/l2/molecules/groupentertext/ml-floating-text-input';
    import '/_102054_/l2/molecules/groupenterboolean/ml-toggle-switch';
    import '/_102054_/l2/molecules/groupexpandcontent/ml-accordion';
    import '/_102054_/l2/molecules/grouptriggeraction/ml-button-standard';
    export class GlassShowcaseCheckout extends StateLitElement {
        private cardName;
        private cardNumber;
        private expiry;
        private cpf;
        private saveCard;
        private diffAddress;
        private loading;
        private onCardName;
        private onCardNumber;
        private onExpiry;
        private onCpf;
        private onSaveCard;
        private onDiffAddress;
        private onConfirm;
        render(): TemplateResult;
    }
}
declare module "_102053_/l2/glassshowcase/demodropdown" {
    import { TemplateResult } from 'lit';
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    import '/_102054_/l2/molecules/groupselectone/ml-select-dropdown';
    export class GlassShowcaseDemoDropdown extends StateLitElement {
        private country;
        private team;
        private onCountry;
        private onTeam;
        render(): TemplateResult;
    }
}
declare module "_102053_/l2/glassshowcase/demolote2" {
    import { TemplateResult } from 'lit';
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    import '/_102054_/l2/molecules/groupnotifyuser/ml-notify-banner';
    import '/_102054_/l2/molecules/groupnotifyuser/ml-toast-notification';
    import '/_102054_/l2/molecules/groupnotifyuser/ml-alert-modal';
    import '/_102054_/l2/molecules/groupexpandcontent/ml-reveal-overlay';
    import '/_102054_/l2/molecules/grouptriggeraction/ml-button-standard';
    export class GlassShowcaseDemoLote2 extends StateLitElement {
        private bannerVisible;
        private toastVisible;
        private modalOpen;
        render(): TemplateResult;
    }
}
declare module "_102053_/l2/glassshowcase/demolote3" {
    import { TemplateResult } from 'lit';
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    import '/_102054_/l2/molecules/grouptriggeraction/ml-icon-button';
    import '/_102054_/l2/molecules/grouptriggeraction/ml-split-button';
    import '/_102054_/l2/molecules/groupviewcard/ml-profile-card';
    import '/_102054_/l2/molecules/groupviewcard/ml-vertical-card';
    import '/_102054_/l2/molecules/grouptriggeraction/ml-button-standard';
    export class GlassShowcaseDemoLote3 extends StateLitElement {
        render(): TemplateResult;
    }
}
declare module "_102053_/l2/glassshowcase/demolote4" {
    import { TemplateResult } from 'lit';
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    import '/_102054_/l2/molecules/groupnavigatesection/ml-tabs';
    import '/_102054_/l2/molecules/groupnavigatesection/ml-navigate-pills';
    import '/_102054_/l2/molecules/groupnavigatesection/ml-breadcrumb-trail';
    import '/_102054_/l2/molecules/groupnavigatemain/ml-sidebar-nav';
    export class GlassShowcaseDemoLote4 extends StateLitElement {
        private tab;
        private pill;
        private navItem;
        render(): TemplateResult;
    }
}
declare module "_102053_/l2/glassshowcase/demolote5" {
    import { TemplateResult } from 'lit';
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    import '/_102054_/l2/molecules/groupenternumber/ml-number-stepper';
    import '/_102054_/l2/molecules/groupenternumber/ml-range-slider';
    import '/_102054_/l2/molecules/groupentermoney/ml-currency-input';
    import '/_102054_/l2/molecules/groupentertext/ml-password-strength-input';
    import '/_102054_/l2/molecules/groupentertext/ml-tag-input';
    import '/_102054_/l2/molecules/groupselectone/ml-combobox';
    import '/_102054_/l2/molecules/groupselectone/ml-card-selector';
    import '/_102054_/l2/molecules/groupselectmany/ml-popover-multi-select';
    import '/_102054_/l2/molecules/groupsearchcontent/ml-search-bar';
    import '/_102054_/l2/molecules/groupselectfileforupload/ml-file-upload-dropzone';
    export class GlassShowcaseDemoLote5 extends StateLitElement {
        private qty;
        private priceLow;
        private priceHigh;
        private price;
        private password;
        private tags;
        private fruit;
        private tier;
        private langs;
        private query;
        render(): TemplateResult;
    }
}
declare module "_102053_/l2/glassshowcase/demolote6" {
    import { TemplateResult } from 'lit';
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    import '/_102054_/l2/molecules/groupviewmetric/ml-metric-card';
    import '/_102054_/l2/molecules/groupviewmetric/ml-metric-big-number';
    import '/_102054_/l2/molecules/groupshowprogress/ml-linear-progress';
    import '/_102054_/l2/molecules/groupshowprogress/ml-circular-progress';
    import '/_102054_/l2/molecules/groupnavigatesteps/ml-horizontal-stepper';
    import '/_102054_/l2/molecules/groupnavigatesteps/ml-wizard-steps';
    import '/_102054_/l2/molecules/grouprateitem/ml-star-rating';
    import '/_102054_/l2/molecules/grouprateitem/ml-emoji-mood-scale';
    import '/_102054_/l2/molecules/groupexpandcontent/ml-collapsible-panel';
    export class GlassShowcaseDemoLote6 extends StateLitElement {
        private step;
        private wiz;
        private stars;
        private mood;
        render(): TemplateResult;
    }
}
declare module "_102053_/l2/glassshowcase/demolote7" {
    import { TemplateResult } from 'lit';
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    import '/_102054_/l2/molecules/groupenterdate/ml-date-picker';
    import '/_102054_/l2/molecules/groupenterdatetime/ml-datetime-picker';
    import '/_102054_/l2/molecules/groupentertime/ml-clock-time-picker';
    export class GlassShowcaseDemoLote7 extends StateLitElement {
        private date;
        private dt;
        private time;
        render(): TemplateResult;
    }
}
declare module "_102053_/l2/glassshowcase/demomultiselect" {
    import { TemplateResult } from 'lit';
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    import '/_102054_/l2/molecules/groupselectmany/ml-multi-select-dropdown';
    export class GlassShowcaseDemoMultiSelect extends StateLitElement {
        private skills;
        private teams;
        private onSkills;
        private onTeams;
        render(): TemplateResult;
    }
}
declare module "_102053_/l2/glassshowcase/login" {
    import { TemplateResult } from 'lit';
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    import '/_102054_/l2/molecules/groupentertext/ml-floating-text-input';
    import '/_102054_/l2/molecules/groupenterboolean/ml-toggle-switch';
    import '/_102054_/l2/molecules/grouptriggeraction/ml-button-standard';
    export class GlassShowcaseLogin extends StateLitElement {
        private email;
        private password;
        private remember;
        private emailError;
        private loading;
        private onEmailInput;
        private onPasswordInput;
        private onRememberChange;
        private isEmailValid;
        private onSubmit;
        private goToSignup;
        render(): TemplateResult;
    }
}
declare module "_102053_/l2/glassshowcase/settings" {
    import { TemplateResult } from 'lit';
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    import '/_102054_/l2/molecules/groupentertext/ml-floating-text-input';
    import '/_102054_/l2/molecules/groupenterboolean/ml-toggle-switch';
    import '/_102054_/l2/molecules/groupexpandcontent/ml-accordion';
    import '/_102054_/l2/molecules/grouptriggeraction/ml-button-standard';
    export class GlassShowcaseSettings extends StateLitElement {
        private dirty;
        private loading;
        private values;
        private onFieldChange;
        private onSave;
        private onCancel;
        render(): TemplateResult;
    }
}
declare module "_102053_/l2/glassshowcase/signup" {
    import { TemplateResult } from 'lit';
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    import '/_102054_/l2/molecules/groupentertext/ml-floating-text-input';
    import '/_102054_/l2/molecules/groupenterboolean/ml-toggle-switch';
    import '/_102054_/l2/molecules/grouptriggeraction/ml-button-standard';
    export class GlassShowcaseSignup extends StateLitElement {
        private name;
        private email;
        private phone;
        private password;
        private acceptedTerms;
        private loading;
        private onName;
        private onEmail;
        private onPhone;
        private onPassword;
        private onTerms;
        private onSubmit;
        private goToLogin;
        render(): TemplateResult;
    }
}
declare module "_102053_/l2/glassshowcase2/demolotea" {
    import { TemplateResult } from 'lit';
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    import '/_102055_/l2/molecules/groupentertext/ml-floating-text-input-glass';
    import '/_102055_/l2/molecules/groupentertext/ml-password-strength-input-glass';
    import '/_102055_/l2/molecules/groupentertext/ml-tag-input-glass';
    import '/_102055_/l2/molecules/groupentermoney/ml-currency-input-glass';
    import '/_102055_/l2/molecules/groupenternumber/ml-number-stepper-glass';
    import '/_102055_/l2/molecules/groupenternumber/ml-range-slider-glass';
    export class GlassShowcase2DemoLoteA extends StateLitElement {
        private fullName;
        private password;
        private tags;
        private price;
        private qty;
        private priceLow;
        private priceHigh;
        render(): TemplateResult;
    }
}
declare module "_102053_/l2/glassshowcase2/demoloteb" {
    import { TemplateResult } from 'lit';
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    import '/_102055_/l2/molecules/groupselectone/ml-select-dropdown-glass';
    import '/_102055_/l2/molecules/groupselectone/ml-radio-group-glass';
    import '/_102055_/l2/molecules/groupselectone/ml-segmented-control-glass';
    import '/_102055_/l2/molecules/groupselectone/ml-combobox-glass';
    import '/_102055_/l2/molecules/groupselectone/ml-card-selector-glass';
    import '/_102055_/l2/molecules/groupselectmany/ml-multi-select-dropdown-glass';
    import '/_102055_/l2/molecules/groupselectmany/ml-popover-multi-select-glass';
    import '/_102055_/l2/molecules/groupsearchcontent/ml-search-bar-glass';
    import '/_102055_/l2/molecules/groupselectfileforupload/ml-file-upload-dropzone-glass';
    export class GlassShowcase2DemoLoteB extends StateLitElement {
        private country;
        private plan;
        private view;
        private fruit;
        private tier;
        private skills;
        private langs;
        private query;
        render(): TemplateResult;
    }
}
declare module "_102053_/l2/glassshowcase2/demolotec" {
    import { TemplateResult } from 'lit';
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    import '/_102055_/l2/molecules/groupenterdatetime/ml-datetime-picker-glass';
    import '/_102055_/l2/molecules/groupentertime/ml-clock-time-picker-glass';
    export class GlassShowcase2DemoLoteC extends StateLitElement {
        private dt;
        private time;
        render(): TemplateResult;
    }
}
declare module "_102053_/l2/glassshowcase2/demoloted" {
    import { TemplateResult } from 'lit';
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    import '/_102055_/l2/molecules/grouptriggeraction/ml-button-standard-glass';
    import '/_102055_/l2/molecules/grouptriggeraction/ml-icon-button-glass';
    import '/_102055_/l2/molecules/grouptriggeraction/ml-split-button-glass';
    import '/_102055_/l2/molecules/groupviewcard/ml-profile-card-glass';
    import '/_102055_/l2/molecules/groupviewcard/ml-vertical-card-glass';
    export class GlassShowcase2DemoLoteD extends StateLitElement {
        private lastAction;
        private selectedPlan;
        private onAction;
        render(): TemplateResult;
    }
}
declare module "_102053_/l2/glassshowcase2/demolotee" {
    import { TemplateResult } from 'lit';
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    import '/_102055_/l2/molecules/groupnavigatesection/ml-tabs-glass';
    import '/_102055_/l2/molecules/groupnavigatesection/ml-navigate-pills-glass';
    import '/_102055_/l2/molecules/groupnavigatesection/ml-breadcrumb-trail-glass';
    import '/_102055_/l2/molecules/groupnavigatemain/ml-sidebar-nav-glass';
    import '/_102055_/l2/molecules/groupnavigatesteps/ml-horizontal-stepper-glass';
    import '/_102055_/l2/molecules/groupnavigatesteps/ml-wizard-steps-glass';
    export class GlassShowcase2DemoLoteE extends StateLitElement {
        private bc;
        private pill;
        private tab;
        private navItem;
        private stepper;
        private wizard;
        render(): TemplateResult;
    }
}
declare module "_102053_/l2/glassshowcase2/demolotef" {
    import { TemplateResult } from 'lit';
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    import '/_102055_/l2/molecules/groupexpandcontent/ml-accordion-glass';
    import '/_102055_/l2/molecules/groupexpandcontent/ml-collapsible-panel-glass';
    import '/_102055_/l2/molecules/groupexpandcontent/ml-reveal-overlay-glass';
    import '/_102055_/l2/molecules/groupnotifyuser/ml-alert-modal-glass';
    import '/_102055_/l2/molecules/groupnotifyuser/ml-notify-banner-glass';
    import '/_102055_/l2/molecules/groupnotifyuser/ml-toast-notification-glass';
    export class GlassShowcase2DemoLoteF extends StateLitElement {
        private bannerVisible;
        private toastVisible;
        private modalOpen;
        render(): TemplateResult;
    }
}
declare module "_102053_/l2/glassshowcase2/demoloteg" {
    import { TemplateResult } from 'lit';
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    import '/_102055_/l2/molecules/groupviewmetric/ml-metric-card-glass';
    import '/_102055_/l2/molecules/groupviewmetric/ml-metric-big-number-glass';
    import '/_102055_/l2/molecules/groupshowprogress/ml-linear-progress-glass';
    import '/_102055_/l2/molecules/groupshowprogress/ml-circular-progress-glass';
    import '/_102055_/l2/molecules/grouprateitem/ml-star-rating-glass';
    import '/_102055_/l2/molecules/grouprateitem/ml-emoji-mood-scale-glass';
    export class GlassShowcase2DemoLoteG extends StateLitElement {
        private stars;
        private mood;
        render(): TemplateResult;
    }
}
declare module "_102053_/l2/glassshowcase2/demopilot" {
    import { TemplateResult } from 'lit';
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    import '/_102055_/l2/molecules/groupenterboolean/ml-toggle-switch-glass';
    import '/_102055_/l2/molecules/groupenterdate/ml-date-picker-glass';
    export class GlassShowcase2DemoPilot extends StateLitElement {
        private notif;
        private terms;
        private date;
        render(): TemplateResult;
    }
}
declare module "_102053_/l2/molecules/groupenterboolean/ml-toggle-switch.defs" {
    export const group = "groupEnterBoolean";
    export const layoutConfig: {
        boolean: string;
    };
    export const skill = "# Metadata\n- TagName: groupenterboolean--ml-toggle-switch\n\n# Objective\nA boolean input molecule that enables users to switch between two mutually exclusive states. It provides an interactive toggle during editing mode and displays the current selection as static text during read-only mode. It reports value changes, focus, and blur to the surrounding system, and presents labels, contextual guidance, and validation errors according to its current state.\n\n# Responsibilities\n- Present an interactive binary toggle when in editing mode\n- Display static text representing the current value when not in editing mode, showing \"Yes\" for true and \"No\" for false\n- Accept and display label content through the contract-defined label region\n- Accept and display helper content through the contract-defined helper region when no validation error is present and in editing mode\n- Display validation error messages when provided and in editing mode\n- Change the boolean value upon user activation when in editing mode\n- Report value changes to the system, including the new boolean state\n- Report when the control receives focus\n- Report when the control loses focus\n- Prevent user activation and suppress value change reports when disabled\n- Prevent all interaction and suppress reports when not in editing mode\n- Initialize with a default value of false when no prior value exists\n- Support keyboard activation to change the value when enabled and in editing mode\n- Communicate the current boolean state to accessibility tools\n- Communicate the disabled condition to accessibility tools when applicable\n- Communicate the invalid condition to accessibility tools when a validation error is present\n- Maintain programmatic associations between the control and its label, helper text, and error messages\n\n# Constraints\n- Must exclusively use the Label and Helper content regions defined in the contract\n- Must treat the value strictly as a boolean type without intermediate states\n- Must not permit value changes while disabled\n- Must not report value changes while disabled\n- Must not permit interaction or report focus, blur, or value changes when not in editing mode\n- Must suppress helper text display when a validation error message is present\n- Must not display helper text or error messages when not in editing mode\n- Must ensure value change reports are detectable outside the component\n- Must display \"Yes\" only when the value is true in read-only mode\n- Must display \"No\" only when the value is false in read-only mode\n\n# Notes\n- The control maintains a strict binary state; null or indeterminate values are not supported\n- Keyboard activation should follow conventional toggle interaction patterns";
}
declare module "_102053_/l2/molecules/groupentertext/index" {
    import { TemplateResult } from 'lit';
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    import "_102053_/l2/molecules/groupentertext/ml-floating-text-input";
    import '/_102053_/l2/molecules/groupentertext/ml-text-field';
    export class GroupEnterTextIndex extends StateLitElement {
        private cardFloatingInput;
        private cardTextField;
        private renderHero;
        private renderShowcaseCards;
        private renderReferenceTable;
        protected render(): TemplateResult;
    }
}
declare module "_102053_/l2/molecules/groupentertext/ml-floating-text-input.defs" {
    export const group = "groupEnterText";
    export const layoutConfig: {
        labelPlacement: string;
    };
    export const skill = "# Metadata\n- TagName: groupentertext--ml-floating-text-input\n\n# Objective\nAllow the user to enter a single line of text through an input field that features a floating label \u2014 the label starts in the placeholder position and animates upward when the field is focused or has a value. The component supports optional input masking, prefix and suffix slots, character length limits, multiple input types, and disabled, readonly, error, loading, and view-only states.\n\n# Responsibilities\n- Display a floating label that animates to a smaller position above the input when the field is focused or has a value.\n- Accept and expose typed text as the component's value, dispatching an \"input\" event on each keystroke and a \"change\" event on blur.\n- Apply an optional input mask: insert literal separator characters automatically, strip non-matching characters, and store only the raw (unmasked) digits or letters as the value.\n- Enforce optional maximum and minimum character length limits on the raw value.\n- Support multiple input types (text, password, email, etc.) via the input-type property; never apply masking when the type is \"password\".\n- Render a read-only view mode (isEditing = false) that shows the label and value as plain text, displaying \"\u2022\u2022\u2022\u2022\u2022\u2022\u2022\u2022\" for password type and \"\u2014\" when the value is empty.\n- Show an inline error message styled in red when the error property is set.\n- Show a helper text below the field when a Helper slot is provided and there is no error.\n- Render optional prefix and suffix content inside the input container via named slots.\n- Show a spinning indicator inside the suffix area when the loading state is active.\n- Dispatch \"focus\" and \"blur\" custom events when the underlying input gains or loses focus.\n- Synchronize the displayed masked value when the bound value, mask, or input-type changes externally.\n\n# Constraints\n- Input, typing, focus, and all interaction must be blocked when disabled, readonly, loading, or isEditing is false.\n- Masking must never be applied to password-type inputs.\n- The raw (unmasked) value must be stored in the value property; masked characters are display-only.\n- The clear action and option list are not part of this component; it is a plain text input, not a select.\n- Error styling must persist until the error property is cleared externally.\n- The loading state must prevent interaction and display a spinner in place of or alongside the suffix slot.\n- Multiple simultaneous selections or multi-line input are not supported by this component.";
}
declare module "_102053_/l2/molecules/groupentertext/ml-text-input-standard.defs" {
    export const group = "groupEnterText";
    export const skill = "# Metadata\n- TagName: groupentertext--ml-text-input-standard\n# Objective\nPermitir que o usu\u00E1rio informe e visualize textos como nome, endere\u00E7o e outros dados textuais, com suporte a modos de edi\u00E7\u00E3o e visualiza\u00E7\u00E3o, m\u00E1scara, valida\u00E7\u00F5es e estados de feedback.\n# Responsibilities\n- Armazenar e emitir o valor como texto.\n- Renderizar um campo de linha \u00FAnica quando a quantidade de linhas for 1 e um campo multilinha quando for maior que 1.\n- Emitir evento de entrada a cada altera\u00E7\u00E3o durante a digita\u00E7\u00E3o com o valor atual.\n- Emitir evento de mudan\u00E7a ao perder o foco ou confirmar a entrada com o valor atual.\n- Emitir eventos de foco e perda de foco quando o campo receber ou perder foco.\n- Suportar modo de edi\u00E7\u00E3o com campo interativo e modo de visualiza\u00E7\u00E3o com texto est\u00E1tico.\n- Em modo de visualiza\u00E7\u00E3o, exibir \u201C\u2014\u201D quando o valor estiver vazio; para tipo senha, exibir \u201C\u2022\u2022\u2022\u2022\u2022\u2022\u2022\u2022\u201D; caso contr\u00E1rio, exibir o valor textual.\n- Respeitar estados desabilitado, somente leitura, obrigat\u00F3rio e carregando, bloqueando intera\u00E7\u00F5es quando aplic\u00E1vel e indicando carregamento.\n- Respeitar o limite m\u00E1ximo de caracteres e sinalizar erro quando o valor estiver abaixo do m\u00EDnimo.\n- Exibir contador de caracteres no formato \u201Catual / m\u00E1ximo\u201D quando houver limite m\u00E1ximo e m\u00FAltiplas linhas.\n- Aplicar m\u00E1scara de entrada quando fornecida, exibindo o valor formatado e armazenando apenas os caracteres brutos.\n- Exibir mensagem de erro quando houver conte\u00FAdo de erro e nunca exibir erro em modo de visualiza\u00E7\u00E3o.\n- Renderizar conte\u00FAdo opcional de r\u00F3tulo, ajuda, prefixo e sufixo nas posi\u00E7\u00F5es adequadas: r\u00F3tulo acima, ajuda/erro abaixo, prefixo antes do campo e sufixo depois do campo.\n- Propagar atributos de placeholder, autocomplete, tipo de entrada, nome, tamanho m\u00EDnimo e m\u00E1ximo conforme definidos para o componente.\n# Constraints\n- N\u00E3o permitir intera\u00E7\u00E3o quando estiver desabilitado, somente leitura ou carregando.\n- N\u00E3o permitir que o valor ultrapasse o limite m\u00E1ximo de caracteres.\n- Em modo de visualiza\u00E7\u00E3o, n\u00E3o exibir bordas, fundo, foco ou mensagem de erro.\n# Notes\n- O contador de caracteres \u00E9 exibido apenas quando h\u00E1 limite m\u00E1ximo e m\u00FAltiplas linhas.";
}
declare module "_102053_/l2/molecules/groupentertext/ml-text-input-standard" {
    import { MoleculeAuraElement } from '_102033_/l2/moleculeBase';
    export class MlTextInputStandardMolecule extends MoleculeAuraElement {
        slotTags: string[];
        value: string;
        error: string;
        name: string;
        placeholder: string;
        maxLength: number | null;
        minLength: number | null;
        rows: number;
        autocomplete: string;
        inputType: string;
        mask: string;
        isEditing: boolean;
        disabled: boolean;
        readonly: boolean;
        required: boolean;
        loading: boolean;
        private displayValue;
        private uid;
        handleIcaStateChange(key: string, value: any): void;
        updated(changedProps: Map<string, unknown>): void;
        private handleInput;
        private handleBlur;
        private handleFocus;
        render(): any;
        private renderLabel;
        private renderEditMode;
        private renderViewMode;
        private renderInputElement;
        private renderPrefix;
        private renderSuffix;
        private renderFeedback;
        private renderCounter;
        private renderSpinner;
        private updateDisplayValueFromProps;
        private isTextarea;
        private isDisabledOrLoading;
        private hasError;
        private getViewDisplayValue;
        private getFieldContainerClasses;
        private getInputClasses;
        private getLabelId;
        private getHelperId;
        private getErrorId;
        private getCounterId;
        private getDescribedBy;
        private isMaskToken;
        private isCharAllowed;
        private extractRawFromMasked;
        private applyMask;
    }
}
declare module "_102053_/l2/molecules/groupexpandcontent/ml-accordion.defs" {
    export const group = "groupExpandContent";
    export const layoutConfig: {
        expand: string;
    };
    export const skill = "# Metadata\n- TagName: groupexpandcontent--ml-accordion\n\n# Objective\nAllow the user to expand and collapse individually labeled content sections arranged vertically. The component can operate in single-expand mode (only one section open at a time) or multi-expand mode (any number of sections open simultaneously), and supports disabled, loading, and per-section disabled states with full keyboard navigation.\n\n# Responsibilities\n- Render each Section slot as a collapsible panel with a clickable header showing its title attribute.\n- Track which sections are open and toggle them when their header is clicked or activated via keyboard.\n- In single-expand mode, close any currently open section before opening a new one.\n- In multi-expand mode, allow any number of sections to be open simultaneously.\n- Initialize open sections from the expanded attribute present on Section elements at first render.\n- Dispatch a toggle custom event (bubbling, composed) with index, title, and expanded when a section is toggled.\n- Allow moving keyboard focus between section headers using ArrowDown and ArrowUp keys, skipping disabled headers.\n- Activate a focused header with Enter or Space.\n- Render an optional Label slot above the accordion panels.\n- Display a loading skeleton with an animated pulse when the loading property is true.\n- Show an empty-state message when no Section slots are provided.\n- Apply disabled styling and block interaction on individual sections that carry the disabled attribute.\n- Block all interaction when the component-level disabled or loading property is true.\n- Support light and dark color schemes through conditional class application.\n\n# Constraints\n- A section must not open or close while the component-level disabled or loading state is active.\n- A per-section disabled header must receive tabindex=\"-1\" and must not be reachable or togglable.\n- In single-expand mode, at most one section may be open at any time.\n- Keyboard navigation must skip disabled headers and wrap around the list.\n- The component must not contain business logic; it only manages visual expand/collapse state.\n- Section content is rendered via unsafeHTML from the Section slot's inner template or innerHTML and must not be sanitized by this component.";
}
declare module "_102053_/l2/molecules/grouptriggeraction/ml-button-standard.defs" {
    export const group = "groupTriggerAction";
    export const layoutConfig: {
        actionStyle: string;
    };
    export const skill = "# Metadata\n- TagName: grouptriggeraction--ml-button-standard\n\n# Objective\nA standard button molecule for the groupTriggerAction group that triggers actions when activated. It supports text labels, icons, multiple sizes, visual styles, loading states with a spinner indicator, and disabled states. Designed for corporate interfaces such as ERP, CRM, HR, Financial, and Logistics systems.\n\n# Responsibilities\n- Display a text label and/or an icon provided through the designated Label and Icon content areas.\n- Arrange the icon either before or after the text label based on configuration.\n- Adjust overall dimensions and icon scale according to the selected size.\n- Behave as a standard button, a submit button, or a reset button based on configuration.\n- Ignore activation attempts and present a disabled state when configured as disabled.\n- Ignore activation attempts and present a busy state when configured as loading.\n- Show a loading spinner in place of the icon or text during loading, keeping the button size unchanged.\n- Trigger an action event when activated by pointer or keyboard (Enter or Space), unless disabled or loading.\n- Expose an accessible name for icon-only buttons using the Label content when available.\n- Support rich content within the Label and Icon areas.\n- Provide distinct visual feedback for Normal, Hover, Active, and Focused states, with a visible focus indicator for keyboard users.\n- Reduce opacity and remove interactive feedback when disabled.\n- Support visual variations for primary, secondary, danger, ghost, and link styles through theming.\n- Adapt colors for dark mode using semantic color definitions.\n\n# Constraints\n- Must compose content using only the Label and Icon areas.\n- Icon position must be either 'start' or 'end'.\n- Size must be one of 'xs', 'sm', 'md', or 'lg'.\n- Type must be one of 'button', 'submit', or 'reset'.\n- When disabled, the action event must not trigger.\n- When loading, the action event must not trigger, and the button must expose busy and disabled states for accessibility.\n- During loading, the spinner replaces the icon if present; otherwise, it replaces the text label.\n- The action event must contain no detail and must propagate normally.\n- For icon-only buttons, the accessible name must come from the Label content if provided; otherwise, it must be empty.\n- Visual style variations must not require additional configuration properties.\n- Dark mode colors must map to semantic tokens for background, text, border, and focus ring.\n\n# Notes\n- Designed for corporate contexts such as ERP forms, CRM proposals, HR approvals, financial payments, and logistics operations.\n- The button must preserve its dimensions during loading to prevent layout shifts.\n- Visual design aligns with Material UI, Ant Design, and Atlassian Design System button patterns.";
}
declare module "_102053_/l2/testes/account-settings" {
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    import '/_102040_/l2/molecules/groupnavigatesection/ml-tabs';
    import '/_102040_/l2/molecules/groupentertext/ml-floating-text-input';
    import '/_102040_/l2/molecules/groupentertext/ml-multiline-text';
    import '/_102040_/l2/molecules/groupentertext/ml-cpf-input';
    import '/_102040_/l2/molecules/groupentermoney/ml-enter-money-br';
    import '/_102040_/l2/molecules/groupenterdate/ml-date-picker';
    import '/_102040_/l2/molecules/groupselectone/ml-select-dropdown';
    import '/_102040_/l2/molecules/groupselectone/ml-segmented-control';
    import '/_102040_/l2/molecules/groupenterboolean/ml-toggle-switch';
    import '/_102040_/l2/molecules/groupenterboolean/ml-checkbox-preference';
    import '/_102040_/l2/molecules/groupnotifyuser/ml-toast-notification';
    export class AccountSettings extends StateLitElement {
        activeTab: string;
        viewEpoch: number;
        toastVisible: boolean;
        toastMsg: string;
        isEditingPerfil: boolean;
        isEditingSeguranca: boolean;
        isEditingCobranca: boolean;
        errors: Record<string, string>;
        name: string;
        email: string;
        phone: string;
        birthDate: string;
        bio: string;
        recoveryEmail: string;
        twoFaEnabled: boolean;
        pushNotif: boolean;
        cpf: string;
        spendingLimit: number;
        spendingAlert: number;
        autoPayment: boolean;
        termsAccepted: boolean;
        language: string;
        timezone: string;
        theme: string;
        private snapshotPerfil;
        private snapshotSeguranca;
        private snapshotCobranca;
        private editPerfil;
        private cancelPerfil;
        private savePerfil;
        private editSeguranca;
        private cancelSeguranca;
        private saveSeguranca;
        private editCobranca;
        private cancelCobranca;
        private saveCobranca;
        private handleRequestEdit;
        private get languageLabel();
        private get timezoneLabel();
        private get themeLabel();
        private formatMoney;
        private formatCpf;
        private err;
        private badge;
        private editHeader;
        private renderPerfilView;
        private renderSegurancaView;
        private renderCobrancaView;
        private renderPreferenciasView;
        private renderPerfilEditForm;
        private renderSegurancaEditForm;
        private renderCobrancaEditForm;
        private renderPreferenciasControls;
        private renderActivePanel;
        private renderTabs;
        render(): any;
    }
}
declare module "_102053_/l2/testes/appointment-scheduler" {
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    import '/_102040_/l2/molecules/groupnavigatesection/ml-tabs';
    import '/_102040_/l2/molecules/groupentertext/ml-floating-text-input';
    import '/_102040_/l2/molecules/groupentertext/ml-multiline-text';
    import '/_102040_/l2/molecules/groupenterdatetime/ml-datetime-picker';
    import '/_102040_/l2/molecules/groupenterdatetimeinterval/ml-enter-datetime-interval';
    import '/_102040_/l2/molecules/groupentertimeinterval/ml-time-interval-selector';
    import '/_102040_/l2/molecules/groupselectone/ml-select-one-autocomplete';
    import '/_102040_/l2/molecules/groupselectmany/ml-multi-select-dropdown';
    import '/_102040_/l2/molecules/groupselectone/ml-radio-group';
    import '/_102040_/l2/molecules/groupenternumber/ml-number-input';
    import '/_102040_/l2/molecules/groupnotifyuser/ml-toast-notification';
    import '/_102040_/l2/molecules/groupviewtable/ml-data-table-minimal';
    interface Meeting {
        id: number;
        title: string;
        date: string;
        room: string;
        participants: number;
    }
    export class AppointmentScheduler extends StateLitElement {
        activeTab: string;
        viewEpoch: number;
        toastVisible: boolean;
        toastMsg: string;
        title: string;
        agenda: string;
        startAt: string;
        intervalStart: string;
        intervalEnd: string;
        preferredStart: string;
        preferredEnd: string;
        participants: string[];
        selectedRooms: string[];
        recurrence: string;
        recurrenceCount: number;
        errors: Record<string, string>;
        upcomingMeetings: Meeting[];
        private readonly availableRooms;
        private readonly allParticipants;
        private validate;
        private err;
        private handleAgendar;
        private handleParticipantSelect;
        private removeParticipant;
        private renderTabs;
        private renderNovaReuniaoForm;
        private renderMinhasReunioes;
        render(): any;
    }
}
declare module "_102053_/l2/testes/budget-editor" {
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    import '/_102040_/l2/molecules/groupviewtable/ml-data-table';
    import '/_102040_/l2/molecules/groupentermoney/ml-enter-money-br';
    import '/_102040_/l2/molecules/groupentertext/ml-floating-text-input';
    import '/_102040_/l2/molecules/groupselectone/ml-select-dropdown';
    import '/_102040_/l2/molecules/groupenternumber/ml-number-input';
    import '/_102040_/l2/molecules/groupselectone/ml-segmented-control';
    import '/_102040_/l2/molecules/groupnotifyuser/ml-notify-banner';
    import '/_102040_/l2/molecules/groupnotifyuser/ml-toast-notification';
    interface BudgetRow {
        id: number;
        description: string;
        costCenter: string;
        qty: number;
        planned: number;
        actual: number;
    }
    export class BudgetEditor extends StateLitElement {
        rows: BudgetRow[];
        activeFilter: 'all' | 'over' | 'within';
        editingRowId: number | null;
        tableEpoch: number;
        bannerDismissed: boolean;
        toastVisible: boolean;
        editDescription: string;
        editCostCenter: string;
        editQty: number;
        editPlanned: number;
        editActual: number;
        errors: Record<string, string>;
        private editSnapshot;
        private get filteredRows();
        private get overBudgetRows();
        private get editingRow();
        private fmt;
        private err;
        private handleRowClick;
        private openEdit;
        private cancelEdit;
        private saveEdit;
        private renderTable;
        private renderEditPanel;
        render(): any;
    }
}
declare module "_102053_/l2/testes/candidate-pipeline" {
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    import '/_102040_/l2/molecules/groupnavigatesection/ml-navigate-pills';
    import '/_102040_/l2/molecules/groupviewcard/ml-view-card-horizontal';
    import '/_102040_/l2/molecules/grouprateitem/ml-star-rating';
    import '/_102040_/l2/molecules/grouprateitem/ml-thumbs-rating';
    import '/_102040_/l2/molecules/groupselectfileforupload/ml-file-upload-dropzone';
    import '/_102040_/l2/molecules/groupselectfileforupload/ml-user-photo-upload';
    import '/_102040_/l2/molecules/groupviewdata/ml-vertical-record-list';
    import '/_102040_/l2/molecules/groupexpandcontent/ml-readmore-expand';
    import '/_102040_/l2/molecules/groupenterdate/ml-compact-calendar';
    import '/_102040_/l2/molecules/grouptriggeraction/ml-button-standard';
    import '/_102040_/l2/molecules/grouptriggeraction/ml-icon-button';
    import '/_102040_/l2/molecules/groupsearchcontent/ml-search-bar';
    import '/_102040_/l2/molecules/groupnotifyuser/ml-toast-notification';
    type Stage = 'triagem' | 'interview' | 'technical' | 'proposal' | 'hired';
    interface HistoryEntry {
        date: string;
        type: string;
        description: string;
    }
    interface Candidate {
        id: number;
        name: string;
        role: string;
        stage: Stage;
        rating: number;
        thumb: 'up' | 'down' | null;
        cvFile: string | null;
        interviewDate: string;
        history: HistoryEntry[];
    }
    export class CandidatePipeline extends StateLitElement {
        activeStage: Stage;
        searchQuery: string;
        selectedId: number;
        toastVisible: boolean;
        toastMessage: string;
        candidates: Candidate[];
        private readonly job;
        private readonly stageOrder;
        private readonly stageLabels;
        private readonly nextStageLabel;
        private get selectedCandidate();
        private get filteredCandidates();
        private countByStage;
        private initials;
        private selectFirstInStage;
        private autoSelectAfterMutation;
        private advanceCandidate;
        private rejectCandidate;
        private updateCandidate;
        private showToast;
        render(): any;
        private renderCandidateCard;
        private renderEmptyPanel;
        private renderDetailPanel;
    }
}
declare module "_102053_/l2/testes/corporate-dashboard" {
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    import '/_102040_/l2/molecules/groupviewmetric/ml-metric-big-number';
    import '/_102040_/l2/molecules/groupviewmetric/ml-metric-gauge';
    import '/_102040_/l2/molecules/groupviewchart/ml-area-chart';
    import '/_102040_/l2/molecules/groupviewchart/ml-bar-chart';
    import '/_102040_/l2/molecules/groupviewtable/ml-data-table-minimal';
    import '/_102040_/l2/molecules/groupnotifyuser/ml-notify-banner';
    import '/_102040_/l2/molecules/groupselectone/ml-segmented-control';
    export class CorporateDashboard extends StateLitElement {
        period: string;
        bannerVisible: boolean;
        private readonly kpiData;
        private readonly transactions;
        private get kpis();
        private statusBadge;
        render(): any;
    }
}
declare module "_102053_/l2/testes/customer-profile" {
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    import '/_102040_/l2/molecules/groupentertext/ml-floating-text-input';
    import '/_102040_/l2/molecules/groupentertext/ml-cpf-input';
    import '/_102040_/l2/molecules/groupentertext/ml-multiline-text';
    import '/_102040_/l2/molecules/groupenterdate/ml-date-picker';
    import '/_102040_/l2/molecules/groupselectone/ml-select-dropdown';
    import '/_102040_/l2/molecules/groupselectone/ml-select-one-autocomplete';
    import '/_102040_/l2/molecules/groupselectmany/ml-multi-checkbox-list';
    import '/_102040_/l2/molecules/groupenterboolean/ml-checkbox-preference';
    import '/_102040_/l2/molecules/groupnotifyuser/ml-toast-notification';
    export class CustomerProfile extends StateLitElement {
        isEditing: boolean;
        toastVisible: boolean;
        errors: Record<string, string>;
        clientName: string;
        personType: string;
        cnpj: string;
        cpf: string;
        email: string;
        phone: string;
        segment: string;
        city: string;
        stateUF: string;
        registerDate: string;
        birthday: string;
        channels: string;
        acceptsOffers: boolean;
        acceptsWpp: boolean;
        notes: string;
        private snapshot;
        private takeSnapshot;
        private restoreSnapshot;
        private edit;
        private cancel;
        private validate;
        private save;
        private err;
        private get segmentLabel();
        private get initials();
        private get personTypeLabel();
        render(): any;
    }
}
declare module "_102053_/l2/testes/edicao-cliente" {
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    import '/_102040_/l2/molecules/groupentertext/ml-floating-text-input';
    import '/_102040_/l2/molecules/groupselectone/ml-combobox';
    import '/_102040_/l2/molecules/groupselectone/ml-segmented-control';
    import '/_102040_/l2/molecules/groupnotifyuser/ml-notify-banner';
    export class EdicaoClientePage extends StateLitElement {
        private nome;
        private endereco;
        private situacao;
        private pesquisa;
        private clienteAtual;
        private errors;
        private saved;
        connectedCallback(): void;
        private getClientes;
        private err;
        private handleSelect;
        private handleSave;
        private handleCancel;
        private clearForm;
        render(): any;
        private renderForm;
        private renderSectionHeader;
    }
}
declare module "_102053_/l2/testes/employee-profile" {
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    import '/_102040_/l2/molecules/groupentertext/ml-floating-text-input';
    import '/_102040_/l2/molecules/groupentertext/ml-cpf-input';
    import '/_102040_/l2/molecules/groupentertext/ml-multiline-text';
    import '/_102040_/l2/molecules/groupenterdate/ml-date-picker';
    import '/_102040_/l2/molecules/groupselectone/ml-select-dropdown';
    import '/_102040_/l2/molecules/groupselectone/ml-radio-group';
    import '/_102040_/l2/molecules/groupentermoney/ml-enter-money-br';
    import '/_102040_/l2/molecules/groupenterboolean/ml-toggle-switch';
    import '/_102040_/l2/molecules/groupnotifyuser/ml-toast-notification';
    export class EmployeeProfile extends StateLitElement {
        isEditing: boolean;
        toastVisible: boolean;
        errors: Record<string, string>;
        name: string;
        cpf: string;
        email: string;
        phone: string;
        birthDate: string;
        admissionDate: string;
        department: string;
        role: string;
        workRegime: string;
        salary: number | null;
        systemAccess: boolean;
        isAdmin: boolean;
        notes: string;
        private snapshot;
        private takeSnapshot;
        private restoreSnapshot;
        private edit;
        private cancel;
        private validate;
        private save;
        private err;
        private get departmentLabel();
        private get roleLabel();
        private get initials();
        render(): any;
    }
}
declare module "_102053_/l2/testes/employee-registration" {
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    import '/_102040_/l2/molecules/groupnavigatesteps/ml-horizontal-stepper';
    import '/_102040_/l2/molecules/groupentertext/ml-floating-text-input';
    import '/_102040_/l2/molecules/groupentertext/ml-cpf-input';
    import '/_102040_/l2/molecules/groupenterdate/ml-date-picker';
    import '/_102040_/l2/molecules/groupselectone/ml-select-dropdown';
    import '/_102040_/l2/molecules/groupselectone/ml-radio-group';
    import '/_102040_/l2/molecules/groupentermoney/ml-enter-money-br';
    import '/_102040_/l2/molecules/groupenterboolean/ml-toggle-switch';
    import '/_102040_/l2/molecules/groupenterboolean/ml-checkbox-preference';
    import '/_102040_/l2/molecules/groupselectmany/ml-multi-checkbox-list';
    import '/_102040_/l2/molecules/groupnotifyuser/ml-toast-notification';
    export class EmployeeRegistration extends StateLitElement {
        currentStep: number;
        toastVisible: boolean;
        errors: Record<string, string>;
        name: string;
        cpf: string;
        email: string;
        phone: string;
        birthDate: string;
        department: string;
        role: string;
        workRegime: string;
        admissionDate: string;
        salary: number | null;
        systemAccess: boolean;
        isAdmin: boolean;
        modules: string;
        privacyAccepted: boolean;
        private readonly steps;
        private validate;
        private next;
        private back;
        private err;
        render(): any;
        private renderStep0;
        private renderStep1;
        private renderStep2;
    }
}
declare module "_102053_/l2/testes/escolha-orcamento" {
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    import '/_102040_/l2/molecules/groupnavigatesteps/ml-wizard-steps';
    import '/_102040_/l2/molecules/groupviewtable/ml-data-table-select';
    import '/_102040_/l2/molecules/groupviewmetric/ml-metric-card';
    import '/_102040_/l2/molecules/groupenterboolean/ml-toggle-switch';
    import '/_102040_/l2/molecules/groupentertext/ml-multiline-text';
    import '/_102040_/l2/molecules/groupnotifyuser/ml-notify-banner';
    export class EscolhaOrcamentoPage extends StateLitElement {
        private step;
        private steps;
        private orcamentoSelecionado;
        private orcamentoIdx;
        private tarefas;
        private bloquearVeiculo;
        private justificativa;
        private justificativaError;
        private osGerada;
        private getMenorValor;
        private brl;
        private stars;
        private tarefaLabel;
        private completeStep;
        private handleWizardChange;
        private handleTableChange;
        private handleNext;
        private handleBack;
        private handleGerarOS;
        render(): any;
        private renderNav;
        private renderStep0;
        private renderStep1;
        private compRow;
        private handleVistoriaChange;
        private renderStep2;
        private renderStep3;
        private renderStep4;
    }
}
declare module "_102053_/l2/testes/field-service-order" {
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    import '/_102040_/l2/molecules/groupnavigatesteps/ml-vertical-stepper';
    import '/_102040_/l2/molecules/groupscancode/ml-scan-code-1d';
    import '/_102040_/l2/molecules/groupscancode/ml-scan-code';
    import '/_102040_/l2/molecules/grouplocateposition/ml-locate-map-picker';
    import '/_102040_/l2/molecules/grouplocateposition/ml-geolocation-trigger';
    import '/_102040_/l2/molecules/groupshowprogress/ml-linear-progress';
    import '/_102040_/l2/molecules/groupshowprogress/ml-indeterminate-spinner';
    import '/_102040_/l2/molecules/groupentertime/ml-clock-time-picker';
    import '/_102040_/l2/molecules/groupentertime/ml-time-scroll-picker';
    import '/_102040_/l2/molecules/groupviewdata/ml-timeline-view';
    import '/_102040_/l2/molecules/groupexpandcontent/ml-single-expand-content';
    import '/_102040_/l2/molecules/grouptriggeraction/ml-button-standard';
    import '/_102040_/l2/molecules/grouptriggeraction/ml-icon-button';
    import '/_102040_/l2/molecules/groupentertext/ml-multiline-text';
    import '/_102040_/l2/molecules/groupenterboolean/ml-checkbox-preference';
    import '/_102040_/l2/molecules/groupnotifyuser/ml-toast-notification';
    interface ChecklistItem {
        id: number;
        label: string;
        done: boolean;
    }
    export class FieldServiceOrder extends StateLitElement {
        currentStep: number;
        scannedBarcode: string;
        scannedQr: string;
        locationCoords: string;
        arrivalTime: string;
        preferredWindowStart: string;
        preferredWindowEnd: string;
        report: string;
        loadingHistory: boolean;
        historyLoaded: boolean;
        toastVisible: boolean;
        toastMessage: string;
        checklist: ChecklistItem[];
        private readonly order;
        private readonly serviceHistory;
        private get doneCount();
        private get allDone();
        private get checklistProgress();
        private toggleItem;
        private showToast;
        private loadHistory;
        private nextStep;
        render(): any;
    }
}
declare module "_102053_/l2/testes/financial-report" {
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    import '/_102040_/l2/molecules/groupenterdateinterval/ml-date-range-dual-calendar';
    import '/_102040_/l2/molecules/groupselectone/ml-select-dropdown';
    import '/_102040_/l2/molecules/groupselectone/ml-segmented-control';
    import '/_102040_/l2/molecules/groupviewmetric/ml-metric-big-number';
    import '/_102040_/l2/molecules/groupviewchart/ml-area-chart';
    import '/_102040_/l2/molecules/groupviewchart/ml-pie-chart';
    import '/_102040_/l2/molecules/groupviewtable/ml-view-table';
    import '/_102040_/l2/molecules/groupnavigatesection/ml-tabs';
    export class FinancialReport extends StateLitElement {
        startDate: string;
        endDate: string;
        granularity: string;
        activeView: 'revenue' | 'expense' | 'margin';
        activeTab: string;
        private readonly summary;
        private kpiRing;
        render(): any;
    }
}
declare module "_102053_/l2/testes/ml-radio-group-exemple" {
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    import '/_102040_/l2/molecules/groupselectone/ml-radio-group';
    interface Config {
        value: string;
        isEditing: boolean;
        required: boolean;
        disabled: boolean;
        readonly: boolean;
        loading: boolean;
        error: string;
    }
    export class MlRadioGroupExemple extends StateLitElement {
        basic: Config;
        grouped: Config;
        private toggle;
        private renderToggle;
        private renderConfig;
        render(): any;
    }
}
declare module "_102053_/l2/testes/order-management" {
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    import '/_102040_/l2/molecules/groupsearchcontent/ml-search-bar';
    import '/_102040_/l2/molecules/groupenterdateinterval/ml-date-range-dual-calendar';
    import '/_102040_/l2/molecules/groupselectmany/ml-multi-select-dropdown';
    import '/_102040_/l2/molecules/groupselectone/ml-select-dropdown';
    import '/_102040_/l2/molecules/groupviewtable/ml-data-table';
    import '/_102040_/l2/molecules/groupnotifyuser/ml-notify-banner';
    import '/_102040_/l2/molecules/groupviewchart/ml-line-chart';
    import '/_102040_/l2/molecules/groupnavigatesection/ml-tabs';
    export class OrderManagement extends StateLitElement {
        activeTab: string;
        search: string;
        statusFilter: string;
        sortBy: string;
        filterStartDate: string;
        filterEndDate: string;
        page: number;
        bannerVisible: boolean;
        private readonly pageSize;
        private readonly allOrders;
        private readonly volumePoints;
        private get filteredOrders();
        private get visibleOrders();
        private toStatusKey;
        private countByTab;
        private statusBadge;
        private lateInTransit;
        render(): any;
    }
}
declare module "_102053_/l2/testes/org-chart" {
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    import '/_102040_/l2/molecules/groupnavigatemain/ml-sidebar-nav';
    import '/_102040_/l2/molecules/groupnavigatesection/ml-breadcrumb-trail';
    import '/_102040_/l2/molecules/groupnavigatesection/ml-navigate-pills';
    import '/_102040_/l2/molecules/groupviewhierarchy/ml-hierarchy-orgchart';
    import '/_102040_/l2/molecules/groupviewhierarchy/ml-hierarchy-tree';
    import '/_102040_/l2/molecules/groupviewhierarchy/ml-hierarchy-tree-diagram';
    import '/_102040_/l2/molecules/groupviewcard/ml-vertical-card';
    import '/_102040_/l2/molecules/groupsearchcontent/ml-search-bar';
    import '/_102040_/l2/molecules/groupselectone/ml-segmented-control';
    import '/_102040_/l2/molecules/groupshowprogress/ml-circular-progress';
    import '/_102040_/l2/molecules/grouptriggeraction/ml-icon-button';
    import '/_102040_/l2/molecules/groupnotifyuser/ml-toast-notification';
    type ViewMode = 'orgchart' | 'tree' | 'diagram';
    type LevelFilter = 'all' | 'exec' | 'manager' | 'operational';
    interface Employee {
        name: string;
        role: string;
        level: LevelFilter;
        dept: string;
        email: string;
    }
    export class OrgChart extends StateLitElement {
        activeDept: string;
        activeView: ViewMode;
        levelFilter: LevelFilter;
        searchQuery: string;
        selectedEmployee: Employee | null;
        loadingChart: boolean;
        loadingProgress: number;
        toastVisible: boolean;
        toastMessage: string;
        private readonly navItems;
        private readonly allEmployees;
        private get currentDeptLabel();
        private get employees();
        private initials;
        private levelLabel;
        private matchesSearch;
        private matchesLevel;
        private switchDept;
        private showToast;
        private handleNodeClick;
        private renderHierarchyNodes;
        render(): any;
    }
}
declare module "_102053_/l2/testes/product-edit" {
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    import '/_102040_/l2/molecules/groupentertext/ml-floating-text-input';
    import '/_102040_/l2/molecules/groupentertext/ml-multiline-text';
    import '/_102040_/l2/molecules/groupentermoney/ml-enter-money-br';
    import '/_102040_/l2/molecules/groupenternumber/ml-number-input';
    import '/_102040_/l2/molecules/groupenternumber/ml-number-stepper';
    import '/_102040_/l2/molecules/groupselectone/ml-select-dropdown';
    import '/_102040_/l2/molecules/groupselectmany/ml-multi-checkbox-list';
    import '/_102040_/l2/molecules/groupenterboolean/ml-toggle-switch';
    import '/_102040_/l2/molecules/groupnotifyuser/ml-toast-notification';
    export class ProductEdit extends StateLitElement {
        isEditing: boolean;
        toastVisible: boolean;
        errors: Record<string, string>;
        productName: string;
        sku: string;
        barcode: string;
        description: string;
        salePrice: number | null;
        costPrice: number | null;
        stock: number | null;
        minStock: number | null;
        packQty: number | null;
        category: string;
        supplier: string;
        tags: string;
        isActive: boolean;
        availOnline: boolean;
        private snapshot;
        private takeSnapshot;
        private restoreSnapshot;
        private edit;
        private cancel;
        private validate;
        private save;
        private err;
        private get margin();
        private get marginColor();
        private get stockStatus();
        private get categoryLabel();
        private get supplierLabel();
        render(): any;
    }
}
declare module "_102053_/l2/testes/select-one" {
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    import '/_102040_/l2/molecules/groupselectone/ml-radio-group';
    import '/_102040_/l2/molecules/groupselectone/ml-segmented-control';
    export class SelectOne102040 extends StateLitElement {
        radioValue: string;
        radioGroupedValue: string;
        segmentedValue: string;
        segmentedErrorValue: string;
        render(): any;
    }
}
declare module "_102053_/l2/testes/supplier-edit" {
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    import '/_102040_/l2/molecules/groupexpandcontent/ml-accordion';
    import '/_102040_/l2/molecules/groupentertext/ml-floating-text-input';
    import '/_102040_/l2/molecules/groupentertext/ml-multiline-text';
    import '/_102040_/l2/molecules/groupenterdate/ml-date-picker';
    import '/_102040_/l2/molecules/groupselectone/ml-select-dropdown';
    import '/_102040_/l2/molecules/groupselectone/ml-radio-group';
    import '/_102040_/l2/molecules/groupselectmany/ml-multi-checkbox-list';
    import '/_102040_/l2/molecules/groupenterboolean/ml-toggle-switch';
    import '/_102040_/l2/molecules/groupnotifyuser/ml-toast-notification';
    export class SupplierEdit extends StateLitElement {
        isEditing: boolean;
        toastVisible: boolean;
        viewEpoch: number;
        errors: Record<string, string>;
        companyName: string;
        cnpj: string;
        email: string;
        website: string;
        address: string;
        companyType: string;
        paymentTerm: string;
        currency: string;
        taxRegime: string;
        contractStart: string;
        certExpiry: string;
        categories: string;
        isActive: boolean;
        isHomologated: boolean;
        isPreferred: boolean;
        notes: string;
        private snapshot;
        private takeSnapshot;
        private restoreSnapshot;
        private edit;
        private cancel;
        private validate;
        private save;
        private err;
        private get companyTypeLabel();
        private get taxRegimeLabel();
        private get paymentTermLabel();
        private get currencyLabel();
        private readonly categoryMap;
        private get categoryLabels();
        private get initials();
        private statusBadge;
        private renderViewMode;
        private renderEditMode;
        render(): any;
    }
}
declare module "_102053_/l2/testes/system-settings" {
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    import '/_102040_/l2/molecules/groupnavigatesection/ml-tabs';
    import '/_102040_/l2/molecules/groupentertext/ml-floating-text-input';
    import '/_102040_/l2/molecules/groupselectone/ml-select-dropdown';
    import '/_102040_/l2/molecules/groupselectone/ml-segmented-control';
    import '/_102040_/l2/molecules/groupenternumber/ml-number-input';
    import '/_102040_/l2/molecules/groupentermoney/ml-enter-money-br';
    import '/_102040_/l2/molecules/groupenterboolean/ml-toggle-switch';
    import '/_102040_/l2/molecules/groupenterboolean/ml-checkbox-preference';
    import '/_102040_/l2/molecules/groupnotifyuser/ml-toast-notification';
    export class SystemSettings extends StateLitElement {
        activeTab: string;
        viewEpoch: number;
        toastVisible: boolean;
        toastMsg: string;
        isEditingGeral: boolean;
        isEditingNotif: boolean;
        isEditingLimites: boolean;
        isEditingIntegracoes: boolean;
        errors: Record<string, string>;
        companyName: string;
        domain: string;
        supportEmail: string;
        language: string;
        timezone: string;
        currency: string;
        theme: string;
        emailNotif: boolean;
        smsNotif: boolean;
        pushNotif: boolean;
        require2fa: boolean;
        autoApproveLimit: number;
        defaultingAlert: number;
        sessionTimeout: number;
        loginAttempts: number;
        erp: string;
        termsAccepted: boolean;
        dataRetention: boolean;
        private snapshotGeral;
        private snapshotNotif;
        private snapshotLimites;
        private snapshotIntegracoes;
        private editGeral;
        private cancelGeral;
        private saveGeral;
        private editNotif;
        private cancelNotif;
        private saveNotif;
        private editLimites;
        private cancelLimites;
        private saveLimites;
        private editIntegracoes;
        private cancelIntegracoes;
        private saveIntegracoes;
        private handleRequestEdit;
        private get languageLabel();
        private get timezoneLabel();
        private get currencyLabel();
        private get themeLabel();
        private get erpLabel();
        private formatMoney;
        private err;
        private badge;
        private editHeader;
        private renderGeralView;
        private renderNotifView;
        private renderLimitesView;
        private renderIntegracoesView;
        private renderGeralEditForm;
        private renderNotifEditForm;
        private renderLimitesEditForm;
        private renderIntegracoesEditForm;
        private renderActiveEditForm;
        private renderTabs;
        render(): any;
    }
}
declare module "_102053_/l2/testes/training-catalog" {
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    import '/_102040_/l2/molecules/groupnavigatesection/ml-breadcrumb-trail';
    import '/_102040_/l2/molecules/groupviewcard/ml-view-card-media';
    import '/_102040_/l2/molecules/groupviewdata/ml-card-grid';
    import '/_102040_/l2/molecules/groupplaymedia/ml-video-player';
    import '/_102040_/l2/molecules/groupplaymedia/ml-audio-player';
    import '/_102040_/l2/molecules/groupshowprogress/ml-linear-progress';
    import '/_102040_/l2/molecules/groupshowprogress/ml-circular-progress';
    import '/_102040_/l2/molecules/grouprateitem/ml-star-rating';
    import '/_102040_/l2/molecules/grouprateitem/ml-numeric-rating-nps';
    import '/_102040_/l2/molecules/groupexpandcontent/ml-single-expand-content';
    import '/_102040_/l2/molecules/groupenterdateinterval/ml-date-interval-drag';
    import '/_102040_/l2/molecules/grouptriggeraction/ml-split-button';
    import '/_102040_/l2/molecules/grouptriggeraction/ml-button-group';
    import '/_102040_/l2/molecules/groupselectmany/ml-multi-select-dropdown';
    import '/_102040_/l2/molecules/groupsearchcontent/ml-search-bar';
    import '/_102040_/l2/molecules/groupnotifyuser/ml-toast-notification';
    type FormatFilter = 'video' | 'audio' | 'reading';
    export class TrainingCatalog extends StateLitElement {
        lessonProgress: number;
        courseComplete: boolean;
        userRating: number;
        npsScore: number | null;
        formatFilter: FormatFilter;
        areaFilter: string;
        searchQuery: string;
        enrollmentStart: string;
        enrollmentEnd: string;
        toastVisible: boolean;
        toastMessage: string;
        private readonly course;
        private readonly recommendedCourses;
        private get filteredCourses();
        private showToast;
        private simulateProgress;
        private formatLabel;
        render(): any;
    }
}
declare module "_102053_/l2/testes/vehicle-registration" {
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    import '/_102040_/l2/molecules/groupentertext/ml-floating-text-input';
    import '/_102040_/l2/molecules/groupselectone/ml-combobox';
    import '/_102040_/l2/molecules/groupselectone/ml-select-one-autocomplete';
    import '/_102040_/l2/molecules/groupselectone/ml-segmented-control';
    import '/_102040_/l2/molecules/groupenternumber/ml-number-input';
    import '/_102040_/l2/molecules/groupnotifyuser/ml-notify-banner';
    export class VehicleRegistration extends StateLitElement {
        codigo: string;
        dataInclusao: string;
        dataModificacao: string;
        placa: string;
        situacao: string;
        marca: string;
        modelo: string;
        anoFabricacao: number | null;
        anoModelo: number | null;
        quilometragem: number | null;
        errors: Record<string, string>;
        saved: boolean;
        private readonly currentYear;
        private readonly brands;
        private readonly modelsByBrand;
        private err;
        private getModelos;
        private validate;
        private handleSave;
        private handleCancel;
        render(): any;
        private renderControle;
        private renderIdentificacao;
        private renderDadosVeiculo;
        private renderEstadoAtual;
        private renderSectionHeader;
    }
}
