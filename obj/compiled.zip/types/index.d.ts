declare module "_102027_/l2/collabImport" {
    interface CollabImportOptions {
        project: number;
        shortName: string;
        folder: string;
        extension?: '.defs.ts' | '.ts' | '.test.ts';
    }
    export function collabImport(opts: CollabImportOptions): Promise<any>;
}
declare module "_102029_/l2/designSystemBase" {
    export interface IKeyValueToken {
        [key: string]: string;
    }
    /** A custom @font-face entry (self-hosted / arbitrary URL). */
    export interface DsFontFace {
        weight?: number;
        style?: string;
        src: string;
    }
    /**
     * One font ROLE. `name` is the role (display, body, mono, …).
     * `source` decides how the family is LOADED:
     *   - system: already installed (no load)
     *   - google: loaded via `@import` from Google Fonts (URL derived from family + weights)
     *   - custom: loaded from `url` (a stylesheet @import) or `faces` (@font-face blocks)
     */
    export interface DsFont {
        name: string;
        source?: 'system' | 'google' | 'custom';
        family: string;
        weights?: number[];
        fallback?: string;
        url?: string;
        faces?: DsFontFace[];
    }
    /**
     * Molecule-token reconciliation for a DS entry: the `--ml-*` vocabulary of the used
     * molecule groups mapped to `--ds-*` expressions. Lives on the entry (same home as the
     * tokens) and is applied by the render into `:root` (see {@link tokensCssFromTheme}).
     *
     * Runtime-clean core interface — the reconciliation agent (`_102020_/l2/dsMatch`)
     * re-exports it so both sides share one shape.
     */
    export interface DsTokenReconciliation {
        version: string;
        usedGroups?: string[];
        map: Record<string, string | null>;
        pinned?: Record<string, string>;
    }
    export interface IDesignSystemTokens {
        themeName: string;
        description: string;
        color: IKeyValueToken;
        typography: IKeyValueToken;
        global: IKeyValueToken;
        /** Font roles that need LOADING (@import/@font-face). The family value itself still lives as a regular token (e.g. `typography['font-family-primary']`). */
        fonts?: DsFont[];
        /** Correlates this entry with the generation config bucket `designSystems[dsIndex]` in l5/project.json (and the `page<layout><ds>` folders). Falls back to the array position + 1 when absent. */
        dsIndex?: string;
        /** Molecule-token reconciliation (`--ml-*` → `--ds-*`), applied by the render into `:root`. */
        tokenReconciliation?: DsTokenReconciliation;
    }
    export interface IDesignSystem {
        tokens: IDesignSystemTokens[];
    }
    export interface IDarkLight {
        [theme: string]: IKeyValueToken;
    }
    /**
     * Loads the project design system and compiles its tokens into ready-to-inject CSS:
     * font-loading rules (`@import`/`@font-face`, when the theme declares `fonts`) followed by
     * a `:root { --token: value; }` block and a `[data-theme="dark"], :root.dark` override block.
     *
     * Runs both in dev (editor/preview) and at app bootstrap in production.
     *
     * @param theme - Which theme to compile: a numeric index into the `tokens` array, or a string matched against `themeName`. Falls back to the first theme when omitted or not found.
     * @param path - Module path of the design system file, forwarded to {@link getTokens}. Defaults to the production convention `/designSystem.js`; dev callers should pass the preview path (e.g. `/_102048_/l2/designSystem.js`).
     * @returns The compiled CSS string, or an empty string when the project has no design system.
     * @throws When the design system exists but its tokens fail to compile.
     */
    export function getTokensCss(nameOrIndex?: number | string, path?: string): Promise<string>;
    /**
     * Compile ONE theme entry into ready-to-inject CSS: font-loading rules (`@import`/`@font-face`)
     * followed by the `:root` / `[data-theme="dark"], :root.dark` custom-property blocks. Pure
     * (no I/O) — the shared core of both the runtime {@link getTokensCss} and the editor variant
     * (`_102027_/l2/designSystemBase.getTokensCss`).
     *
     * @param tokenInfo - The theme entry (color + typography + global maps; dark via `_dark-` prefix; optional `fonts`; optional `tokenReconciliation`).
     * @returns The compiled CSS string.
     */
    export function tokensCssFromTheme(tokenInfo: IDesignSystemTokens): string;
    /**
     * Molecule-token reconciliation as a `:root` block: each `--ml-*` mapped to its `--ds-*`
     * expression (`map`, then `pinned` overrides which win). `null`/empty values are skipped —
     * the molecule keeps its own default. Theme-agnostic: the values point at `var(--ds-*)`,
     * which already switch in the dark block, so a single `:root` block covers both themes.
     *
     * @param reconciliation - The entry's `tokenReconciliation`; absent/empty yields an empty string.
     * @returns The `:root { --ml-*: …; }` block, or an empty string when nothing is mapped.
     */
    export function getMlTokensCss(reconciliation?: DsTokenReconciliation): string;
    /**
     * Font-loading CSS for one theme: `@import` lines (google + custom URLs) and
     * `@font-face` blocks (custom self-hosted sources). Must come before every other
     * rule in the final stylesheet — `@import` is only valid at the top.
     *
     * @param fonts - The theme's `fonts` declarations; absent/empty yields an empty string.
     * @returns The font-loading CSS, or an empty string when there is nothing to load.
     */
    export function getFontLoadsCss(fonts?: DsFont[]): string;
    /**
     * Dynamically imports the design system module and returns its raw token themes.
     *
     * Note: `import()` caches by URL — in dev, append a cache-busting query
     * (e.g. `?v=${Date.now()}`) to the path to reload after the design system changes.
     *
     * @param path - Module path of the design system file. Defaults to `/designSystem.js`, the path where the built app serves it in production.
     * @returns The design system's `tokens` array (one entry per theme), or an empty array when the module exports none.
     * @throws When the module cannot be imported or resolves to nothing.
     */
    export function getTokens(path?: string): Promise<IDesignSystemTokens[]>;
    /**
     * Strips every `//Start Less Tokens ... //End Less Tokens` block from a Less source,
     * so token definitions injected by the editor are not duplicated when recompiling.
     *
     * @param src - Less source that may contain injected token blocks.
     * @returns The source without the token blocks.
     */
    export function removeTokensFromSource(src: string): string;
    /**
     * Splits a flat token map into theme groups by key prefix: keys starting with
     * `_dark-` go to the `dark` group, everything else goes to `root` (light/default).
     *
     * @param allTokens - Flat map with all tokens of a theme (color + typography + global merged).
     * @returns Tokens grouped by theme name (`root`, `dark`), keeping the original keys.
     */
    export function getDarkAndLight(allTokens: IKeyValueToken): IDarkLight;
    /**
     * Renders theme groups as CSS custom-property blocks: the `root` group becomes
     * `:root { --token: value; }` and any other group becomes a
     * `[data-theme="dark"], :root.dark { ... }` block (both dark conventions — legacy
     * attribute and Aura class) with the theme prefix stripped from the keys.
     *
     * @param themes - Tokens grouped by theme, as produced by {@link getDarkAndLight}.
     * @returns The CSS blocks joined into a single string (values may still contain Less expressions — see {@link convertLessTokensToCss}).
     */
    export function getCssVars(themes: IDarkLight): string;
    /**
     * Rewrites Less token references (`@token`) as CSS variable reads (`var(--token)`),
     * so the output can be served straight to the browser without a Less compile step.
     *
     * A reference is only rewritten when the token exists in `tokens`; occurrences
     * inside `@media (...)` conditions or inside Less-only function calls (see
     * `lessOnlyFunctions`) are left untouched, since `var()` is invalid there.
     *
     * @param less - Less source containing `@token` references.
     * @param tokens - Map of known token names used to validate each reference.
     * @returns The source with valid token references converted to `var(--token)`.
     */
    export function convertLessTokensToCss(less: string, tokens: IKeyValueToken): string;
    /** The 11 color families (base key = `<family>-color`). `grey` has a distinct variant shape. */
    export const MANDATORY_COLOR_FAMILIES: readonly ["text-primary", "text-secondary", "bg-primary", "bg-secondary", "grey", "error", "success", "warning", "info", "active", "link"];
    export type MandatoryColorFamily = typeof MANDATORY_COLOR_FAMILIES[number];
    /** Complete default DS tokens (light + `_dark-` pairs). The canonical mandatory baseline. */
    export const DEFAULT_TOKENS_TEMPLATE: {
        color: IKeyValueToken;
        global: IKeyValueToken;
        typography: IKeyValueToken;
    };
    /** The mandatory token names per section (derived from the template — the lock/completeness list). */
    export const MANDATORY_TOKEN_KEYS: {
        color: string[];
        global: string[];
        typography: string[];
    };
    /** True when `key` is a mandatory (non-deletable) token of `section`. */
    export function isMandatoryToken(section: 'color' | 'global' | 'typography', key: string): boolean;
    /** A fresh deep copy of the default template (never hand out the shared constant for mutation). */
    export function defaultTokensTemplate(): {
        color: IKeyValueToken;
        global: IKeyValueToken;
        typography: IKeyValueToken;
    };
}
declare module "_102027_/l2/utils" {
    export function getPath(widget: string): mls.stor.IFileInfoBase | undefined;
    export function convertTagToFileName(tag: string): {
        shortName: string;
        project: number;
        folder: string;
    } | undefined;
    export function convertFileNameToTag(info: {
        shortName: string;
        project: number;
        folder?: string;
    }): string;
    export function setErrorOnModel(model: monaco.editor.ITextModel, line: number, startColumn: number, endColumn: number, message: string, severity: monaco.MarkerSeverity): void;
}
declare module "_102027_/l2/libCompile" {
    export const getDependenciesByHtmlFile: (file: mls.stor.IFileInfo, html: string, theme: string, withCss?: boolean) => Promise<IJSONDependence>;
    export const getDependenciesByHtml: (models: mls.editor.IModels, html: string, theme: string, withCss?: boolean) => Promise<IJSONDependence>;
    export const getDependenciesByMFile: (models: mls.editor.IModels, withCss?: boolean) => Promise<IJSONDependence>;
    export function getAllWebComponentsInSource(source: string): string[];
    export interface IJSONDependence {
        file: string;
        wcComponents: string[];
        importsMap: string[];
        importsJs: string[];
        importsLinks: {
            ref: string;
            rel: string;
        }[];
        tokens: string | undefined;
        globalCss: string;
        errors: {
            tag: string;
            error: string;
        }[];
    }
}
declare module "_102027_/l2/libCommom" {
    export function getMyKeysBranch(project: number): {
        branch: string;
        owner: string;
        repo: string;
    };
    export function createPath(project: number, shortName: string, folder: string): string;
    export function generateCompactTimestamp(): string;
    export function getDateFormated(dt: string): string;
    export function changeFavIcon(notification: boolean): void;
    export function checkIfHasLocalProject(): boolean;
    export function getLocalProjectName(): string;
    export function setLocalProjectName(prjName: string): void;
    export function getLocalProjectDependencies(): number[];
    export function setLocalProjectDependencies(dependencies: number[]): void;
    export function deleteLocalProject(): Promise<void>;
    export function isValidProjectName(name: string): boolean;
    export function escapeHTML(str: string): string;
    export function openService(service: string, position: 'left' | 'right', level: number, args?: Record<string, string>): Promise<void>;
    export function selectLevel(level: number): void;
    export function forceServiceInstance(level: number, service: string): Promise<void>;
    export function loadFileHTMLInContainer(el: HTMLElement, shortName: string, project: number): Promise<void>;
    export function convertColorToHex(color: string): string;
    export function getEnhancementName(file: {
        project: number;
        shortName: string;
        folder: string;
        level: number;
    }): Promise<string>;
    export function getStyleEnhancementName(file: {
        project: number;
        shortName: string;
        folder: string;
        level: number;
    }): Promise<string | undefined>;
    export function loadPluginProject(project: number, scope: string, onlyEnabled?: boolean): Promise<mls.plugin.MenuAction[]>;
    export function setProjectDetails(project: number): void;
    export function getProjectDetails(): mls.stor.localStor.IRetProjectDetails | undefined;
    export function calculateTotalStringSize(source: string, limitBase: number): ICalculateTotalStringSize;
    export function getListNewFilesToDeleteByFolder(project: number, folder: string, includeDist?: boolean): Promise<mls.stor.IFileInfo[]>;
    export function deleteAllFilesLocal(filesToDelete: mls.stor.IFileInfo[]): AsyncGenerator<string, void, unknown>;
    export function loadModuleFromProjectOrDependency(name: string, folder: string, ext: string): Promise<any>;
    export function findStorFileInProjectsOrDeps(projectActual: number, level: number, fileName: string, folder: string, extension: string): mls.stor.IFileInfo;
    export function saveOpenedFile(project: number, level: number, file: OpenedFile): void;
    export function getLastOpenedFiles(project: number): UserOpenedFiles;
    export function deleteLastOpenedFiles(project: number): void;
    export function getLastModule(): Record<string, string>;
    export function setLastModule(project: number, moduleName: string): void;
    export function getBaseTemplate(file: IInfoFile, enhancement?: string): Promise<string>;
    export function isStorContentEqualTemplateDefault(storFile: mls.stor.IFileInfo): Promise<boolean>;
    export function verifyNeedAddTripleslach(info: mls.stor.IFileInfoBase, src: string, extension: string, enhancement?: string): string;
    export function getInstanceByFile(file: mls.stor.IFileInfo): Promise<Object | undefined>;
    export function isNameValid(project: number, shortName: string, folder: string, level: number, extension: string): boolean;
    export function openElementInServiceDetails(el: HTMLElement): Promise<void>;
    export function clearServiceDetails(): Promise<void>;
    export function getProjectConfig(project: number): Promise<IProjectConfig | undefined>;
    export function getProjectModuleConfig(path: string, project: number): Promise<IProjectModuleConfig | undefined>;
    export function getMessageKey(messages: any): string;
    export type OpenedFile = string | OpenedFileL2;
    export type UserOpenedFiles = Record<number, OpenedFile>;
    export type OpenedFileL2 = {
        left?: string;
        right?: string;
    };
    export interface IProjectModuleConfig {
        theme: string;
        initialPage: string;
        menu: IProjectModuleConfigMenu[];
    }
    export interface IProjectModuleConfigMenu {
        pageName: string;
        title: string;
        auth: string;
        icon?: string;
        target?: string;
    }
    export interface IProjectConfigModules {
        name: string;
        path: string;
        pathServer?: string;
        auth: string;
        icon?: string;
    }
    export interface IProjectConfig {
        masterFrontEnd?: {
            build: string;
            start: string;
            liveView: string;
        };
        masterBackEnd?: {
            build: string;
            start: string;
            serverView: string;
        };
        modules: IProjectConfigModules[];
    }
    interface ICalculateTotalStringSize {
        totalsize: number;
        exceededLimit: boolean;
        sizeFormatted: string;
    }
    interface IInfoFile {
        project: number;
        folder: string;
        shortName: string;
        extension: string;
    }
}
declare module "_102027_/l2/libMindMap" {
    export const allDefs: Record<string, IdefModule>;
    export function getAllDefs(): Promise<Record<string, IdefModule>>;
    export function getDefsByFile(file: mls.stor.IFileInfo): Promise<mls.defs.AsIs | undefined>;
    export function getMindMapByName(file: string): Promise<MindMapData | undefined>;
    export function getMindMapByStorFile(file: mls.stor.IFileInfo): Promise<MindMapData | undefined>;
    export function setMindMapVariable(bread: MindMapNode[]): void;
    export function getMindMapVariable(): MindMapNode[];
    export type MindMapSelected = MindMapSelectedFile | MindMapSelectedPlugin;
    export interface MindMapSelectedBase {
        plugin: Function;
        args: string;
    }
    export interface MindMapSelectedFile extends MindMapSelectedBase {
        type: "file";
        file: mls.stor.IFileInfo;
        organism?: string;
        widget?: string;
        modelType?: mls.editor.ModelType;
    }
    export interface MindMapSelectedPlugin extends MindMapSelectedBase {
        type: "plugin";
        file: mls.stor.IFileInfo;
    }
    export type MindMapNodeType = 'main' | 'asIs' | 'codeInsights' | 'webcomponent' | 'imports' | 'importedBy' | 'language' | 'attributes' | 'file' | 'file_wc' | 'text' | 'findFile' | 'findFile_item';
    export interface MindMapNode {
        id: string;
        label: string;
        type: MindMapNodeType;
        related: string[];
        meta: Record<string, any>;
        description?: string;
        navigate?: boolean;
    }
    export interface MindMapData {
        current: string;
        nodes: MindMapNode[];
    }
    export interface MindMapNodeStyle {
        fill: string;
        stroke: string;
        text: string;
    }
    export type MindMapNodeStyles = Record<string, MindMapNodeStyle>;
    export interface IdefModule {
        file: mls.stor.IFileInfo;
        defs: mls.defs.AsIs;
    }
}
declare module "_102027_/l2/libModel" {
    export function waitModelIdle(model: mls.editor.IModelBase | undefined): Promise<void>;
    export function readProjectTypescriptAndCompile(project: number, shortName: string, needCompile?: boolean): Promise<void>;
    export function readProjectTypescriptAndCompileL1(project: number, shortName: string, needCompile?: boolean): Promise<void>;
    export function createAllModels(storFileBase: mls.stor.IFileInfo, needCompile?: boolean, awaitCompile?: boolean, createStorIfNeed?: boolean): Promise<mls.editor.IModels | undefined>;
    export function createModel(storFile: mls.stor.IFileInfo, needCompile?: boolean, awaitCompile?: boolean): Promise<mls.editor.IModelBase | undefined>;
    export function setErrorOnModel(model: monaco.editor.ITextModel, line: number, startColumn: number, endColumn: number, message: string, severity: monaco.MarkerSeverity): void;
    export function createModelAnyFile(storFile: mls.stor.IFileInfo): Promise<mls.editor.IModelBase>;
    export function setModelEventAny(model: mls.editor.IModelBase, storFile: mls.stor.IFileInfo): Promise<void>;
    export function _MarkCompileNeed(storFile: mls.stor.IFileInfo): Promise<void>;
    export interface IModelProcessing {
        begin(): void;
        end(): void;
        whenIdle(): Promise<void>;
        isProcessing(): boolean;
    }
    export class ModelProcessing implements IModelProcessing {
        private running;
        private idlePromise;
        private idleResolve;
        begin(): void;
        end(): void;
        whenIdle(): Promise<void>;
        isProcessing(): boolean;
    }
    export interface IModelBase extends mls.editor.IModelBase {
        changeTimeout?: number;
        processing?: IModelProcessing;
    }
}
declare module "_102027_/l2/designSystemBase" {
    import { removeTokensFromSource, type IDesignSystemTokens } from "_102029_/l2/designSystemBase";
    export { removeTokensFromSource, type IDesignSystemTokens };
    export function getTokens(project: number): Promise<IDesignSystemTokens[]>;
    export function getTokensLess(project: number, theme: string): Promise<string>;
    export function getTokensLessByTokensArray(tokens: IDesignSystemTokens[], theme: string): Promise<string>;
    export function getTokensCss(project: number, theme: string): Promise<string>;
    export function getGlobalCss(project: number, theme: string): Promise<string>;
    export function getGlobalLess(project: number): Promise<string>;
    export function compileLess(str: string): Promise<string>;
    export function preCompileLess(project: number, less: string, theme: string): Promise<string>;
    export function preCompileLessAction(lessSource: string, tokens: IDesignSystemTokens[], theme: string): Promise<string>;
    export function preCompileLessByThemeOrDefault(project: number, less: string, theme: string): Promise<string>;
    export function removeTokensTheme(project: number, themeName: string): Promise<void>;
    export function replaceTokensBlock(code: string, newContent: string): string;
}
declare module "_102053_/l2/designSystem" {
    import { IDesignSystemTokens } from "_102027_/l2/designSystemBase";
    export const tokens: IDesignSystemTokens[];
}
declare module "_102053_/l2/project" {
    export const projectConfig: {
        masterFrontEnd: {
            build: string;
            start: string;
            liveView: string;
        };
        masterBackEnd: {
            build: string;
            start: string;
            serverView: string;
        };
        modules: any[];
    };
}
declare module "_102029_/l2/collabState" {
    /**
     * Returns the value for a given state key.
     * @param key State key in dot notation.
     * @returns The value stored at the specified key, or undefined if not set.
     */
    export function getState(key: string): any;
    /**
     * Updates the value for a given state key.
     * @param key State key in dot notation.
     * @param value Value to be stored.
     * @param systemChange Optional. If true, marks as a system-initiated change.
     */
    export function setState(key: string, value: any, systemChange?: boolean): void;
    /**
     * Subscribes a component to one or more state keys.
     * @param keyOrKeys - The state key or keys. Example: 'name/0;ui.name'.
     * Use a key starting with '*' (e.g. '*myKey;ui.xxx') to ensure only one active subscription with that key.
     * @param component - The subscribing component or callback function.
     */
    export function subscribe(keyOrKeys: string | string[], component: Object): void;
    /**
     * Unsubscribe a component from a state key or keys.
     * @param keyOrKeys - The state key or keys.
     * @param component - The unsubscribing component.
     */
    export function unsubscribe(keyOrKeys: string | string[], component: Object | "*"): void;
    /**
     * Notify subscribed components about a state change.
     * @param key - The state key that changed.
     */
    export function notify(key: string): void;
    /**
     * Initializes a nested property in the global state object if it doesn't already exist.
     * If the property exists, it retains its current value without being overwritten.
     *
     * @param {string} path - The dot-separated path specifying the property to initialize (e.g., "globalState.users").
     * @param {*} value - The value to set if the property at the given path does not exist.
     */
    export function initState(path: string, value: string | Object | Array<unknown>): void;
    export interface GlobalState {
        [key: string]: any;
    }
    export const globalState: {
        _ica: GlobalState;
        globalStateManagment: CollabState;
        globalVariation: number;
    };
    export interface CollabState {
        getState(key: string): any;
        setState(key: string, value: any, systemChange?: boolean): void;
        getHistory(): Array<{
            timestamp: number;
            system: boolean;
            key: string;
            value: any;
        }>;
        clearHistory(): void;
        subscribe(keyOrKeys: string | string[], component: Object): void;
        unsubscribe(keyOrKeys: string | string[], component: Object | "*"): void;
        notify(key: string): void;
    }
    export function getCollabStateInstance(): CollabState;
}
declare module "_102029_/l2/collabLitElement" {
    import { LitElement } from 'lit';
    /**
     * Class extending LitElement with CollabState functionality.
     */
    export class CollabLitElement extends LitElement {
        globalVariation: number;
        createRenderRoot(): this;
        protected updated(changedProperties: Map<string | number | symbol, unknown>): void;
        getMessageKey(messages: any): string;
        loadStyle(css: string): void;
    }
    export function getMessageKey(messages: any): string;
    export interface IScenaryDetails {
        description: string;
        html: HTMLElement;
    }
}
declare module "_102029_/l2/stateLitElement" {
    import { PropertyValueMap } from 'lit';
    import { CollabLitElement } from "_102029_/l2/collabLitElement";
    /**
     * Base class for all components that need to interact with the shared state.
     */
    export abstract class StateLitElement extends CollabLitElement {
        stateKeys: Map<string, boolean>;
        updateStateKeys(attributeName: string, paths: string[]): void;
        private subscribeToState;
        createRenderRoot(): this;
        connectedCallback(): void;
        disconnectedCallback(): void;
        firstUpdated(_changedProperties: PropertyValueMap<any> | Map<PropertyKey, unknown>): void;
        updated(_changedProps: PropertyValueMap<any> | Map<PropertyKey, unknown>): void;
        /**
         * Handle state changes from IcaState.
         * @param key - The state key that changed, ex: 'users[0].name'
         * @param value - The new value of the state.
         */
        handleIcaStateChange(key: string, value: any): void;
        connectMonitoring(): void;
    }
}
declare module "_102053_/l2/brutalshowcase/testeinicial" {
    import { TemplateResult } from 'lit';
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    import '/_102054_/l2/molecules/grouptriggeraction/ml-button-standard-brutal';
    import '/_102054_/l2/molecules/grouptriggeraction/ml-icon-button-brutal';
    import '/_102054_/l2/molecules/grouptriggeraction/ml-split-button-brutal';
    import '/_102054_/l2/molecules/groupenterboolean/ml-toggle-switch-brutal';
    import '/_102054_/l2/molecules/groupentertext/ml-floating-text-input-brutal';
    import '/_102054_/l2/molecules/groupentertext/ml-password-strength-input-brutal';
    import '/_102054_/l2/molecules/groupentertext/ml-tag-input-brutal';
    import '/_102054_/l2/molecules/groupenternumber/ml-number-stepper-brutal';
    import '/_102054_/l2/molecules/groupenternumber/ml-range-slider-brutal';
    import '/_102054_/l2/molecules/groupentermoney/ml-currency-input-brutal';
    export class BrutalShowcaseTesteInicial extends StateLitElement {
        render(): TemplateResult;
    }
}
declare module "_102053_/l2/demo1/acao-visualizacao" {
    import { TemplateResult } from 'lit';
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    import '/_102040_/l2/molecules/grouptriggeraction/ml-button-standard';
    import '/_102040_/l2/molecules/grouptriggeraction/ml-icon-button';
    import '/_102040_/l2/molecules/grouptriggeraction/ml-split-button';
    import '/_102040_/l2/molecules/groupshowprogress/ml-linear-progress';
    import '/_102040_/l2/molecules/groupshowprogress/ml-circular-progress';
    import '/_102040_/l2/molecules/groupviewcard/ml-profile-card';
    import '/_102040_/l2/molecules/groupviewcard/ml-vertical-card';
    import '/_102040_/l2/molecules/groupviewmetric/ml-metric-card';
    import '/_102040_/l2/molecules/groupviewmetric/ml-metric-big-number';
    export class Demo1AcaoVisualizacao extends StateLitElement {
        render(): TemplateResult;
    }
}
declare module "_102053_/l2/demo1/entrada" {
    import { TemplateResult } from 'lit';
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    import '/_102040_/l2/molecules/groupenterboolean/ml-toggle-switch';
    import '/_102040_/l2/molecules/groupenterdate/ml-date-picker';
    import '/_102040_/l2/molecules/groupenterdatetime/ml-datetime-picker';
    import '/_102040_/l2/molecules/groupentermoney/ml-currency-input';
    import '/_102040_/l2/molecules/groupenternumber/ml-number-stepper';
    import '/_102040_/l2/molecules/groupenternumber/ml-range-slider';
    import '/_102040_/l2/molecules/groupentertext/ml-floating-text-input';
    import '/_102040_/l2/molecules/groupentertext/ml-password-strength-input';
    import '/_102040_/l2/molecules/groupentertext/ml-tag-input';
    import '/_102040_/l2/molecules/groupentertime/ml-clock-time-picker';
    export class Demo1Entrada extends StateLitElement {
        private tgOn;
        private tgOff;
        private date;
        private dt;
        private price;
        private budget;
        private qty;
        private rangeLow;
        private rangeHigh;
        private fullName;
        private username;
        private password;
        private tags;
        private time;
        private upd;
        render(): TemplateResult;
    }
}
declare module "_102053_/l2/demo1/feedback" {
    import { TemplateResult } from 'lit';
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    import '/_102040_/l2/molecules/groupnotifyuser/ml-notify-banner';
    import '/_102040_/l2/molecules/groupnotifyuser/ml-toast-notification';
    import '/_102040_/l2/molecules/groupnotifyuser/ml-alert-modal';
    import '/_102040_/l2/molecules/groupexpandcontent/ml-accordion';
    import '/_102040_/l2/molecules/groupexpandcontent/ml-collapsible-panel';
    import '/_102040_/l2/molecules/groupexpandcontent/ml-reveal-overlay';
    import '/_102040_/l2/molecules/grouprateitem/ml-star-rating';
    import '/_102040_/l2/molecules/grouprateitem/ml-emoji-mood-scale';
    export class Demo1Feedback extends StateLitElement {
        private stars;
        private mood;
        private modalOpen;
        private upd;
        render(): TemplateResult;
    }
}
declare module "_102053_/l2/demo1/navegacao" {
    import { TemplateResult } from 'lit';
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    import '/_102040_/l2/molecules/groupnavigatesection/ml-tabs';
    import '/_102040_/l2/molecules/groupnavigatesection/ml-navigate-pills';
    import '/_102040_/l2/molecules/groupnavigatesection/ml-breadcrumb-trail';
    import '/_102040_/l2/molecules/groupnavigatesteps/ml-horizontal-stepper';
    import '/_102040_/l2/molecules/groupnavigatesteps/ml-wizard-steps';
    import '/_102040_/l2/molecules/groupnavigatemain/ml-sidebar-nav';
    export class Demo1Navegacao extends StateLitElement {
        private main;
        private tab;
        private pill;
        private step;
        private wiz;
        private upd;
        render(): TemplateResult;
    }
}
declare module "_102053_/l2/demo1/selecao" {
    import { TemplateResult } from 'lit';
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    import '/_102040_/l2/molecules/groupselectone/ml-select-dropdown';
    import '/_102040_/l2/molecules/groupselectone/ml-radio-group';
    import '/_102040_/l2/molecules/groupselectone/ml-segmented-control';
    import '/_102040_/l2/molecules/groupselectone/ml-combobox';
    import '/_102040_/l2/molecules/groupselectone/ml-card-selector';
    import '/_102040_/l2/molecules/groupselectmany/ml-multi-select-dropdown';
    import '/_102040_/l2/molecules/groupselectmany/ml-popover-multi-select';
    import '/_102040_/l2/molecules/groupsearchcontent/ml-search-bar';
    import '/_102040_/l2/molecules/groupselectfileforupload/ml-file-upload-dropzone';
    export class Demo1Selecao extends StateLitElement {
        private country;
        private plan;
        private view;
        private fruit;
        private tier;
        private skills;
        private hab;
        private q;
        private upd;
        render(): TemplateResult;
    }
}
declare module "_102053_/l2/demo2/acao-visualizacao" {
    import { TemplateResult } from 'lit';
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    import '/_102054_/l2/molecules/grouptriggeraction/ml-button-standard-brutal';
    import '/_102054_/l2/molecules/grouptriggeraction/ml-icon-button-brutal';
    import '/_102054_/l2/molecules/grouptriggeraction/ml-split-button-brutal';
    import '/_102054_/l2/molecules/groupshowprogress/ml-linear-progress-brutal';
    import '/_102054_/l2/molecules/groupshowprogress/ml-circular-progress-brutal';
    import '/_102054_/l2/molecules/groupviewcard/ml-profile-card-brutal';
    import '/_102054_/l2/molecules/groupviewcard/ml-vertical-card-brutal';
    import '/_102054_/l2/molecules/groupviewmetric/ml-metric-card-brutal';
    import '/_102054_/l2/molecules/groupviewmetric/ml-metric-big-number-brutal';
    export class Demo2AcaoVisualizacao extends StateLitElement {
        render(): TemplateResult;
    }
}
declare module "_102053_/l2/demo2/entrada" {
    import { TemplateResult } from 'lit';
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    import '/_102054_/l2/molecules/groupenterboolean/ml-toggle-switch-brutal';
    import '/_102054_/l2/molecules/groupenterdate/ml-date-picker-brutal';
    import '/_102054_/l2/molecules/groupenterdatetime/ml-datetime-picker-brutal';
    import '/_102054_/l2/molecules/groupentermoney/ml-currency-input-brutal';
    import '/_102054_/l2/molecules/groupenternumber/ml-number-stepper-brutal';
    import '/_102054_/l2/molecules/groupenternumber/ml-range-slider-brutal';
    import '/_102054_/l2/molecules/groupentertext/ml-floating-text-input-brutal';
    import '/_102054_/l2/molecules/groupentertext/ml-password-strength-input-brutal';
    import '/_102054_/l2/molecules/groupentertext/ml-tag-input-brutal';
    import '/_102054_/l2/molecules/groupentertime/ml-clock-time-picker-brutal';
    export class Demo2Entrada extends StateLitElement {
        private tgOn;
        private tgOff;
        private date;
        private dt;
        private price;
        private budget;
        private qty;
        private rangeLow;
        private rangeHigh;
        private fullName;
        private username;
        private password;
        private tags;
        private time;
        private upd;
        render(): TemplateResult;
    }
}
declare module "_102053_/l2/demo2/feedback" {
    import { TemplateResult } from 'lit';
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    import '/_102054_/l2/molecules/groupnotifyuser/ml-notify-banner-brutal';
    import '/_102054_/l2/molecules/groupnotifyuser/ml-toast-notification-brutal';
    import '/_102054_/l2/molecules/groupnotifyuser/ml-alert-modal-brutal';
    import '/_102054_/l2/molecules/groupexpandcontent/ml-accordion-brutal';
    import '/_102054_/l2/molecules/groupexpandcontent/ml-collapsible-panel-brutal';
    import '/_102054_/l2/molecules/groupexpandcontent/ml-reveal-overlay-brutal';
    import '/_102054_/l2/molecules/grouprateitem/ml-star-rating-brutal';
    import '/_102054_/l2/molecules/grouprateitem/ml-emoji-mood-scale-brutal';
    export class Demo2Feedback extends StateLitElement {
        private stars;
        private mood;
        private modalOpen;
        private upd;
        render(): TemplateResult;
    }
}
declare module "_102053_/l2/demo2/navegacao" {
    import { TemplateResult } from 'lit';
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    import '/_102054_/l2/molecules/groupnavigatesection/ml-tabs-brutal';
    import '/_102054_/l2/molecules/groupnavigatesection/ml-navigate-pills-brutal';
    import '/_102054_/l2/molecules/groupnavigatesection/ml-breadcrumb-trail-brutal';
    import '/_102054_/l2/molecules/groupnavigatesteps/ml-horizontal-stepper-brutal';
    import '/_102054_/l2/molecules/groupnavigatesteps/ml-wizard-steps-brutal';
    import '/_102054_/l2/molecules/groupnavigatemain/ml-sidebar-nav-brutal';
    export class Demo2Navegacao extends StateLitElement {
        private main;
        private tab;
        private pill;
        private step;
        private wiz;
        private upd;
        render(): TemplateResult;
    }
}
declare module "_102053_/l2/demo2/selecao" {
    import { TemplateResult } from 'lit';
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    import '/_102054_/l2/molecules/groupselectone/ml-select-dropdown-brutal';
    import '/_102054_/l2/molecules/groupselectone/ml-radio-group-brutal';
    import '/_102054_/l2/molecules/groupselectone/ml-segmented-control-brutal';
    import '/_102054_/l2/molecules/groupselectone/ml-combobox-brutal';
    import '/_102054_/l2/molecules/groupselectone/ml-card-selector-brutal';
    import '/_102054_/l2/molecules/groupselectmany/ml-multi-select-dropdown-brutal';
    import '/_102054_/l2/molecules/groupselectmany/ml-popover-multi-select-brutal';
    import '/_102054_/l2/molecules/groupsearchcontent/ml-search-bar-brutal';
    import '/_102054_/l2/molecules/groupselectfileforupload/ml-file-upload-dropzone-brutal';
    export class Demo2Selecao extends StateLitElement {
        private country;
        private plan;
        private view;
        private fruit;
        private tier;
        private skills;
        private hab;
        private q;
        private upd;
        render(): TemplateResult;
    }
}
declare module "_102053_/l2/demo3/acao-visualizacao" {
    import { TemplateResult } from 'lit';
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    import '/_102055_/l2/molecules/grouptriggeraction/ml-button-standard-glass';
    import '/_102055_/l2/molecules/grouptriggeraction/ml-icon-button-glass';
    import '/_102055_/l2/molecules/grouptriggeraction/ml-split-button-glass';
    import '/_102055_/l2/molecules/groupshowprogress/ml-linear-progress-glass';
    import '/_102055_/l2/molecules/groupshowprogress/ml-circular-progress-glass';
    import '/_102055_/l2/molecules/groupviewcard/ml-profile-card-glass';
    import '/_102055_/l2/molecules/groupviewcard/ml-vertical-card-glass';
    import '/_102055_/l2/molecules/groupviewmetric/ml-metric-card-glass';
    import '/_102055_/l2/molecules/groupviewmetric/ml-metric-big-number-glass';
    export class Demo3AcaoVisualizacao extends StateLitElement {
        render(): TemplateResult;
    }
}
declare module "_102053_/l2/demo3/entrada" {
    import { TemplateResult } from 'lit';
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    import '/_102055_/l2/molecules/groupenterboolean/ml-toggle-switch-glass';
    import '/_102055_/l2/molecules/groupenterdate/ml-date-picker-glass';
    import '/_102055_/l2/molecules/groupenterdatetime/ml-datetime-picker-glass';
    import '/_102055_/l2/molecules/groupentermoney/ml-currency-input-glass';
    import '/_102055_/l2/molecules/groupenternumber/ml-number-stepper-glass';
    import '/_102055_/l2/molecules/groupenternumber/ml-range-slider-glass';
    import '/_102055_/l2/molecules/groupentertext/ml-floating-text-input-glass';
    import '/_102055_/l2/molecules/groupentertext/ml-password-strength-input-glass';
    import '/_102055_/l2/molecules/groupentertext/ml-tag-input-glass';
    import '/_102055_/l2/molecules/groupentertime/ml-clock-time-picker-glass';
    export class Demo3Entrada extends StateLitElement {
        private tgOn;
        private tgOff;
        private date;
        private dt;
        private price;
        private budget;
        private qty;
        private rangeLow;
        private rangeHigh;
        private fullName;
        private username;
        private password;
        private tags;
        private time;
        private upd;
        render(): TemplateResult;
    }
}
declare module "_102053_/l2/demo3/feedback" {
    import { TemplateResult } from 'lit';
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    import '/_102055_/l2/molecules/groupnotifyuser/ml-notify-banner-glass';
    import '/_102055_/l2/molecules/groupnotifyuser/ml-toast-notification-glass';
    import '/_102055_/l2/molecules/groupnotifyuser/ml-alert-modal-glass';
    import '/_102055_/l2/molecules/groupexpandcontent/ml-accordion-glass';
    import '/_102055_/l2/molecules/groupexpandcontent/ml-collapsible-panel-glass';
    import '/_102055_/l2/molecules/groupexpandcontent/ml-reveal-overlay-glass';
    import '/_102055_/l2/molecules/grouprateitem/ml-star-rating-glass';
    import '/_102055_/l2/molecules/grouprateitem/ml-emoji-mood-scale-glass';
    export class Demo3Feedback extends StateLitElement {
        private stars;
        private mood;
        private modalOpen;
        private upd;
        render(): TemplateResult;
    }
}
declare module "_102053_/l2/demo3/navegacao" {
    import { TemplateResult } from 'lit';
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    import '/_102055_/l2/molecules/groupnavigatesection/ml-tabs-glass';
    import '/_102055_/l2/molecules/groupnavigatesection/ml-navigate-pills-glass';
    import '/_102055_/l2/molecules/groupnavigatesection/ml-breadcrumb-trail-glass';
    import '/_102055_/l2/molecules/groupnavigatesteps/ml-horizontal-stepper-glass';
    import '/_102055_/l2/molecules/groupnavigatesteps/ml-wizard-steps-glass';
    import '/_102055_/l2/molecules/groupnavigatemain/ml-sidebar-nav-glass';
    export class Demo3Navegacao extends StateLitElement {
        private main;
        private tab;
        private pill;
        private step;
        private wiz;
        private upd;
        render(): TemplateResult;
    }
}
declare module "_102053_/l2/demo3/selecao" {
    import { TemplateResult } from 'lit';
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    import '/_102055_/l2/molecules/groupselectone/ml-select-dropdown-glass';
    import '/_102055_/l2/molecules/groupselectone/ml-radio-group-glass';
    import '/_102055_/l2/molecules/groupselectone/ml-segmented-control-glass';
    import '/_102055_/l2/molecules/groupselectone/ml-combobox-glass';
    import '/_102055_/l2/molecules/groupselectone/ml-card-selector-glass';
    import '/_102055_/l2/molecules/groupselectmany/ml-multi-select-dropdown-glass';
    import '/_102055_/l2/molecules/groupselectmany/ml-popover-multi-select-glass';
    import '/_102055_/l2/molecules/groupsearchcontent/ml-search-bar-glass';
    import '/_102055_/l2/molecules/groupselectfileforupload/ml-file-upload-dropzone-glass';
    export class Demo3Selecao extends StateLitElement {
        private country;
        private plan;
        private view;
        private fruit;
        private tier;
        private skills;
        private hab;
        private q;
        private upd;
        render(): TemplateResult;
    }
}
declare module "_102029_/l2/collabDecorators" {
    import { PropertyDeclaration } from 'lit';
    /**
     * Custom decorator to bind properties to multiple data sources dynamically.
     * @param options - Property options, including type and default value.
     * Accepts variations, e.g., label="Hello {{user.name}}" label-pt="Olá {{user.name}}".
     * Do not use this for changing data sources dynamically (e.g., input values);
     * use `propertyDataSource` instead.
     * This decorator will read state values but does not persist changes to the state.
     */
    export function propertyCompositeDataSource(options?: PropertyDeclaration): (proto: any, propName: PropertyKey) => any;
    /**
     * Custom decorator to bind properties either to static data or dynamically from CollabState.
     * @param options - Property options, including type and default value.
     * Does not support variations; use `propertyCompositeDataSource` for variations.
     * For example, label="Hello {{user.name}}" label-pt="Olá {{user.name}}" (label-pt is ignored).
     * This decorator will read state values and persist changes to the state.
     */
    export function propertyDataSource(options?: PropertyDeclaration): (proto: any, propName: PropertyKey) => any;
    export interface OptionItem {
        key: string;
        value: string;
    }
}
declare module "_102033_/l2/moleculeBase" {
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    export class MoleculeAuraElement extends StateLitElement {
        cssClass: string;
        protected slotTags: string[];
        /**
         * When true, this molecule is inside another molecule's slot tag.
         * It should NOT render — it exists only as raw HTML for the parent
         * molecule to read via getSlotContent().
         */
        private _isInert;
        /**
         * Checks if this element is inside a slot tag of a parent molecule.
         * Walks up the DOM looking for a parent MoleculeAuraElement whose
         * slot tags include one of our ancestors.
         */
        private _checkIfInert;
        private _snapshot;
        /**
         * Returns a parsed Document snapshot for querying slot tags.
         */
        private getSnapshot;
        /**
         * Takes a snapshot: reads outerHTML from slot tag children,
         * parses into isolated Document.
         */
        private _takeSnapshot;
        private _slotObserver;
        private _updateDebounceTimer;
        _mutationLock: boolean;
        connectedCallback(): void;
        disconnectedCallback(): void;
        private _stopNativeFormEvent;
        private _hideSlotTags;
        private _setupSlotObserver;
        private _isInsideSlotTag;
        private _teardownSlotObserver;
        private _debouncedSlotUpdate;
        /**
         * Called when slot tag content changes.
         * Re-takes snapshot, re-hides, re-renders.
         */
        _onSlotTagsChanged(): void;
        protected getSlot(tag: string): Element | null;
        protected getSlots(tag: string): Element[];
        protected getSlotAttr(tag: string, attr: string): string | null;
        protected getSlotContent(tag: string): string;
        protected hasSlot(tag: string): boolean;
        protected getSlotClass(tag: string): string;
    }
}
declare module "_102033_/l2/cn" {
    export function cn(...inputs: (string | undefined | null | false)[]): string;
}
declare module "_102053_/l2/molecules/grouptriggeraction/ml-button-standard" {
    import { TemplateResult } from 'lit';
    import { MoleculeAuraElement } from "_102033_/l2/moleculeBase";
    export class ButtonStandardMolecule extends MoleculeAuraElement {
        slotTags: string[];
        cssClass: string;
        size: 'xs' | 'sm' | 'md' | 'lg';
        type: 'button' | 'submit' | 'reset';
        iconPosition: 'start' | 'end';
        disabled: boolean;
        loading: boolean;
        private handleActionClick;
        private isDisabled;
        private getVariant;
        private getSizeKey;
        private getSizeClasses;
        private getVariantClasses;
        private getButtonClasses;
        private getSlotClass;
        private getIconClasses;
        private renderSpinner;
        render(): TemplateResult<1>;
    }
}
declare module "_102053_/l2/molecules/groupentertext/ml-floating-text-input" {
    import { TemplateResult } from 'lit';
    import { MoleculeAuraElement } from "_102033_/l2/moleculeBase";
    export class MlFloatingTextInputMolecule extends MoleculeAuraElement {
        slotTags: string[];
        cssClass: string;
        value: string;
        error: string;
        name: string;
        placeholder: string;
        maxLength: number | null;
        minLength: number | null;
        rows: number;
        autocomplete: string;
        inputType: string;
        mask: string;
        isEditing: boolean;
        disabled: boolean;
        readonly: boolean;
        required: boolean;
        loading: boolean;
        private rawDisplay;
        private isFocused;
        private uid;
        handleIcaStateChange(key: string, value: any): void;
        updated(changedProps: Map<string, unknown>): void;
        private handleInput;
        private handleBlur;
        private handleFocus;
        private shouldUseMask;
        private getMaskedDisplayValue;
        private applyMaskToRaw;
        private extractRawFromInput;
        private isMaskToken;
        private isCharValidForToken;
        private getSlotClass;
        private getLabelText;
        private getInputPlaceholder;
        private getViewValue;
        private renderPrefix;
        private renderSuffix;
        private renderFeedback;
        private renderInlineLabel;
        private renderFloatingLabel;
        private getContainerClasses;
        private getInputClasses;
        render(): TemplateResult<1>;
    }
}
declare module "_102053_/l2/molecules/groupenterboolean/ml-toggle-switch" {
    import { TemplateResult } from 'lit';
    import { MoleculeAuraElement } from "_102033_/l2/moleculeBase";
    export class ToggleSwitchMolecule extends MoleculeAuraElement {
        private msg;
        private uid;
        slotTags: string[];
        cssClass: string;
        value: boolean;
        error: string;
        name: string;
        isEditing: boolean;
        disabled: boolean;
        private getSlotClass;
        private handleToggle;
        private handleFocus;
        private handleBlur;
        private handleKeydown;
        private renderLabel;
        private renderHelper;
        private renderError;
        private getToggleButtonClasses;
        private getThumbClasses;
        private renderViewMode;
        render(): TemplateResult;
    }
}
declare module "_102053_/l2/molecules/groupexpandcontent/ml-accordion" {
    import { TemplateResult } from 'lit';
    import { MoleculeAuraElement } from "_102033_/l2/moleculeBase";
    export class MlAccordionMolecule extends MoleculeAuraElement {
        private msg;
        slotTags: string[];
        cssClass: string;
        multiple: boolean;
        disabled: boolean;
        loading: boolean;
        private openSections;
        firstUpdated(): void;
        private handleToggle;
        private handleHeaderKeydown;
        private findNextEnabledHeader;
        private getSlotClass;
        private getSectionContent;
        private getHeaderClasses;
        private getContentClasses;
        private getChevronClasses;
        render(): TemplateResult<1>;
        private renderLabel;
        private renderLoading;
        private renderSections;
        private renderSection;
    }
}
declare module "_102053_/l2/demo4/showcase-fase1-ds" {
    import { TemplateResult } from 'lit';
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    import "_102053_/l2/molecules/grouptriggeraction/ml-button-standard";
    import "_102053_/l2/molecules/groupentertext/ml-floating-text-input";
    import "_102053_/l2/molecules/groupenterboolean/ml-toggle-switch";
    import "_102053_/l2/molecules/groupexpandcontent/ml-accordion";
    export class Demo4ShowcaseFase1Ds extends StateLitElement {
        private toggleOn;
        private toggleOff;
        private handleInput;
        render(): TemplateResult;
    }
}
declare module "_102053_/l2/demo4/showcase-fase1" {
    import { TemplateResult } from 'lit';
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    import "_102053_/l2/molecules/grouptriggeraction/ml-button-standard";
    import "_102053_/l2/molecules/groupentertext/ml-floating-text-input";
    import "_102053_/l2/molecules/groupenterboolean/ml-toggle-switch";
    import "_102053_/l2/molecules/groupexpandcontent/ml-accordion";
    export class Demo4ShowcaseFase1 extends StateLitElement {
        private inputValue;
        private inputError;
        private toggleOn;
        private toggleOff;
        private handleInput;
        render(): TemplateResult;
    }
}
declare module "_102053_/l2/demo4/showcase-fase2" {
    import { TemplateResult } from 'lit';
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    import "_102053_/l2/molecules/grouptriggeraction/ml-button-standard";
    import "_102053_/l2/molecules/groupentertext/ml-floating-text-input";
    import "_102053_/l2/molecules/groupenterboolean/ml-toggle-switch";
    import "_102053_/l2/molecules/groupexpandcontent/ml-accordion";
    export class Demo4ShowcaseFase2 extends StateLitElement {
        private toggleVal;
        render(): TemplateResult;
    }
}
declare module "_102053_/l2/demo4/showcase-fase3" {
    import { TemplateResult } from 'lit';
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    import "_102053_/l2/molecules/grouptriggeraction/ml-button-standard";
    import "_102053_/l2/molecules/groupentertext/ml-floating-text-input";
    import "_102053_/l2/molecules/groupenterboolean/ml-toggle-switch";
    import "_102053_/l2/molecules/groupexpandcontent/ml-accordion";
    export class Demo4ShowcaseFase3 extends StateLitElement {
        private toggleVal;
        render(): TemplateResult;
    }
}
declare module "_102053_/l2/demo4/showcase-fase4" {
    import { TemplateResult } from 'lit';
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    import "_102053_/l2/molecules/grouptriggeraction/ml-button-standard";
    import "_102053_/l2/molecules/groupentertext/ml-floating-text-input";
    import "_102053_/l2/molecules/groupenterboolean/ml-toggle-switch";
    import "_102053_/l2/molecules/groupexpandcontent/ml-accordion";
    export class Demo4ShowcaseFase4 extends StateLitElement {
        private darkMode;
        private toggleVal;
        private toggleOff;
        private toggleDarkMode;
        render(): TemplateResult;
    }
}
declare module "_102053_/l2/demo4/sign-in" {
    import { TemplateResult } from 'lit';
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    import "_102053_/l2/molecules/grouptriggeraction/ml-button-standard";
    import "_102053_/l2/molecules/groupentertext/ml-floating-text-input";
    import "_102053_/l2/molecules/groupenterboolean/ml-toggle-switch";
    export class Demo4SignIn extends StateLitElement {
        private email;
        private password;
        private remember;
        private loading;
        private error;
        private handleSubmit;
        render(): TemplateResult;
    }
}
declare module "_102053_/l2/glassshowcase/checkout" {
    import { TemplateResult } from 'lit';
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    import '/_102054_/l2/molecules/groupentertext/ml-floating-text-input';
    import '/_102054_/l2/molecules/groupenterboolean/ml-toggle-switch';
    import '/_102054_/l2/molecules/groupexpandcontent/ml-accordion';
    import '/_102054_/l2/molecules/grouptriggeraction/ml-button-standard';
    export class GlassShowcaseCheckout extends StateLitElement {
        private cardName;
        private cardNumber;
        private expiry;
        private cpf;
        private saveCard;
        private diffAddress;
        private loading;
        private onCardName;
        private onCardNumber;
        private onExpiry;
        private onCpf;
        private onSaveCard;
        private onDiffAddress;
        private onConfirm;
        render(): TemplateResult;
    }
}
declare module "_102053_/l2/glassshowcase/demodropdown" {
    import { TemplateResult } from 'lit';
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    import '/_102054_/l2/molecules/groupselectone/ml-select-dropdown';
    export class GlassShowcaseDemoDropdown extends StateLitElement {
        private country;
        private team;
        private onCountry;
        private onTeam;
        render(): TemplateResult;
    }
}
declare module "_102053_/l2/glassshowcase/demolote2" {
    import { TemplateResult } from 'lit';
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    import '/_102054_/l2/molecules/groupnotifyuser/ml-notify-banner';
    import '/_102054_/l2/molecules/groupnotifyuser/ml-toast-notification';
    import '/_102054_/l2/molecules/groupnotifyuser/ml-alert-modal';
    import '/_102054_/l2/molecules/groupexpandcontent/ml-reveal-overlay';
    import '/_102054_/l2/molecules/grouptriggeraction/ml-button-standard';
    export class GlassShowcaseDemoLote2 extends StateLitElement {
        private bannerVisible;
        private toastVisible;
        private modalOpen;
        render(): TemplateResult;
    }
}
declare module "_102053_/l2/glassshowcase/demolote3" {
    import { TemplateResult } from 'lit';
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    import '/_102054_/l2/molecules/grouptriggeraction/ml-icon-button';
    import '/_102054_/l2/molecules/grouptriggeraction/ml-split-button';
    import '/_102054_/l2/molecules/groupviewcard/ml-profile-card';
    import '/_102054_/l2/molecules/groupviewcard/ml-vertical-card';
    import '/_102054_/l2/molecules/grouptriggeraction/ml-button-standard';
    export class GlassShowcaseDemoLote3 extends StateLitElement {
        render(): TemplateResult;
    }
}
declare module "_102053_/l2/glassshowcase/demolote4" {
    import { TemplateResult } from 'lit';
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    import '/_102054_/l2/molecules/groupnavigatesection/ml-tabs';
    import '/_102054_/l2/molecules/groupnavigatesection/ml-navigate-pills';
    import '/_102054_/l2/molecules/groupnavigatesection/ml-breadcrumb-trail';
    import '/_102054_/l2/molecules/groupnavigatemain/ml-sidebar-nav';
    export class GlassShowcaseDemoLote4 extends StateLitElement {
        private tab;
        private pill;
        private navItem;
        render(): TemplateResult;
    }
}
declare module "_102053_/l2/glassshowcase/demolote5" {
    import { TemplateResult } from 'lit';
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    import '/_102054_/l2/molecules/groupenternumber/ml-number-stepper';
    import '/_102054_/l2/molecules/groupenternumber/ml-range-slider';
    import '/_102054_/l2/molecules/groupentermoney/ml-currency-input';
    import '/_102054_/l2/molecules/groupentertext/ml-password-strength-input';
    import '/_102054_/l2/molecules/groupentertext/ml-tag-input';
    import '/_102054_/l2/molecules/groupselectone/ml-combobox';
    import '/_102054_/l2/molecules/groupselectone/ml-card-selector';
    import '/_102054_/l2/molecules/groupselectmany/ml-popover-multi-select';
    import '/_102054_/l2/molecules/groupsearchcontent/ml-search-bar';
    import '/_102054_/l2/molecules/groupselectfileforupload/ml-file-upload-dropzone';
    export class GlassShowcaseDemoLote5 extends StateLitElement {
        private qty;
        private priceLow;
        private priceHigh;
        private price;
        private password;
        private tags;
        private fruit;
        private tier;
        private langs;
        private query;
        render(): TemplateResult;
    }
}
declare module "_102053_/l2/glassshowcase/demolote6" {
    import { TemplateResult } from 'lit';
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    import '/_102054_/l2/molecules/groupviewmetric/ml-metric-card';
    import '/_102054_/l2/molecules/groupviewmetric/ml-metric-big-number';
    import '/_102054_/l2/molecules/groupshowprogress/ml-linear-progress';
    import '/_102054_/l2/molecules/groupshowprogress/ml-circular-progress';
    import '/_102054_/l2/molecules/groupnavigatesteps/ml-horizontal-stepper';
    import '/_102054_/l2/molecules/groupnavigatesteps/ml-wizard-steps';
    import '/_102054_/l2/molecules/grouprateitem/ml-star-rating';
    import '/_102054_/l2/molecules/grouprateitem/ml-emoji-mood-scale';
    import '/_102054_/l2/molecules/groupexpandcontent/ml-collapsible-panel';
    export class GlassShowcaseDemoLote6 extends StateLitElement {
        private step;
        private wiz;
        private stars;
        private mood;
        render(): TemplateResult;
    }
}
declare module "_102053_/l2/glassshowcase/demolote7" {
    import { TemplateResult } from 'lit';
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    import '/_102054_/l2/molecules/groupenterdate/ml-date-picker';
    import '/_102054_/l2/molecules/groupenterdatetime/ml-datetime-picker';
    import '/_102054_/l2/molecules/groupentertime/ml-clock-time-picker';
    export class GlassShowcaseDemoLote7 extends StateLitElement {
        private date;
        private dt;
        private time;
        render(): TemplateResult;
    }
}
declare module "_102053_/l2/glassshowcase/demomultiselect" {
    import { TemplateResult } from 'lit';
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    import '/_102054_/l2/molecules/groupselectmany/ml-multi-select-dropdown';
    export class GlassShowcaseDemoMultiSelect extends StateLitElement {
        private skills;
        private teams;
        private onSkills;
        private onTeams;
        render(): TemplateResult;
    }
}
declare module "_102053_/l2/glassshowcase/login" {
    import { TemplateResult } from 'lit';
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    import '/_102054_/l2/molecules/groupentertext/ml-floating-text-input';
    import '/_102054_/l2/molecules/groupenterboolean/ml-toggle-switch';
    import '/_102054_/l2/molecules/grouptriggeraction/ml-button-standard';
    export class GlassShowcaseLogin extends StateLitElement {
        private email;
        private password;
        private remember;
        private emailError;
        private loading;
        private onEmailInput;
        private onPasswordInput;
        private onRememberChange;
        private isEmailValid;
        private onSubmit;
        private goToSignup;
        render(): TemplateResult;
    }
}
declare module "_102053_/l2/glassshowcase/settings" {
    import { TemplateResult } from 'lit';
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    import '/_102054_/l2/molecules/groupentertext/ml-floating-text-input';
    import '/_102054_/l2/molecules/groupenterboolean/ml-toggle-switch';
    import '/_102054_/l2/molecules/groupexpandcontent/ml-accordion';
    import '/_102054_/l2/molecules/grouptriggeraction/ml-button-standard';
    export class GlassShowcaseSettings extends StateLitElement {
        private dirty;
        private loading;
        private values;
        private onFieldChange;
        private onSave;
        private onCancel;
        render(): TemplateResult;
    }
}
declare module "_102053_/l2/glassshowcase/signup" {
    import { TemplateResult } from 'lit';
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    import '/_102054_/l2/molecules/groupentertext/ml-floating-text-input';
    import '/_102054_/l2/molecules/groupenterboolean/ml-toggle-switch';
    import '/_102054_/l2/molecules/grouptriggeraction/ml-button-standard';
    export class GlassShowcaseSignup extends StateLitElement {
        private name;
        private email;
        private phone;
        private password;
        private acceptedTerms;
        private loading;
        private onName;
        private onEmail;
        private onPhone;
        private onPassword;
        private onTerms;
        private onSubmit;
        private goToLogin;
        render(): TemplateResult;
    }
}
declare module "_102053_/l2/glassshowcase2/demolotea" {
    import { TemplateResult } from 'lit';
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    import '/_102055_/l2/molecules/groupentertext/ml-floating-text-input-glass';
    import '/_102055_/l2/molecules/groupentertext/ml-password-strength-input-glass';
    import '/_102055_/l2/molecules/groupentertext/ml-tag-input-glass';
    import '/_102055_/l2/molecules/groupentermoney/ml-currency-input-glass';
    import '/_102055_/l2/molecules/groupenternumber/ml-number-stepper-glass';
    import '/_102055_/l2/molecules/groupenternumber/ml-range-slider-glass';
    export class GlassShowcase2DemoLoteA extends StateLitElement {
        private fullName;
        private password;
        private tags;
        private price;
        private qty;
        private priceLow;
        private priceHigh;
        render(): TemplateResult;
    }
}
declare module "_102053_/l2/glassshowcase2/demoloteb" {
    import { TemplateResult } from 'lit';
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    import '/_102055_/l2/molecules/groupselectone/ml-select-dropdown-glass';
    import '/_102055_/l2/molecules/groupselectone/ml-radio-group-glass';
    import '/_102055_/l2/molecules/groupselectone/ml-segmented-control-glass';
    import '/_102055_/l2/molecules/groupselectone/ml-combobox-glass';
    import '/_102055_/l2/molecules/groupselectone/ml-card-selector-glass';
    import '/_102055_/l2/molecules/groupselectmany/ml-multi-select-dropdown-glass';
    import '/_102055_/l2/molecules/groupselectmany/ml-popover-multi-select-glass';
    import '/_102055_/l2/molecules/groupsearchcontent/ml-search-bar-glass';
    import '/_102055_/l2/molecules/groupselectfileforupload/ml-file-upload-dropzone-glass';
    export class GlassShowcase2DemoLoteB extends StateLitElement {
        private country;
        private plan;
        private view;
        private fruit;
        private tier;
        private skills;
        private langs;
        private query;
        render(): TemplateResult;
    }
}
declare module "_102053_/l2/glassshowcase2/demolotec" {
    import { TemplateResult } from 'lit';
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    import '/_102055_/l2/molecules/groupenterdatetime/ml-datetime-picker-glass';
    import '/_102055_/l2/molecules/groupentertime/ml-clock-time-picker-glass';
    export class GlassShowcase2DemoLoteC extends StateLitElement {
        private dt;
        private time;
        render(): TemplateResult;
    }
}
declare module "_102053_/l2/glassshowcase2/demoloted" {
    import { TemplateResult } from 'lit';
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    import '/_102055_/l2/molecules/grouptriggeraction/ml-button-standard-glass';
    import '/_102055_/l2/molecules/grouptriggeraction/ml-icon-button-glass';
    import '/_102055_/l2/molecules/grouptriggeraction/ml-split-button-glass';
    import '/_102055_/l2/molecules/groupviewcard/ml-profile-card-glass';
    import '/_102055_/l2/molecules/groupviewcard/ml-vertical-card-glass';
    export class GlassShowcase2DemoLoteD extends StateLitElement {
        private lastAction;
        private selectedPlan;
        private onAction;
        render(): TemplateResult;
    }
}
declare module "_102053_/l2/glassshowcase2/demolotee" {
    import { TemplateResult } from 'lit';
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    import '/_102055_/l2/molecules/groupnavigatesection/ml-tabs-glass';
    import '/_102055_/l2/molecules/groupnavigatesection/ml-navigate-pills-glass';
    import '/_102055_/l2/molecules/groupnavigatesection/ml-breadcrumb-trail-glass';
    import '/_102055_/l2/molecules/groupnavigatemain/ml-sidebar-nav-glass';
    import '/_102055_/l2/molecules/groupnavigatesteps/ml-horizontal-stepper-glass';
    import '/_102055_/l2/molecules/groupnavigatesteps/ml-wizard-steps-glass';
    export class GlassShowcase2DemoLoteE extends StateLitElement {
        private bc;
        private pill;
        private tab;
        private navItem;
        private stepper;
        private wizard;
        render(): TemplateResult;
    }
}
declare module "_102053_/l2/glassshowcase2/demolotef" {
    import { TemplateResult } from 'lit';
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    import '/_102055_/l2/molecules/groupexpandcontent/ml-accordion-glass';
    import '/_102055_/l2/molecules/groupexpandcontent/ml-collapsible-panel-glass';
    import '/_102055_/l2/molecules/groupexpandcontent/ml-reveal-overlay-glass';
    import '/_102055_/l2/molecules/groupnotifyuser/ml-alert-modal-glass';
    import '/_102055_/l2/molecules/groupnotifyuser/ml-notify-banner-glass';
    import '/_102055_/l2/molecules/groupnotifyuser/ml-toast-notification-glass';
    export class GlassShowcase2DemoLoteF extends StateLitElement {
        private bannerVisible;
        private toastVisible;
        private modalOpen;
        render(): TemplateResult;
    }
}
declare module "_102053_/l2/glassshowcase2/demoloteg" {
    import { TemplateResult } from 'lit';
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    import '/_102055_/l2/molecules/groupviewmetric/ml-metric-card-glass';
    import '/_102055_/l2/molecules/groupviewmetric/ml-metric-big-number-glass';
    import '/_102055_/l2/molecules/groupshowprogress/ml-linear-progress-glass';
    import '/_102055_/l2/molecules/groupshowprogress/ml-circular-progress-glass';
    import '/_102055_/l2/molecules/grouprateitem/ml-star-rating-glass';
    import '/_102055_/l2/molecules/grouprateitem/ml-emoji-mood-scale-glass';
    export class GlassShowcase2DemoLoteG extends StateLitElement {
        private stars;
        private mood;
        render(): TemplateResult;
    }
}
declare module "_102053_/l2/glassshowcase2/demopilot" {
    import { TemplateResult } from 'lit';
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    import '/_102055_/l2/molecules/groupenterboolean/ml-toggle-switch-glass';
    import '/_102055_/l2/molecules/groupenterdate/ml-date-picker-glass';
    export class GlassShowcase2DemoPilot extends StateLitElement {
        private notif;
        private terms;
        private date;
        render(): TemplateResult;
    }
}
declare module "_102053_/l2/molecules/groupenterboolean/ml-toggle-switch.defs" {
    export const group = "groupEnterBoolean";
    export const layoutConfig: {
        boolean: string;
    };
    export const skill = "# Metadata\n- TagName: groupenterboolean--ml-toggle-switch\n\n# Objective\nA boolean input molecule that enables users to switch between two mutually exclusive states. It provides an interactive toggle during editing mode and displays the current selection as static text during read-only mode. It reports value changes, focus, and blur to the surrounding system, and presents labels, contextual guidance, and validation errors according to its current state.\n\n# Responsibilities\n- Present an interactive binary toggle when in editing mode\n- Display static text representing the current value when not in editing mode, showing \"Yes\" for true and \"No\" for false\n- Accept and display label content through the contract-defined label region\n- Accept and display helper content through the contract-defined helper region when no validation error is present and in editing mode\n- Display validation error messages when provided and in editing mode\n- Change the boolean value upon user activation when in editing mode\n- Report value changes to the system, including the new boolean state\n- Report when the control receives focus\n- Report when the control loses focus\n- Prevent user activation and suppress value change reports when disabled\n- Prevent all interaction and suppress reports when not in editing mode\n- Initialize with a default value of false when no prior value exists\n- Support keyboard activation to change the value when enabled and in editing mode\n- Communicate the current boolean state to accessibility tools\n- Communicate the disabled condition to accessibility tools when applicable\n- Communicate the invalid condition to accessibility tools when a validation error is present\n- Maintain programmatic associations between the control and its label, helper text, and error messages\n\n# Constraints\n- Must exclusively use the Label and Helper content regions defined in the contract\n- Must treat the value strictly as a boolean type without intermediate states\n- Must not permit value changes while disabled\n- Must not report value changes while disabled\n- Must not permit interaction or report focus, blur, or value changes when not in editing mode\n- Must suppress helper text display when a validation error message is present\n- Must not display helper text or error messages when not in editing mode\n- Must ensure value change reports are detectable outside the component\n- Must display \"Yes\" only when the value is true in read-only mode\n- Must display \"No\" only when the value is false in read-only mode\n\n# Notes\n- The control maintains a strict binary state; null or indeterminate values are not supported\n- Keyboard activation should follow conventional toggle interaction patterns";
}
declare module "_102053_/l2/molecules/groupentertext/ml-text-input-standard" {
    import { TemplateResult } from 'lit';
    import { MoleculeAuraElement } from "_102033_/l2/moleculeBase";
    export class MlTextInputStandardMolecule extends MoleculeAuraElement {
        slotTags: string[];
        value: string;
        error: string;
        name: string;
        placeholder: string;
        maxLength: number | null;
        minLength: number | null;
        rows: number;
        autocomplete: string;
        inputType: string;
        mask: string;
        isEditing: boolean;
        disabled: boolean;
        readonly: boolean;
        required: boolean;
        loading: boolean;
        private displayValue;
        private uid;
        handleIcaStateChange(key: string, value: any): void;
        updated(changedProps: Map<string, unknown>): void;
        private handleInput;
        private handleBlur;
        private handleFocus;
        render(): TemplateResult<1>;
        private renderLabel;
        private renderEditMode;
        private renderViewMode;
        private renderInputElement;
        private renderPrefix;
        private renderSuffix;
        private renderFeedback;
        private renderCounter;
        private renderSpinner;
        private updateDisplayValueFromProps;
        private isTextarea;
        private isDisabledOrLoading;
        private hasError;
        private getViewDisplayValue;
        private getFieldContainerClasses;
        private getInputClasses;
        private getLabelId;
        private getHelperId;
        private getErrorId;
        private getCounterId;
        private getDescribedBy;
        private isMaskToken;
        private isCharAllowed;
        private extractRawFromMasked;
        private applyMask;
    }
}
declare module "_102053_/l2/molecules/groupentertext/ml-enter-text-test" {
    import { TemplateResult } from 'lit';
    import { MoleculeAuraElement } from "_102033_/l2/moleculeBase";
    export class MlEnterTextTestMolecule extends MoleculeAuraElement {
        private msg;
        slotTags: string[];
        value: string;
        error: string;
        name: string;
        placeholder: string;
        maxLength: number | null;
        minLength: number | null;
        rows: number;
        autocomplete: string;
        inputType: string;
        mask: string;
        isEditing: boolean;
        disabled: boolean;
        readonly: boolean;
        required: boolean;
        loading: boolean;
        private rawDisplay;
        private uid;
        handleIcaStateChange(key: string, value: any): void;
        updated(changedProps: Map<string, unknown>): void;
        private handleInput;
        private handleTextareaInput;
        private handleChange;
        private handleFocus;
        private handleBlur;
        private getValueString;
        private getRowsValue;
        private getMaxLength;
        private getMinLength;
        private hasMask;
        private applyMaxLength;
        private isErrorState;
        private formatWithMask;
        private extractRaw;
        private getViewText;
        private getInputContainerClasses;
        private getViewContainerClasses;
        private getInputClasses;
        render(): TemplateResult<1>;
        private renderLabel;
        private renderPrefix;
        private renderSuffix;
        private renderInput;
        private renderTextarea;
        private renderFeedback;
        private renderCounter;
        private getDescribedBy;
    }
}
declare module "_102053_/l2/molecules/groupentertext/index" {
    import { TemplateResult } from 'lit';
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    import "_102053_/l2/molecules/groupentertext/ml-floating-text-input";
    import "_102053_/l2/molecules/groupentertext/ml-text-input-standard";
    import "_102053_/l2/molecules/groupentertext/ml-enter-text-test";
    export class GroupEnterTextIndex extends StateLitElement {
        private cardFloating;
        private cardStandard;
        private cardMasked;
        private renderHero;
        private renderShowcaseCards;
        private renderReferenceTable;
        protected render(): TemplateResult;
    }
}
declare module "_102053_/l2/molecules/groupentertext/ml-enter-text-test.defs" {
    export const group = "groupEnterText";
    export const skill = "# Metadata\n- TagName: groupentertext--ml-enter-text-test\n\n# Objective\nCapture general text input from users with support for minimum and maximum character limits. Provide clear visual feedback for validation errors and adapt its presentation across editing, viewing, disabled, readonly, and loading states.\n\n# Responsibilities\n- Accept text input from users within configurable minimum and maximum character boundaries\n- Prevent text entry beyond the defined maximum character limit\n- Indicate an error state when entered text is below the defined minimum character limit\n- Display a character counter in multi-line mode when a maximum limit is defined\n- Communicate the current text value whenever the user modifies the content\n- Communicate the text value when the user leaves the field\n- Signal when the field gains focus and when it loses focus\n- Render as a single-line field or a multi-line text region based on the configured row count\n- Display static content when in view mode instead of an editable input\n- Show placeholder text when the field is empty\n- Support insertion of label, helper text, prefix, and suffix content\n- Present distinct visual treatments for normal, error, disabled, readonly, and loading states\n- Mask sensitive content in view mode when configured for password input\n- Display a dash placeholder for empty values in view mode\n\n# Constraints\n- Must not allow the text value to exceed the configured maximum length during entry\n- Must enter an error state when text length is below the configured minimum and must display the associated error message\n- Must not display helper text, error messages, or input controls when in view mode\n- Must block user interaction when disabled or loading\n- Must display reduced opacity when disabled\n- Must display selectable text styling when readonly\n- Must render a single-line field when configured for one row, and a multi-line region when configured for multiple rows\n- Must show the character counter only in multi-line mode with a maximum length defined\n- Must display masked characters for password-type fields in view mode regardless of actual value\n- Must display a dash placeholder for empty values in view mode\n- Must apply error styling to borders and highlights when in an error state\n\n# Notes\n- Error state activation depends on the relationship between current text length and the configured minimum length";
}
declare module "_102053_/l2/molecules/groupentertext/ml-floating-text-input.defs" {
    export const group = "groupEnterText";
    export const layoutConfig: {
        labelPlacement: string;
    };
    export const skill = "# Metadata\n- TagName: groupentertext--ml-floating-text-input\n\n# Objective\nAllow the user to enter a single line of text through an input field that features a floating label \u2014 the label starts in the placeholder position and animates upward when the field is focused or has a value. The component supports optional input masking, prefix and suffix slots, character length limits, multiple input types, and disabled, readonly, error, loading, and view-only states.\n\n# Responsibilities\n- Display a floating label that animates to a smaller position above the input when the field is focused or has a value.\n- Accept and expose typed text as the component's value, dispatching an \"input\" event on each keystroke and a \"change\" event on blur.\n- Apply an optional input mask: insert literal separator characters automatically, strip non-matching characters, and store only the raw (unmasked) digits or letters as the value.\n- Enforce optional maximum and minimum character length limits on the raw value.\n- Support multiple input types (text, password, email, etc.) via the input-type property; never apply masking when the type is \"password\".\n- Render a read-only view mode (isEditing = false) that shows the label and value as plain text, displaying \"\u2022\u2022\u2022\u2022\u2022\u2022\u2022\u2022\" for password type and \"\u2014\" when the value is empty.\n- Show an inline error message styled in red when the error property is set.\n- Show a helper text below the field when a Helper slot is provided and there is no error.\n- Render optional prefix and suffix content inside the input container via named slots.\n- Show a spinning indicator inside the suffix area when the loading state is active.\n- Dispatch \"focus\" and \"blur\" custom events when the underlying input gains or loses focus.\n- Synchronize the displayed masked value when the bound value, mask, or input-type changes externally.\n\n# Constraints\n- Input, typing, focus, and all interaction must be blocked when disabled, readonly, loading, or isEditing is false.\n- Masking must never be applied to password-type inputs.\n- The raw (unmasked) value must be stored in the value property; masked characters are display-only.\n- The clear action and option list are not part of this component; it is a plain text input, not a select.\n- Error styling must persist until the error property is cleared externally.\n- The loading state must prevent interaction and display a spinner in place of or alongside the suffix slot.\n- Multiple simultaneous selections or multi-line input are not supported by this component.";
}
declare module "_102053_/l2/molecules/groupentertext/ml-text-input-standard.defs" {
    export const group = "groupEnterText";
    export const skill = "# Metadata\n- TagName: groupentertext--ml-text-input-standard\n# Objective\nPermitir que o usu\u00E1rio informe e visualize textos como nome, endere\u00E7o e outros dados textuais, com suporte a modos de edi\u00E7\u00E3o e visualiza\u00E7\u00E3o, m\u00E1scara, valida\u00E7\u00F5es e estados de feedback.\n# Responsibilities\n- Armazenar e emitir o valor como texto.\n- Renderizar um campo de linha \u00FAnica quando a quantidade de linhas for 1 e um campo multilinha quando for maior que 1.\n- Emitir evento de entrada a cada altera\u00E7\u00E3o durante a digita\u00E7\u00E3o com o valor atual.\n- Emitir evento de mudan\u00E7a ao perder o foco ou confirmar a entrada com o valor atual.\n- Emitir eventos de foco e perda de foco quando o campo receber ou perder foco.\n- Suportar modo de edi\u00E7\u00E3o com campo interativo e modo de visualiza\u00E7\u00E3o com texto est\u00E1tico.\n- Em modo de visualiza\u00E7\u00E3o, exibir \u201C\u2014\u201D quando o valor estiver vazio; para tipo senha, exibir \u201C\u2022\u2022\u2022\u2022\u2022\u2022\u2022\u2022\u201D; caso contr\u00E1rio, exibir o valor textual.\n- Respeitar estados desabilitado, somente leitura, obrigat\u00F3rio e carregando, bloqueando intera\u00E7\u00F5es quando aplic\u00E1vel e indicando carregamento.\n- Respeitar o limite m\u00E1ximo de caracteres e sinalizar erro quando o valor estiver abaixo do m\u00EDnimo.\n- Exibir contador de caracteres no formato \u201Catual / m\u00E1ximo\u201D quando houver limite m\u00E1ximo e m\u00FAltiplas linhas.\n- Aplicar m\u00E1scara de entrada quando fornecida, exibindo o valor formatado e armazenando apenas os caracteres brutos.\n- Exibir mensagem de erro quando houver conte\u00FAdo de erro e nunca exibir erro em modo de visualiza\u00E7\u00E3o.\n- Renderizar conte\u00FAdo opcional de r\u00F3tulo, ajuda, prefixo e sufixo nas posi\u00E7\u00F5es adequadas: r\u00F3tulo acima, ajuda/erro abaixo, prefixo antes do campo e sufixo depois do campo.\n- Propagar atributos de placeholder, autocomplete, tipo de entrada, nome, tamanho m\u00EDnimo e m\u00E1ximo conforme definidos para o componente.\n# Constraints\n- N\u00E3o permitir intera\u00E7\u00E3o quando estiver desabilitado, somente leitura ou carregando.\n- N\u00E3o permitir que o valor ultrapasse o limite m\u00E1ximo de caracteres.\n- Em modo de visualiza\u00E7\u00E3o, n\u00E3o exibir bordas, fundo, foco ou mensagem de erro.\n# Notes\n- O contador de caracteres \u00E9 exibido apenas quando h\u00E1 limite m\u00E1ximo e m\u00FAltiplas linhas.";
}
declare module "_102053_/l2/molecules/groupexpandcontent/ml-accordion.defs" {
    export const group = "groupExpandContent";
    export const layoutConfig: {
        expand: string;
    };
    export const skill = "# Metadata\n- TagName: groupexpandcontent--ml-accordion\n\n# Objective\nAllow the user to expand and collapse individually labeled content sections arranged vertically. The component can operate in single-expand mode (only one section open at a time) or multi-expand mode (any number of sections open simultaneously), and supports disabled, loading, and per-section disabled states with full keyboard navigation.\n\n# Responsibilities\n- Render each Section slot as a collapsible panel with a clickable header showing its title attribute.\n- Track which sections are open and toggle them when their header is clicked or activated via keyboard.\n- In single-expand mode, close any currently open section before opening a new one.\n- In multi-expand mode, allow any number of sections to be open simultaneously.\n- Initialize open sections from the expanded attribute present on Section elements at first render.\n- Dispatch a toggle custom event (bubbling, composed) with index, title, and expanded when a section is toggled.\n- Allow moving keyboard focus between section headers using ArrowDown and ArrowUp keys, skipping disabled headers.\n- Activate a focused header with Enter or Space.\n- Render an optional Label slot above the accordion panels.\n- Display a loading skeleton with an animated pulse when the loading property is true.\n- Show an empty-state message when no Section slots are provided.\n- Apply disabled styling and block interaction on individual sections that carry the disabled attribute.\n- Block all interaction when the component-level disabled or loading property is true.\n- Support light and dark color schemes through conditional class application.\n\n# Constraints\n- A section must not open or close while the component-level disabled or loading state is active.\n- A per-section disabled header must receive tabindex=\"-1\" and must not be reachable or togglable.\n- In single-expand mode, at most one section may be open at any time.\n- Keyboard navigation must skip disabled headers and wrap around the list.\n- The component must not contain business logic; it only manages visual expand/collapse state.\n- Section content is rendered via unsafeHTML from the Section slot's inner template or innerHTML and must not be sanitized by this component.";
}
declare module "_102053_/l2/molecules/groupselectmany/ml-multi-select-dropdown-test-two" {
    import { TemplateResult } from 'lit';
    import { MoleculeAuraElement } from "_102033_/l2/moleculeBase";
    export class MlMultiSelectDropdownTestTwoMolecule extends MoleculeAuraElement {
        private msg;
        private uid;
        slotTags: string[];
        value: string;
        error: string;
        name: string;
        placeholder: string;
        searchable: boolean;
        minSelection: number;
        maxSelection: number;
        isEditing: boolean;
        disabled: boolean;
        readonly: boolean;
        required: boolean;
        loading: boolean;
        private isOpen;
        private searchQuery;
        private activeIndex;
        portalContainer: HTMLDivElement | null;
        portalWidgetName: string;
        private boundUpdatePosition;
        private boundDocumentClick;
        private boundDocumentKeydown;
        private boundFocusOut;
        connectedCallback(): void;
        disconnectedCallback(): void;
        updated(changedProps: Map<string, unknown>): void;
        private handleTriggerClick;
        private handleTriggerKeyDown;
        private handleSearchInput;
        private handleItemToggle;
        private handleTriggerFocus;
        private handleFocusOut;
        private handlePanelKeyDown;
        private handleDocumentClick;
        private handleDocumentKeydown;
        private createPortal;
        private destroyPortal;
        private updatePanelPosition;
        private renderPortalContent;
        private openPanel;
        private closePanel;
        private toggleOpen;
        private getPortalTemplate;
        render(): TemplateResult;
        private renderTriggerContent;
        private renderSearchInput;
        private renderGroup;
        private renderItem;
        private renderEmptyState;
        private renderViewMode;
        private getSelectedSet;
        private getFlatItems;
        private getGroupedItems;
        private getGroupedItemsFiltered;
        private getFlatItemsFiltered;
        private parseItemElement;
        private getPlainText;
        private getErrorText;
        private updateActiveIndexForItems;
        private moveActive;
        private focusActiveItem;
        private focusTrigger;
        private getTriggerClasses;
        private getPanelClasses;
        private getItemClasses;
        private getItemMarkerClasses;
        private getItemLabelClasses;
        private getGroupLabelClasses;
        private getSearchWrapperClasses;
        private getSearchInputClasses;
        private getEmptyClasses;
        private getLoadingClasses;
        private getViewContainerClasses;
        private getViewTagClasses;
    }
}
declare module "_102053_/l2/molecules/groupselectmany/index" {
    import { TemplateResult } from 'lit';
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    import '/_102053_/l2/molecules/groupselectmany/ml-multi-select-dropdown-test';
    import "_102053_/l2/molecules/groupselectmany/ml-multi-select-dropdown-test-two";
    export class GroupSelectManyIndex extends StateLitElement {
        private cardOne;
        private cardTwo;
        private renderHero;
        private renderShowcaseCards;
        private renderReferenceTable;
        protected render(): TemplateResult;
    }
}
declare module "_102053_/l2/molecules/groupselectmany/ml-multi-select-dropdown-test-two.defs" {
    export const group = "groupSelectMany";
    export const skill = "# Metadata\n- TagName: groupselectmany--ml-multi-select-dropdown-test-two\n\n# Objective\nA multi-selection dropdown that allows the user to choose one or more options from a list. It supports minimum and maximum selection limits, optional search filtering, and can operate in either an interactive or a read-only display mode.\n\n# Responsibilities\n- Allow the user to select multiple options simultaneously from a provided list, producing a comma-separated text value representing the current choices.\n- Enforce a configurable minimum number of selections that must be made.\n- Enforce a configurable maximum number of selections, preventing any additional selection once the limit is reached.\n- Display a visual error state when the count of selected items is below the required minimum or when an external error state is indicated.\n- Keep the selection panel open after each selection or deselection to allow consecutive choices without requiring the panel to be reopened.\n- Render the selection panel outside the component boundaries so it is not clipped by ancestor containers.\n- Toggle the panel open and closed when the user activates the trigger; close the panel when the user presses Escape or clicks outside the component and its layer.\n- Present disabled options in the list without allowing them to be selected.\n- Visually deactivate and block selection of all unselected options when the maximum selection limit is reached; restore them only after a selected item is removed.\n- Provide an optional search field at the top of the selection panel that filters the list by visible option text.\n- Support an editable mode that enables full interaction, and a view mode that presents selected values as static text or tags without an interactive panel.\n- Signal when the selection changes, communicating the updated comma-separated value.\n- Signal when the field gains focus and when it loses focus.\n- Honor disabled, read-only, and loading states by removing interactivity and preventing the panel from opening.\n- Accommodate a label, helper text, and an empty state message when no options are available.\n\n# Constraints\n- The trigger must display placeholder text when no option is selected, and must show the quantity or representation of selected items when one or more are chosen.\n- The selection panel must be positioned directly below the trigger, match the trigger width, align to the left, and appear visually above all other page elements.\n- Every option inside the panel must present a clear visual marker indicating whether it is currently selected.\n- The error state must highlight the field border with the group's error color and display an error message beneath the field using the group's error text style.\n- The disabled state must reduce the component opacity and use a non-interactive cursor on the trigger.\n- The loading state must replace the content with a loading indicator and block the panel from opening.\n- When the maximum selection limit is active, unselected options must appear inactive and must not respond to hover or activation.\n- The search field, when visible, must occupy the full width at the top of the panel and follow the group's standard input appearance.\n- In view mode, only the selected values may be rendered as text or tags; the trigger, panel, helper text, and error messages must remain hidden.\n- All visual presentation must rely on the group's semantic style classes and design tokens for color, border, shadow, and typography. Layout and positioning must be defined separately from these semantic styles.\n\n# Notes\n- The comma-separated value format is used consistently for representing the set of selected options.";
}
declare module "_102053_/l2/molecules/groupselectone/ml-select-one-test" {
    import { TemplateResult } from 'lit';
    import { MoleculeAuraElement } from "_102033_/l2/moleculeBase";
    export class MlSelectOneTestMolecule extends MoleculeAuraElement {
        private msg;
        slotTags: string[];
        value: string | null;
        error: string;
        name: string;
        variant: string;
        placeholder: string;
        searchable: boolean;
        isEditing: boolean;
        disabled: boolean;
        readonly: boolean;
        required: boolean;
        loading: boolean;
        private isOpen;
        private searchQuery;
        private isFocused;
        private uid;
        protected portalContainer: HTMLDivElement | null;
        protected portalWidgetName: string;
        private boundOutsideClick;
        private boundUpdatePosition;
        connectedCallback(): void;
        disconnectedCallback(): void;
        updated(changedProps: Map<string, unknown>): void;
        private createPortal;
        private destroyPortal;
        private updatePanelPosition;
        private renderPortalContent;
        private handleFocusIn;
        private handleFocusOut;
        private handleTriggerClick;
        private handleTriggerKeyDown;
        private handlePanelKeyDown;
        private handleInlineKeyDown;
        private handleItemSelect;
        private handleRowSelect;
        private handleSearchInput;
        private handleRadioChange;
        private openPanel;
        private closePanel;
        private parseItems;
        private getFilteredItems;
        private getGroupedItems;
        private getSelectedItem;
        private stripHtml;
        private selectNextItem;
        private selectCurrentItem;
        private getTriggerClasses;
        private getOptionClasses;
        private getInlineItemClasses;
        private getContainerClasses;
        private renderLabel;
        private renderHelperOrError;
        private renderEmpty;
        private renderTriggerContent;
        private renderSearchInput;
        private renderDropdownPanel;
        private renderGroup;
        private renderOption;
        private renderInlineOptions;
        private renderInlineItem;
        private renderTable;
        private renderTableRow;
        private renderViewMode;
        protected getPortalTemplate(): TemplateResult;
        render(): TemplateResult<1>;
    }
}
declare module "_102053_/l2/molecules/groupselectone/index" {
    import { TemplateResult } from 'lit';
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    import "_102053_/l2/molecules/groupselectone/ml-select-one-test";
    export class GroupSelectOneIndex extends StateLitElement {
        private cardDropdown;
        private cardRadio;
        private cardSegmented;
        private cardList;
        private cardTable;
        private renderHero;
        private renderShowcaseCards;
        private renderReferenceTable;
        render(): TemplateResult;
    }
}
declare module "_102053_/l2/molecules/groupselectone/ml-select-one-test.defs" {
    export const group = "groupSelectOne";
    export const skill = "# Metadata\n- TagName: groupselectone--ml-select-one-test\n\n# Objective\nAllow a user to choose exactly one option from a defined set, using different presentation styles suitable for various contexts such as plan selection or state selection.\n\n# Responsibilities\n- Present multiple options and allow only one to be chosen at a time.\n- Remember the currently chosen option and indicate clearly when nothing is chosen.\n- Support different presentation styles including dropdown, radio group, segmented control, list, and table.\n- In dropdown style, reveal options when activated and conceal them when the user selects an option, clicks outside the selection area, or presses the Escape key.\n- Allow narrowing down visible options through text input when search is enabled.\n- Display unavailable options in a way that prevents their selection.\n- Signal when the user moves focus into or out of the selection area.\n- Signal when the chosen option changes.\n- Provide an interactive interface when editable, and display only the chosen option label or an empty indicator when not editable.\n- Indicate an invalid state when a selection is required but none is made.\n\n# Constraints\n- Only one option can be selected simultaneously.\n- Unavailable options must not respond to selection attempts.\n- When inactive or locked, all interaction is blocked, options cannot be revealed, and the selection cannot change.\n- Search filtering must only hide non-matching options without altering the underlying choices.\n- The non-editable presentation must not allow changing the selected option.\n- An empty state must appear when no options exist or when filtering returns no results.\n\n# Notes\n- Distinct behavioral states must be maintained for normal, selected, unavailable, locked, and invalid conditions.";
}
declare module "_102053_/l2/molecules/grouptriggeraction/ml-button-standard.defs" {
    export const group = "groupTriggerAction";
    export const layoutConfig: {
        actionStyle: string;
    };
    export const skill = "# Metadata\n- TagName: grouptriggeraction--ml-button-standard\n\n# Objective\nA standard button molecule for the groupTriggerAction group that triggers actions when activated. It supports text labels, icons, multiple sizes, visual styles, loading states with a spinner indicator, and disabled states. Designed for corporate interfaces such as ERP, CRM, HR, Financial, and Logistics systems.\n\n# Responsibilities\n- Display a text label and/or an icon provided through the designated Label and Icon content areas.\n- Arrange the icon either before or after the text label based on configuration.\n- Adjust overall dimensions and icon scale according to the selected size.\n- Behave as a standard button, a submit button, or a reset button based on configuration.\n- Ignore activation attempts and present a disabled state when configured as disabled.\n- Ignore activation attempts and present a busy state when configured as loading.\n- Show a loading spinner in place of the icon or text during loading, keeping the button size unchanged.\n- Trigger an action event when activated by pointer or keyboard (Enter or Space), unless disabled or loading.\n- Expose an accessible name for icon-only buttons using the Label content when available.\n- Support rich content within the Label and Icon areas.\n- Provide distinct visual feedback for Normal, Hover, Active, and Focused states, with a visible focus indicator for keyboard users.\n- Reduce opacity and remove interactive feedback when disabled.\n- Support visual variations for primary, secondary, danger, ghost, and link styles through theming.\n- Adapt colors for dark mode using semantic color definitions.\n\n# Constraints\n- Must compose content using only the Label and Icon areas.\n- Icon position must be either 'start' or 'end'.\n- Size must be one of 'xs', 'sm', 'md', or 'lg'.\n- Type must be one of 'button', 'submit', or 'reset'.\n- When disabled, the action event must not trigger.\n- When loading, the action event must not trigger, and the button must expose busy and disabled states for accessibility.\n- During loading, the spinner replaces the icon if present; otherwise, it replaces the text label.\n- The action event must contain no detail and must propagate normally.\n- For icon-only buttons, the accessible name must come from the Label content if provided; otherwise, it must be empty.\n- Visual style variations must not require additional configuration properties.\n- Dark mode colors must map to semantic tokens for background, text, border, and focus ring.\n\n# Notes\n- Designed for corporate contexts such as ERP forms, CRM proposals, HR approvals, financial payments, and logistics operations.\n- The button must preserve its dimensions during loading to prevent layout shifts.\n- Visual design aligns with Material UI, Ant Design, and Atlassian Design System button patterns.";
}
declare module "_102053_/l2/testes/account-settings" {
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    import '/_102040_/l2/molecules/groupnavigatesection/ml-tabs';
    import '/_102040_/l2/molecules/groupentertext/ml-floating-text-input';
    import '/_102040_/l2/molecules/groupentertext/ml-multiline-text';
    import '/_102040_/l2/molecules/groupentertext/ml-cpf-input';
    import '/_102040_/l2/molecules/groupentermoney/ml-enter-money-br';
    import '/_102040_/l2/molecules/groupenterdate/ml-date-picker';
    import '/_102040_/l2/molecules/groupselectone/ml-select-dropdown';
    import '/_102040_/l2/molecules/groupselectone/ml-segmented-control';
    import '/_102040_/l2/molecules/groupenterboolean/ml-toggle-switch';
    import '/_102040_/l2/molecules/groupenterboolean/ml-checkbox-preference';
    import '/_102040_/l2/molecules/groupnotifyuser/ml-toast-notification';
    export class AccountSettings extends StateLitElement {
        activeTab: string;
        viewEpoch: number;
        toastVisible: boolean;
        toastMsg: string;
        isEditingPerfil: boolean;
        isEditingSeguranca: boolean;
        isEditingCobranca: boolean;
        errors: Record<string, string>;
        name: string;
        email: string;
        phone: string;
        birthDate: string;
        bio: string;
        recoveryEmail: string;
        twoFaEnabled: boolean;
        pushNotif: boolean;
        cpf: string;
        spendingLimit: number;
        spendingAlert: number;
        autoPayment: boolean;
        termsAccepted: boolean;
        language: string;
        timezone: string;
        theme: string;
        private snapshotPerfil;
        private snapshotSeguranca;
        private snapshotCobranca;
        private editPerfil;
        private cancelPerfil;
        private savePerfil;
        private editSeguranca;
        private cancelSeguranca;
        private saveSeguranca;
        private editCobranca;
        private cancelCobranca;
        private saveCobranca;
        private handleRequestEdit;
        private get languageLabel();
        private get timezoneLabel();
        private get themeLabel();
        private formatMoney;
        private formatCpf;
        private err;
        private badge;
        private editHeader;
        private renderPerfilView;
        private renderSegurancaView;
        private renderCobrancaView;
        private renderPreferenciasView;
        private renderPerfilEditForm;
        private renderSegurancaEditForm;
        private renderCobrancaEditForm;
        private renderPreferenciasControls;
        private renderActivePanel;
        private renderTabs;
        render(): import("lit").TemplateResult<1>;
    }
}
declare module "_102053_/l2/testes/appointment-scheduler" {
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    import '/_102040_/l2/molecules/groupnavigatesection/ml-tabs';
    import '/_102040_/l2/molecules/groupentertext/ml-floating-text-input';
    import '/_102040_/l2/molecules/groupentertext/ml-multiline-text';
    import '/_102040_/l2/molecules/groupenterdatetime/ml-datetime-picker';
    import '/_102040_/l2/molecules/groupenterdatetimeinterval/ml-enter-datetime-interval';
    import '/_102040_/l2/molecules/groupentertimeinterval/ml-time-interval-selector';
    import '/_102040_/l2/molecules/groupselectone/ml-select-one-autocomplete';
    import '/_102040_/l2/molecules/groupselectmany/ml-multi-select-dropdown';
    import '/_102040_/l2/molecules/groupselectone/ml-radio-group';
    import '/_102040_/l2/molecules/groupenternumber/ml-number-input';
    import '/_102040_/l2/molecules/groupnotifyuser/ml-toast-notification';
    import '/_102040_/l2/molecules/groupviewtable/ml-data-table-minimal';
    interface Meeting {
        id: number;
        title: string;
        date: string;
        room: string;
        participants: number;
    }
    export class AppointmentScheduler extends StateLitElement {
        activeTab: string;
        viewEpoch: number;
        toastVisible: boolean;
        toastMsg: string;
        title: string;
        agenda: string;
        startAt: string;
        intervalStart: string;
        intervalEnd: string;
        preferredStart: string;
        preferredEnd: string;
        participants: string[];
        selectedRooms: string[];
        recurrence: string;
        recurrenceCount: number;
        errors: Record<string, string>;
        upcomingMeetings: Meeting[];
        private readonly availableRooms;
        private readonly allParticipants;
        private validate;
        private err;
        private handleAgendar;
        private handleParticipantSelect;
        private removeParticipant;
        private renderTabs;
        private renderNovaReuniaoForm;
        private renderMinhasReunioes;
        render(): import("lit").TemplateResult<1>;
    }
}
declare module "_102053_/l2/testes/budget-editor" {
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    import '/_102040_/l2/molecules/groupviewtable/ml-data-table';
    import '/_102040_/l2/molecules/groupentermoney/ml-enter-money-br';
    import '/_102040_/l2/molecules/groupentertext/ml-floating-text-input';
    import '/_102040_/l2/molecules/groupselectone/ml-select-dropdown';
    import '/_102040_/l2/molecules/groupenternumber/ml-number-input';
    import '/_102040_/l2/molecules/groupselectone/ml-segmented-control';
    import '/_102040_/l2/molecules/groupnotifyuser/ml-notify-banner';
    import '/_102040_/l2/molecules/groupnotifyuser/ml-toast-notification';
    interface BudgetRow {
        id: number;
        description: string;
        costCenter: string;
        qty: number;
        planned: number;
        actual: number;
    }
    export class BudgetEditor extends StateLitElement {
        rows: BudgetRow[];
        activeFilter: 'all' | 'over' | 'within';
        editingRowId: number | null;
        tableEpoch: number;
        bannerDismissed: boolean;
        toastVisible: boolean;
        editDescription: string;
        editCostCenter: string;
        editQty: number;
        editPlanned: number;
        editActual: number;
        errors: Record<string, string>;
        private editSnapshot;
        private get filteredRows();
        private get overBudgetRows();
        private get editingRow();
        private fmt;
        private err;
        private handleRowClick;
        private openEdit;
        private cancelEdit;
        private saveEdit;
        private renderTable;
        private renderEditPanel;
        render(): import("lit").TemplateResult<1>;
    }
}
declare module "_102053_/l2/testes/candidate-pipeline" {
    import { TemplateResult } from 'lit';
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    import '/_102040_/l2/molecules/groupnavigatesection/ml-navigate-pills';
    import '/_102040_/l2/molecules/groupviewcard/ml-view-card-horizontal';
    import '/_102040_/l2/molecules/grouprateitem/ml-star-rating';
    import '/_102040_/l2/molecules/grouprateitem/ml-thumbs-rating';
    import '/_102040_/l2/molecules/groupselectfileforupload/ml-file-upload-dropzone';
    import '/_102040_/l2/molecules/groupselectfileforupload/ml-user-photo-upload';
    import '/_102040_/l2/molecules/groupviewdata/ml-vertical-record-list';
    import '/_102040_/l2/molecules/groupexpandcontent/ml-readmore-expand';
    import '/_102040_/l2/molecules/groupenterdate/ml-compact-calendar';
    import '/_102040_/l2/molecules/grouptriggeraction/ml-button-standard';
    import '/_102040_/l2/molecules/grouptriggeraction/ml-icon-button';
    import '/_102040_/l2/molecules/groupsearchcontent/ml-search-bar';
    import '/_102040_/l2/molecules/groupnotifyuser/ml-toast-notification';
    type Stage = 'triagem' | 'interview' | 'technical' | 'proposal' | 'hired';
    interface HistoryEntry {
        date: string;
        type: string;
        description: string;
    }
    interface Candidate {
        id: number;
        name: string;
        role: string;
        stage: Stage;
        rating: number;
        thumb: 'up' | 'down' | null;
        cvFile: string | null;
        interviewDate: string;
        history: HistoryEntry[];
    }
    export class CandidatePipeline extends StateLitElement {
        activeStage: Stage;
        searchQuery: string;
        selectedId: number;
        toastVisible: boolean;
        toastMessage: string;
        candidates: Candidate[];
        private readonly job;
        private readonly stageOrder;
        private readonly stageLabels;
        private readonly nextStageLabel;
        private get selectedCandidate();
        private get filteredCandidates();
        private countByStage;
        private initials;
        private selectFirstInStage;
        private autoSelectAfterMutation;
        private advanceCandidate;
        private rejectCandidate;
        private updateCandidate;
        private showToast;
        render(): TemplateResult<1>;
        private renderCandidateCard;
        private renderEmptyPanel;
        private renderDetailPanel;
    }
}
declare module "_102053_/l2/testes/corporate-dashboard" {
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    import '/_102040_/l2/molecules/groupviewmetric/ml-metric-big-number';
    import '/_102040_/l2/molecules/groupviewmetric/ml-metric-gauge';
    import '/_102040_/l2/molecules/groupviewchart/ml-area-chart';
    import '/_102040_/l2/molecules/groupviewchart/ml-bar-chart';
    import '/_102040_/l2/molecules/groupviewtable/ml-data-table-minimal';
    import '/_102040_/l2/molecules/groupnotifyuser/ml-notify-banner';
    import '/_102040_/l2/molecules/groupselectone/ml-segmented-control';
    export class CorporateDashboard extends StateLitElement {
        period: string;
        bannerVisible: boolean;
        private readonly kpiData;
        private readonly transactions;
        private get kpis();
        private statusBadge;
        render(): import("lit").TemplateResult<1>;
    }
}
declare module "_102053_/l2/testes/customer-profile" {
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    import '/_102040_/l2/molecules/groupentertext/ml-floating-text-input';
    import '/_102040_/l2/molecules/groupentertext/ml-cpf-input';
    import '/_102040_/l2/molecules/groupentertext/ml-multiline-text';
    import '/_102040_/l2/molecules/groupenterdate/ml-date-picker';
    import '/_102040_/l2/molecules/groupselectone/ml-select-dropdown';
    import '/_102040_/l2/molecules/groupselectone/ml-select-one-autocomplete';
    import '/_102040_/l2/molecules/groupselectmany/ml-multi-checkbox-list';
    import '/_102040_/l2/molecules/groupenterboolean/ml-checkbox-preference';
    import '/_102040_/l2/molecules/groupnotifyuser/ml-toast-notification';
    export class CustomerProfile extends StateLitElement {
        isEditing: boolean;
        toastVisible: boolean;
        errors: Record<string, string>;
        clientName: string;
        personType: string;
        cnpj: string;
        cpf: string;
        email: string;
        phone: string;
        segment: string;
        city: string;
        stateUF: string;
        registerDate: string;
        birthday: string;
        channels: string;
        acceptsOffers: boolean;
        acceptsWpp: boolean;
        notes: string;
        private snapshot;
        private takeSnapshot;
        private restoreSnapshot;
        private edit;
        private cancel;
        private validate;
        private save;
        private err;
        private get segmentLabel();
        private get initials();
        private get personTypeLabel();
        render(): import("lit").TemplateResult<1>;
    }
}
declare module "_102053_/l2/testes/edicao-cliente" {
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    import '/_102040_/l2/molecules/groupentertext/ml-floating-text-input';
    import '/_102040_/l2/molecules/groupselectone/ml-combobox';
    import '/_102040_/l2/molecules/groupselectone/ml-segmented-control';
    import '/_102040_/l2/molecules/groupnotifyuser/ml-notify-banner';
    export class EdicaoClientePage extends StateLitElement {
        private nome;
        private endereco;
        private situacao;
        private pesquisa;
        private clienteAtual;
        private errors;
        private saved;
        connectedCallback(): void;
        private getClientes;
        private err;
        private handleSelect;
        private handleSave;
        private handleCancel;
        private clearForm;
        render(): import("lit").TemplateResult<1>;
        private renderForm;
        private renderSectionHeader;
    }
}
declare module "_102053_/l2/testes/employee-profile" {
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    import '/_102040_/l2/molecules/groupentertext/ml-floating-text-input';
    import '/_102040_/l2/molecules/groupentertext/ml-cpf-input';
    import '/_102040_/l2/molecules/groupentertext/ml-multiline-text';
    import '/_102040_/l2/molecules/groupenterdate/ml-date-picker';
    import '/_102040_/l2/molecules/groupselectone/ml-select-dropdown';
    import '/_102040_/l2/molecules/groupselectone/ml-radio-group';
    import '/_102040_/l2/molecules/groupentermoney/ml-enter-money-br';
    import '/_102040_/l2/molecules/groupenterboolean/ml-toggle-switch';
    import '/_102040_/l2/molecules/groupnotifyuser/ml-toast-notification';
    export class EmployeeProfile extends StateLitElement {
        isEditing: boolean;
        toastVisible: boolean;
        errors: Record<string, string>;
        name: string;
        cpf: string;
        email: string;
        phone: string;
        birthDate: string;
        admissionDate: string;
        department: string;
        role: string;
        workRegime: string;
        salary: number | null;
        systemAccess: boolean;
        isAdmin: boolean;
        notes: string;
        private snapshot;
        private takeSnapshot;
        private restoreSnapshot;
        private edit;
        private cancel;
        private validate;
        private save;
        private err;
        private get departmentLabel();
        private get roleLabel();
        private get initials();
        render(): import("lit").TemplateResult<1>;
    }
}
declare module "_102053_/l2/testes/employee-registration" {
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    import '/_102040_/l2/molecules/groupnavigatesteps/ml-horizontal-stepper';
    import '/_102040_/l2/molecules/groupentertext/ml-floating-text-input';
    import '/_102040_/l2/molecules/groupentertext/ml-cpf-input';
    import '/_102040_/l2/molecules/groupenterdate/ml-date-picker';
    import '/_102040_/l2/molecules/groupselectone/ml-select-dropdown';
    import '/_102040_/l2/molecules/groupselectone/ml-radio-group';
    import '/_102040_/l2/molecules/groupentermoney/ml-enter-money-br';
    import '/_102040_/l2/molecules/groupenterboolean/ml-toggle-switch';
    import '/_102040_/l2/molecules/groupenterboolean/ml-checkbox-preference';
    import '/_102040_/l2/molecules/groupselectmany/ml-multi-checkbox-list';
    import '/_102040_/l2/molecules/groupnotifyuser/ml-toast-notification';
    export class EmployeeRegistration extends StateLitElement {
        currentStep: number;
        toastVisible: boolean;
        errors: Record<string, string>;
        name: string;
        cpf: string;
        email: string;
        phone: string;
        birthDate: string;
        department: string;
        role: string;
        workRegime: string;
        admissionDate: string;
        salary: number | null;
        systemAccess: boolean;
        isAdmin: boolean;
        modules: string;
        privacyAccepted: boolean;
        private readonly steps;
        private validate;
        private next;
        private back;
        private err;
        render(): import("lit").TemplateResult<1>;
        private renderStep0;
        private renderStep1;
        private renderStep2;
    }
}
declare module "_102053_/l2/testes/escolha-orcamento" {
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    import '/_102040_/l2/molecules/groupnavigatesteps/ml-wizard-steps';
    import '/_102040_/l2/molecules/groupviewtable/ml-data-table-select';
    import '/_102040_/l2/molecules/groupviewmetric/ml-metric-card';
    import '/_102040_/l2/molecules/groupenterboolean/ml-toggle-switch';
    import '/_102040_/l2/molecules/groupentertext/ml-multiline-text';
    import '/_102040_/l2/molecules/groupnotifyuser/ml-notify-banner';
    export class EscolhaOrcamentoPage extends StateLitElement {
        private step;
        private steps;
        private orcamentoSelecionado;
        private orcamentoIdx;
        private tarefas;
        private bloquearVeiculo;
        private justificativa;
        private justificativaError;
        private osGerada;
        private getMenorValor;
        private brl;
        private stars;
        private tarefaLabel;
        private completeStep;
        private handleWizardChange;
        private handleTableChange;
        private handleNext;
        private handleBack;
        private handleGerarOS;
        render(): import("lit").TemplateResult<1>;
        private renderNav;
        private renderStep0;
        private renderStep1;
        private compRow;
        private handleVistoriaChange;
        private renderStep2;
        private renderStep3;
        private renderStep4;
    }
}
declare module "_102053_/l2/testes/field-service-order" {
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    import '/_102040_/l2/molecules/groupnavigatesteps/ml-vertical-stepper';
    import '/_102040_/l2/molecules/groupscancode/ml-scan-code-1d';
    import '/_102040_/l2/molecules/groupscancode/ml-scan-code';
    import '/_102040_/l2/molecules/grouplocateposition/ml-locate-map-picker';
    import '/_102040_/l2/molecules/grouplocateposition/ml-geolocation-trigger';
    import '/_102040_/l2/molecules/groupshowprogress/ml-linear-progress';
    import '/_102040_/l2/molecules/groupshowprogress/ml-indeterminate-spinner';
    import '/_102040_/l2/molecules/groupentertime/ml-clock-time-picker';
    import '/_102040_/l2/molecules/groupentertime/ml-time-scroll-picker';
    import '/_102040_/l2/molecules/groupviewdata/ml-timeline-view';
    import '/_102040_/l2/molecules/groupexpandcontent/ml-single-expand-content';
    import '/_102040_/l2/molecules/grouptriggeraction/ml-button-standard';
    import '/_102040_/l2/molecules/grouptriggeraction/ml-icon-button';
    import '/_102040_/l2/molecules/groupentertext/ml-multiline-text';
    import '/_102040_/l2/molecules/groupenterboolean/ml-checkbox-preference';
    import '/_102040_/l2/molecules/groupnotifyuser/ml-toast-notification';
    interface ChecklistItem {
        id: number;
        label: string;
        done: boolean;
    }
    export class FieldServiceOrder extends StateLitElement {
        currentStep: number;
        scannedBarcode: string;
        scannedQr: string;
        locationCoords: string;
        arrivalTime: string;
        preferredWindowStart: string;
        preferredWindowEnd: string;
        report: string;
        loadingHistory: boolean;
        historyLoaded: boolean;
        toastVisible: boolean;
        toastMessage: string;
        checklist: ChecklistItem[];
        private readonly order;
        private readonly serviceHistory;
        private get doneCount();
        private get allDone();
        private get checklistProgress();
        private toggleItem;
        private showToast;
        private loadHistory;
        private nextStep;
        render(): import("lit").TemplateResult<1>;
    }
}
declare module "_102053_/l2/testes/financial-report" {
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    import '/_102040_/l2/molecules/groupenterdateinterval/ml-date-range-dual-calendar';
    import '/_102040_/l2/molecules/groupselectone/ml-select-dropdown';
    import '/_102040_/l2/molecules/groupselectone/ml-segmented-control';
    import '/_102040_/l2/molecules/groupviewmetric/ml-metric-big-number';
    import '/_102040_/l2/molecules/groupviewchart/ml-area-chart';
    import '/_102040_/l2/molecules/groupviewchart/ml-pie-chart';
    import '/_102040_/l2/molecules/groupviewtable/ml-view-table';
    import '/_102040_/l2/molecules/groupnavigatesection/ml-tabs';
    export class FinancialReport extends StateLitElement {
        startDate: string;
        endDate: string;
        granularity: string;
        activeView: 'revenue' | 'expense' | 'margin';
        activeTab: string;
        private readonly summary;
        private kpiRing;
        render(): import("lit").TemplateResult<1>;
    }
}
declare module "_102053_/l2/testes/ml-radio-group-exemple" {
    import { TemplateResult } from 'lit';
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    import '/_102040_/l2/molecules/groupselectone/ml-radio-group';
    interface Config {
        value: string;
        isEditing: boolean;
        required: boolean;
        disabled: boolean;
        readonly: boolean;
        loading: boolean;
        error: string;
    }
    export class MlRadioGroupExemple extends StateLitElement {
        basic: Config;
        grouped: Config;
        private toggle;
        private renderToggle;
        private renderConfig;
        render(): TemplateResult<1>;
    }
}
declare module "_102053_/l2/testes/order-management" {
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    import '/_102040_/l2/molecules/groupsearchcontent/ml-search-bar';
    import '/_102040_/l2/molecules/groupenterdateinterval/ml-date-range-dual-calendar';
    import '/_102040_/l2/molecules/groupselectmany/ml-multi-select-dropdown';
    import '/_102040_/l2/molecules/groupselectone/ml-select-dropdown';
    import '/_102040_/l2/molecules/groupviewtable/ml-data-table';
    import '/_102040_/l2/molecules/groupnotifyuser/ml-notify-banner';
    import '/_102040_/l2/molecules/groupviewchart/ml-line-chart';
    import '/_102040_/l2/molecules/groupnavigatesection/ml-tabs';
    export class OrderManagement extends StateLitElement {
        activeTab: string;
        search: string;
        statusFilter: string;
        sortBy: string;
        filterStartDate: string;
        filterEndDate: string;
        page: number;
        bannerVisible: boolean;
        private readonly pageSize;
        private readonly allOrders;
        private readonly volumePoints;
        private get filteredOrders();
        private get visibleOrders();
        private toStatusKey;
        private countByTab;
        private statusBadge;
        private lateInTransit;
        render(): import("lit").TemplateResult<1>;
    }
}
declare module "_102053_/l2/testes/org-chart" {
    import { TemplateResult } from 'lit';
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    import '/_102040_/l2/molecules/groupnavigatemain/ml-sidebar-nav';
    import '/_102040_/l2/molecules/groupnavigatesection/ml-breadcrumb-trail';
    import '/_102040_/l2/molecules/groupnavigatesection/ml-navigate-pills';
    import '/_102040_/l2/molecules/groupviewhierarchy/ml-hierarchy-orgchart';
    import '/_102040_/l2/molecules/groupviewhierarchy/ml-hierarchy-tree';
    import '/_102040_/l2/molecules/groupviewhierarchy/ml-hierarchy-tree-diagram';
    import '/_102040_/l2/molecules/groupviewcard/ml-vertical-card';
    import '/_102040_/l2/molecules/groupsearchcontent/ml-search-bar';
    import '/_102040_/l2/molecules/groupselectone/ml-segmented-control';
    import '/_102040_/l2/molecules/groupshowprogress/ml-circular-progress';
    import '/_102040_/l2/molecules/grouptriggeraction/ml-icon-button';
    import '/_102040_/l2/molecules/groupnotifyuser/ml-toast-notification';
    type ViewMode = 'orgchart' | 'tree' | 'diagram';
    type LevelFilter = 'all' | 'exec' | 'manager' | 'operational';
    interface Employee {
        name: string;
        role: string;
        level: LevelFilter;
        dept: string;
        email: string;
    }
    export class OrgChart extends StateLitElement {
        activeDept: string;
        activeView: ViewMode;
        levelFilter: LevelFilter;
        searchQuery: string;
        selectedEmployee: Employee | null;
        loadingChart: boolean;
        loadingProgress: number;
        toastVisible: boolean;
        toastMessage: string;
        private readonly navItems;
        private readonly allEmployees;
        private get currentDeptLabel();
        private get employees();
        private initials;
        private levelLabel;
        private matchesSearch;
        private matchesLevel;
        private switchDept;
        private showToast;
        private handleNodeClick;
        private renderHierarchyNodes;
        render(): TemplateResult<1>;
    }
}
declare module "_102053_/l2/testes/product-edit" {
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    import '/_102040_/l2/molecules/groupentertext/ml-floating-text-input';
    import '/_102040_/l2/molecules/groupentertext/ml-multiline-text';
    import '/_102040_/l2/molecules/groupentermoney/ml-enter-money-br';
    import '/_102040_/l2/molecules/groupenternumber/ml-number-input';
    import '/_102040_/l2/molecules/groupenternumber/ml-number-stepper';
    import '/_102040_/l2/molecules/groupselectone/ml-select-dropdown';
    import '/_102040_/l2/molecules/groupselectmany/ml-multi-checkbox-list';
    import '/_102040_/l2/molecules/groupenterboolean/ml-toggle-switch';
    import '/_102040_/l2/molecules/groupnotifyuser/ml-toast-notification';
    export class ProductEdit extends StateLitElement {
        isEditing: boolean;
        toastVisible: boolean;
        errors: Record<string, string>;
        productName: string;
        sku: string;
        barcode: string;
        description: string;
        salePrice: number | null;
        costPrice: number | null;
        stock: number | null;
        minStock: number | null;
        packQty: number | null;
        category: string;
        supplier: string;
        tags: string;
        isActive: boolean;
        availOnline: boolean;
        private snapshot;
        private takeSnapshot;
        private restoreSnapshot;
        private edit;
        private cancel;
        private validate;
        private save;
        private err;
        private get margin();
        private get marginColor();
        private get stockStatus();
        private get categoryLabel();
        private get supplierLabel();
        render(): import("lit").TemplateResult<1>;
    }
}
declare module "_102053_/l2/testes/select-one" {
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    import '/_102040_/l2/molecules/groupselectone/ml-radio-group';
    import '/_102040_/l2/molecules/groupselectone/ml-segmented-control';
    export class SelectOne102040 extends StateLitElement {
        radioValue: string;
        radioGroupedValue: string;
        segmentedValue: string;
        segmentedErrorValue: string;
        render(): import("lit").TemplateResult<1>;
    }
}
declare module "_102053_/l2/testes/supplier-edit" {
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    import '/_102040_/l2/molecules/groupexpandcontent/ml-accordion';
    import '/_102040_/l2/molecules/groupentertext/ml-floating-text-input';
    import '/_102040_/l2/molecules/groupentertext/ml-multiline-text';
    import '/_102040_/l2/molecules/groupenterdate/ml-date-picker';
    import '/_102040_/l2/molecules/groupselectone/ml-select-dropdown';
    import '/_102040_/l2/molecules/groupselectone/ml-radio-group';
    import '/_102040_/l2/molecules/groupselectmany/ml-multi-checkbox-list';
    import '/_102040_/l2/molecules/groupenterboolean/ml-toggle-switch';
    import '/_102040_/l2/molecules/groupnotifyuser/ml-toast-notification';
    export class SupplierEdit extends StateLitElement {
        isEditing: boolean;
        toastVisible: boolean;
        viewEpoch: number;
        errors: Record<string, string>;
        companyName: string;
        cnpj: string;
        email: string;
        website: string;
        address: string;
        companyType: string;
        paymentTerm: string;
        currency: string;
        taxRegime: string;
        contractStart: string;
        certExpiry: string;
        categories: string;
        isActive: boolean;
        isHomologated: boolean;
        isPreferred: boolean;
        notes: string;
        private snapshot;
        private takeSnapshot;
        private restoreSnapshot;
        private edit;
        private cancel;
        private validate;
        private save;
        private err;
        private get companyTypeLabel();
        private get taxRegimeLabel();
        private get paymentTermLabel();
        private get currencyLabel();
        private readonly categoryMap;
        private get categoryLabels();
        private get initials();
        private statusBadge;
        private renderViewMode;
        private renderEditMode;
        render(): import("lit").TemplateResult<1>;
    }
}
declare module "_102053_/l2/testes/system-settings" {
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    import '/_102040_/l2/molecules/groupnavigatesection/ml-tabs';
    import '/_102040_/l2/molecules/groupentertext/ml-floating-text-input';
    import '/_102040_/l2/molecules/groupselectone/ml-select-dropdown';
    import '/_102040_/l2/molecules/groupselectone/ml-segmented-control';
    import '/_102040_/l2/molecules/groupenternumber/ml-number-input';
    import '/_102040_/l2/molecules/groupentermoney/ml-enter-money-br';
    import '/_102040_/l2/molecules/groupenterboolean/ml-toggle-switch';
    import '/_102040_/l2/molecules/groupenterboolean/ml-checkbox-preference';
    import '/_102040_/l2/molecules/groupnotifyuser/ml-toast-notification';
    export class SystemSettings extends StateLitElement {
        activeTab: string;
        viewEpoch: number;
        toastVisible: boolean;
        toastMsg: string;
        isEditingGeral: boolean;
        isEditingNotif: boolean;
        isEditingLimites: boolean;
        isEditingIntegracoes: boolean;
        errors: Record<string, string>;
        companyName: string;
        domain: string;
        supportEmail: string;
        language: string;
        timezone: string;
        currency: string;
        theme: string;
        emailNotif: boolean;
        smsNotif: boolean;
        pushNotif: boolean;
        require2fa: boolean;
        autoApproveLimit: number;
        defaultingAlert: number;
        sessionTimeout: number;
        loginAttempts: number;
        erp: string;
        termsAccepted: boolean;
        dataRetention: boolean;
        private snapshotGeral;
        private snapshotNotif;
        private snapshotLimites;
        private snapshotIntegracoes;
        private editGeral;
        private cancelGeral;
        private saveGeral;
        private editNotif;
        private cancelNotif;
        private saveNotif;
        private editLimites;
        private cancelLimites;
        private saveLimites;
        private editIntegracoes;
        private cancelIntegracoes;
        private saveIntegracoes;
        private handleRequestEdit;
        private get languageLabel();
        private get timezoneLabel();
        private get currencyLabel();
        private get themeLabel();
        private get erpLabel();
        private formatMoney;
        private err;
        private badge;
        private editHeader;
        private renderGeralView;
        private renderNotifView;
        private renderLimitesView;
        private renderIntegracoesView;
        private renderGeralEditForm;
        private renderNotifEditForm;
        private renderLimitesEditForm;
        private renderIntegracoesEditForm;
        private renderActiveEditForm;
        private renderTabs;
        render(): import("lit").TemplateResult<1>;
    }
}
declare module "_102053_/l2/testes/training-catalog" {
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    import '/_102040_/l2/molecules/groupnavigatesection/ml-breadcrumb-trail';
    import '/_102040_/l2/molecules/groupviewcard/ml-view-card-media';
    import '/_102040_/l2/molecules/groupviewdata/ml-card-grid';
    import '/_102040_/l2/molecules/groupplaymedia/ml-video-player';
    import '/_102040_/l2/molecules/groupplaymedia/ml-audio-player';
    import '/_102040_/l2/molecules/groupshowprogress/ml-linear-progress';
    import '/_102040_/l2/molecules/groupshowprogress/ml-circular-progress';
    import '/_102040_/l2/molecules/grouprateitem/ml-star-rating';
    import '/_102040_/l2/molecules/grouprateitem/ml-numeric-rating-nps';
    import '/_102040_/l2/molecules/groupexpandcontent/ml-single-expand-content';
    import '/_102040_/l2/molecules/groupenterdateinterval/ml-date-interval-drag';
    import '/_102040_/l2/molecules/grouptriggeraction/ml-split-button';
    import '/_102040_/l2/molecules/grouptriggeraction/ml-button-group';
    import '/_102040_/l2/molecules/groupselectmany/ml-multi-select-dropdown';
    import '/_102040_/l2/molecules/groupsearchcontent/ml-search-bar';
    import '/_102040_/l2/molecules/groupnotifyuser/ml-toast-notification';
    type FormatFilter = 'video' | 'audio' | 'reading';
    export class TrainingCatalog extends StateLitElement {
        lessonProgress: number;
        courseComplete: boolean;
        userRating: number;
        npsScore: number | null;
        formatFilter: FormatFilter;
        areaFilter: string;
        searchQuery: string;
        enrollmentStart: string;
        enrollmentEnd: string;
        toastVisible: boolean;
        toastMessage: string;
        private readonly course;
        private readonly recommendedCourses;
        private get filteredCourses();
        private showToast;
        private simulateProgress;
        private formatLabel;
        render(): import("lit").TemplateResult<1>;
    }
}
declare module "_102053_/l2/testes/vehicle-registration" {
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    import '/_102040_/l2/molecules/groupentertext/ml-floating-text-input';
    import '/_102040_/l2/molecules/groupselectone/ml-combobox';
    import '/_102040_/l2/molecules/groupselectone/ml-select-one-autocomplete';
    import '/_102040_/l2/molecules/groupselectone/ml-segmented-control';
    import '/_102040_/l2/molecules/groupenternumber/ml-number-input';
    import '/_102040_/l2/molecules/groupnotifyuser/ml-notify-banner';
    export class VehicleRegistration extends StateLitElement {
        codigo: string;
        dataInclusao: string;
        dataModificacao: string;
        placa: string;
        situacao: string;
        marca: string;
        modelo: string;
        anoFabricacao: number | null;
        anoModelo: number | null;
        quilometragem: number | null;
        errors: Record<string, string>;
        saved: boolean;
        private readonly currentYear;
        private readonly brands;
        private readonly modelsByBrand;
        private err;
        private getModelos;
        private validate;
        private handleSave;
        private handleCancel;
        render(): import("lit").TemplateResult<1>;
        private renderControle;
        private renderIdentificacao;
        private renderDadosVeiculo;
        private renderEstadoAtual;
        private renderSectionHeader;
    }
}
