declare module "_102027_/l2/collabImport" {
    interface CollabImportOptions {
        project: number;
        shortName: string;
        folder: string;
        extension?: '.defs.ts' | '.ts' | '.test.ts';
    }
    export function collabImport(opts: CollabImportOptions): Promise<any>;
}
declare module "_102027_/l2/utils" {
    export function getPath(widget: string): mls.stor.IFileInfoBase | undefined;
    export function convertTagToFileName(tag: string): {
        shortName: string;
        project: number;
        folder: string;
    } | undefined;
    export function convertFileNameToTag(info: {
        shortName: string;
        project: number;
        folder?: string;
    }): string;
    export function setErrorOnModel(model: monaco.editor.ITextModel, line: number, startColumn: number, endColumn: number, message: string, severity: monaco.MarkerSeverity): void;
}
declare module "_102027_/l2/libCompile" {
    export const getDependenciesByHtmlFile: (file: mls.stor.IFileInfo, html: string, theme: string, withCss?: boolean) => Promise<IJSONDependence>;
    export const getDependenciesByHtml: (models: mls.editor.IModels, html: string, theme: string, withCss?: boolean) => Promise<IJSONDependence>;
    export const getDependenciesByMFile: (models: mls.editor.IModels, withCss?: boolean) => Promise<IJSONDependence>;
    export function getAllWebComponentsInSource(source: string): string[];
    export interface IJSONDependence {
        file: string;
        wcComponents: string[];
        importsMap: string[];
        importsJs: string[];
        importsLinks: {
            ref: string;
            rel: string;
        }[];
        tokens: string | undefined;
        globalCss: string;
        errors: {
            tag: string;
            error: string;
        }[];
    }
}
declare module "_102027_/l2/libCommom" {
    export function getMyKeysBranch(project: number): {
        branch: string;
        owner: string;
        repo: string;
    };
    export function createPath(project: number, shortName: string, folder: string): string;
    export function generateCompactTimestamp(): string;
    export function getDateFormated(dt: string): string;
    export function changeFavIcon(notification: boolean): void;
    export function checkIfHasLocalProject(): boolean;
    export function getLocalProjectName(): string;
    export function setLocalProjectName(prjName: string): void;
    export function getLocalProjectDependencies(): number[];
    export function setLocalProjectDependencies(dependencies: number[]): void;
    export function deleteLocalProject(): Promise<void>;
    export function isValidProjectName(name: string): boolean;
    export function escapeHTML(str: string): string;
    export function openService(service: string, position: 'left' | 'right', level: number, args?: Record<string, string>): Promise<void>;
    export function selectLevel(level: number): void;
    export function forceServiceInstance(level: number, service: string): Promise<void>;
    export function loadFileHTMLInContainer(el: HTMLElement, shortName: string, project: number): Promise<void>;
    export function convertColorToHex(color: string): string;
    export function getEnhancementName(file: {
        project: number;
        shortName: string;
        folder: string;
        level: number;
    }): Promise<string>;
    export function getStyleEnhancementName(file: {
        project: number;
        shortName: string;
        folder: string;
        level: number;
    }): Promise<string | undefined>;
    export function loadPluginProject(project: number, scope: string, onlyEnabled?: boolean): Promise<mls.plugin.MenuAction[]>;
    export function setProjectDetails(project: number): void;
    export function getProjectDetails(): mls.stor.localStor.IRetProjectDetails | undefined;
    export function calculateTotalStringSize(source: string, limitBase: number): ICalculateTotalStringSize;
    export function getListNewFilesToDeleteByFolder(project: number, folder: string, includeDist?: boolean): Promise<mls.stor.IFileInfo[]>;
    export function deleteAllFilesLocal(filesToDelete: mls.stor.IFileInfo[]): AsyncGenerator<string, void, unknown>;
    export function loadModuleFromProjectOrDependency(name: string, folder: string, ext: string): Promise<any>;
    export function findStorFileInProjectsOrDeps(projectActual: number, level: number, fileName: string, folder: string, extension: string): mls.stor.IFileInfo;
    export function saveOpenedFile(project: number, level: number, file: OpenedFile): void;
    export function getLastOpenedFiles(project: number): UserOpenedFiles;
    export function deleteLastOpenedFiles(project: number): void;
    export function getLastModule(): Record<string, string>;
    export function setLastModule(project: number, moduleName: string): void;
    export function getBaseTemplate(file: IInfoFile, enhancement?: string): Promise<string>;
    export function verifyNeedAddTripleslach(info: mls.stor.IFileInfoBase, src: string, extension: string, enhancement?: string): string;
    export function getInstanceByFile(file: mls.stor.IFileInfo): Promise<Object | undefined>;
    export function isNameValid(project: number, shortName: string, folder: string, level: number, extension: string): boolean;
    export function openElementInServiceDetails(el: HTMLElement): Promise<void>;
    export function clearServiceDetails(): Promise<void>;
    export function getProjectConfig(project: number): Promise<IProjectConfig | undefined>;
    export function getProjectModuleConfig(path: string, project: number): Promise<IProjectModuleConfig | undefined>;
    export function getMessageKey(messages: any): string;
    export type OpenedFile = string | OpenedFileL2;
    export type UserOpenedFiles = Record<number, OpenedFile>;
    export type OpenedFileL2 = {
        left?: string;
        right?: string;
    };
    export interface IProjectModuleConfig {
        theme: string;
        initialPage: string;
        menu: IProjectModuleConfigMenu[];
    }
    export interface IProjectModuleConfigMenu {
        pageName: string;
        title: string;
        auth: string;
        icon?: string;
        target?: string;
    }
    export interface IProjectConfigModules {
        name: string;
        path: string;
        pathServer?: string;
        auth: string;
        icon?: string;
    }
    export interface IProjectConfig {
        masterFrontEnd?: {
            build: string;
            start: string;
            liveView: string;
        };
        masterBackEnd?: {
            build: string;
            start: string;
            serverView: string;
        };
        modules: IProjectConfigModules[];
    }
    interface ICalculateTotalStringSize {
        totalsize: number;
        exceededLimit: boolean;
        sizeFormatted: string;
    }
    interface IInfoFile {
        project: number;
        folder: string;
        shortName: string;
        extension: string;
    }
}
declare module "_102027_/l2/libMindMap" {
    export const allDefs: Record<string, IdefModule>;
    export function getAllDefs(): Promise<Record<string, IdefModule>>;
    export function getDefsByFile(file: mls.stor.IFileInfo): Promise<mls.defs.AsIs | undefined>;
    export function getMindMapByName(file: string): Promise<MindMapData | undefined>;
    export function getMindMapByStorFile(file: mls.stor.IFileInfo): Promise<MindMapData | undefined>;
    export function setMindMapVariable(bread: MindMapNode[]): void;
    export function getMindMapVariable(): MindMapNode[];
    export type MindMapSelected = MindMapSelectedFile | MindMapSelectedPlugin;
    export interface MindMapSelectedBase {
        plugin: Function;
        args: string;
    }
    export interface MindMapSelectedFile extends MindMapSelectedBase {
        type: "file";
        file: mls.stor.IFileInfo;
        organism?: string;
        widget?: string;
        modelType?: mls.editor.ModelType;
    }
    export interface MindMapSelectedPlugin extends MindMapSelectedBase {
        type: "plugin";
        file: mls.stor.IFileInfo;
    }
    export type MindMapNodeType = 'main' | 'asIs' | 'codeInsights' | 'webcomponent' | 'imports' | 'importedBy' | 'language' | 'attributes' | 'file' | 'file_wc' | 'text' | 'findFile' | 'findFile_item';
    export interface MindMapNode {
        id: string;
        label: string;
        type: MindMapNodeType;
        related: string[];
        meta: Record<string, any>;
        description?: string;
        navigate?: boolean;
    }
    export interface MindMapData {
        current: string;
        nodes: MindMapNode[];
    }
    export interface MindMapNodeStyle {
        fill: string;
        stroke: string;
        text: string;
    }
    export type MindMapNodeStyles = Record<string, MindMapNodeStyle>;
    export interface IdefModule {
        file: mls.stor.IFileInfo;
        defs: mls.defs.AsIs;
    }
}
declare module "_102027_/l2/libModel" {
    export function waitModelIdle(model: mls.editor.IModelBase | undefined): Promise<void>;
    export function readProjectTypescriptAndCompile(project: number, shortName: string, needCompile?: boolean): Promise<void>;
    export function readProjectTypescriptAndCompileL1(project: number, shortName: string, needCompile?: boolean): Promise<void>;
    export function createAllModels(storFileBase: mls.stor.IFileInfo, needCompile?: boolean, awaitCompile?: boolean, createStorIfNeed?: boolean): Promise<mls.editor.IModels | undefined>;
    export function createModel(storFile: mls.stor.IFileInfo, needCompile?: boolean, awaitCompile?: boolean): Promise<mls.editor.IModelBase | undefined>;
    export function setErrorOnModel(model: monaco.editor.ITextModel, line: number, startColumn: number, endColumn: number, message: string, severity: monaco.MarkerSeverity): void;
    export function createModelAnyFile(storFile: mls.stor.IFileInfo): Promise<mls.editor.IModelBase>;
    export function setModelEventAny(model: mls.editor.IModelBase, storFile: mls.stor.IFileInfo): void;
    export function _MarkCompileNeed(storFile: mls.stor.IFileInfo): Promise<void>;
    export interface IModelProcessing {
        begin(): void;
        end(): void;
        whenIdle(): Promise<void>;
        isProcessing(): boolean;
    }
    export class ModelProcessing implements IModelProcessing {
        private running;
        private idlePromise;
        private idleResolve;
        begin(): void;
        end(): void;
        whenIdle(): Promise<void>;
        isProcessing(): boolean;
    }
    export interface IModelBase extends mls.editor.IModelBase {
        changeTimeout?: number;
        processing?: IModelProcessing;
    }
}
declare module "_102027_/l2/designSystemBase" {
    export function getTokens(project: number): Promise<IDesignSystemTokens[]>;
    export function getTokensLess(project: number, theme: string): Promise<string>;
    export function getTokensLessByTokensArray(tokens: IDesignSystemTokens[], theme: string): Promise<string>;
    export function getTokensCss(project: number, theme: string): Promise<string>;
    export function getGlobalCss(project: number, theme: string): Promise<string>;
    export function getGlobalLess(project: number): Promise<string>;
    export function compileLess(str: string): Promise<string>;
    export function preCompileLess(project: number, less: string, theme: string): Promise<string>;
    export function preCompileLessAction(lessSource: string, tokens: IDesignSystemTokens[], theme: string): Promise<string>;
    export function preCompileLessByThemeOrDefault(project: number, less: string, theme: string): Promise<string>;
    export function removeTokensFromSource(src: string): string;
    export function removeTokensTheme(project: number, themeName: string): Promise<void>;
    export function replaceTokensBlock(code: string, newContent: string): string;
    export interface IDesignSystemTokens {
        description: string;
        themeName: string;
        color: Record<string, string>;
        global: Record<string, string>;
        typography: Record<string, string>;
    }
    export interface IDesignSystem {
        tokens: IDesignSystemTokens[];
    }
    interface IKeyValueToken {
        [x: string]: string;
    }
    export interface IDarkLight {
        [theme: string]: IKeyValueToken;
    }
}
declare module "_102053_/l2/designSystem" {
    import { IDesignSystemTokens } from "_102027_/l2/designSystemBase";
    export const tokens: IDesignSystemTokens[];
}
declare module "_102053_/l2/project" {
    export const projectConfig: {
        masterFrontEnd: {
            build: string;
            start: string;
            liveView: string;
        };
        masterBackEnd: {
            build: string;
            start: string;
            serverView: string;
        };
        modules: any[];
    };
}
declare module "_102053_/l2/glassshowcase/checkout" {
    import { TemplateResult } from 'lit';
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    import '/_102054_/l2/molecules/groupentertext/ml-floating-text-input';
    import '/_102054_/l2/molecules/groupenterboolean/ml-toggle-switch';
    import '/_102054_/l2/molecules/groupexpandcontent/ml-accordion';
    import '/_102054_/l2/molecules/grouptriggeraction/ml-button-standard';
    export class GlassShowcaseCheckout extends StateLitElement {
        private cardName;
        private cardNumber;
        private expiry;
        private cpf;
        private saveCard;
        private diffAddress;
        private loading;
        private onCardName;
        private onCardNumber;
        private onExpiry;
        private onCpf;
        private onSaveCard;
        private onDiffAddress;
        private onConfirm;
        render(): TemplateResult;
    }
}
declare module "_102053_/l2/glassshowcase/login" {
    import { TemplateResult } from 'lit';
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    import '/_102054_/l2/molecules/groupentertext/ml-floating-text-input';
    import '/_102054_/l2/molecules/groupenterboolean/ml-toggle-switch';
    import '/_102054_/l2/molecules/grouptriggeraction/ml-button-standard';
    export class GlassShowcaseLogin extends StateLitElement {
        private email;
        private password;
        private remember;
        private emailError;
        private loading;
        private onEmailInput;
        private onPasswordInput;
        private onRememberChange;
        private isEmailValid;
        private onSubmit;
        private goToSignup;
        render(): TemplateResult;
    }
}
declare module "_102053_/l2/glassshowcase/settings" {
    import { TemplateResult } from 'lit';
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    import '/_102054_/l2/molecules/groupentertext/ml-floating-text-input';
    import '/_102054_/l2/molecules/groupenterboolean/ml-toggle-switch';
    import '/_102054_/l2/molecules/groupexpandcontent/ml-accordion';
    import '/_102054_/l2/molecules/grouptriggeraction/ml-button-standard';
    export class GlassShowcaseSettings extends StateLitElement {
        private dirty;
        private loading;
        private values;
        private onFieldChange;
        private onSave;
        private onCancel;
        render(): TemplateResult;
    }
}
declare module "_102053_/l2/glassshowcase/signup" {
    import { TemplateResult } from 'lit';
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    import '/_102054_/l2/molecules/groupentertext/ml-floating-text-input';
    import '/_102054_/l2/molecules/groupenterboolean/ml-toggle-switch';
    import '/_102054_/l2/molecules/grouptriggeraction/ml-button-standard';
    export class GlassShowcaseSignup extends StateLitElement {
        private name;
        private email;
        private phone;
        private password;
        private acceptedTerms;
        private loading;
        private onName;
        private onEmail;
        private onPhone;
        private onPassword;
        private onTerms;
        private onSubmit;
        private goToLogin;
        render(): TemplateResult;
    }
}
declare module "_102053_/l2/molecules/groupenterboolean/ml-toggle-switch.defs" {
    export const group = "groupEnterBoolean";
    export const skill = "# Metadata\n- TagName: groupenterboolean--ml-toggle-switch\n\n# Objective\nA toggle switch molecule. Themed version for design model POC.";
}
declare module "_102053_/l2/molecules/groupenterboolean/ml-toggle-switch" {
    import { MoleculeAuraElement } from '_102033_/l2/moleculeBase';
    export class ToggleSwitchMolecule extends MoleculeAuraElement {
        private msg;
        private uid;
        slotTags: string[];
        value: boolean;
        error: string;
        name: string;
        isEditing: boolean;
        disabled: boolean;
        private handleToggle;
        private handleFocus;
        private handleBlur;
        private handleKeydown;
        private renderLabel;
        private renderHelper;
        private renderError;
        private getToggleButtonClasses;
        private getThumbClasses;
        private renderViewMode;
        render(): any;
    }
}
declare module "_102053_/l2/molecules/groupentertext/ml-floating-text-input.defs" {
    export const group = "groupEnterText";
    export const skill = "# Metadata\n- TagName: groupentertext--ml-floating-text-input\n\n# Objective\nA floating-label text input molecule. Themed version for design model POC.";
}
declare module "_102053_/l2/molecules/groupentertext/ml-floating-text-input" {
    import { MoleculeAuraElement } from '_102033_/l2/moleculeBase';
    export class MlFloatingTextInputMolecule extends MoleculeAuraElement {
        slotTags: string[];
        value: string;
        error: string;
        name: string;
        placeholder: string;
        maxLength: number | null;
        minLength: number | null;
        rows: number;
        autocomplete: string;
        inputType: string;
        mask: string;
        isEditing: boolean;
        disabled: boolean;
        readonly: boolean;
        required: boolean;
        loading: boolean;
        private rawDisplay;
        private isFocused;
        private uid;
        handleIcaStateChange(key: string, value: any): void;
        updated(changedProps: Map<string, unknown>): void;
        private handleInput;
        private handleBlur;
        private handleFocus;
        private shouldUseMask;
        private getMaskedDisplayValue;
        private applyMaskToRaw;
        private extractRawFromInput;
        private isMaskToken;
        private isCharValidForToken;
        private getLabelText;
        private getInputPlaceholder;
        private getViewValue;
        private renderPrefix;
        private renderSuffix;
        private renderFeedback;
        private renderInlineLabel;
        private renderFloatingLabel;
        private getContainerClasses;
        private getInputClasses;
        render(): any;
    }
}
declare module "_102053_/l2/molecules/groupexpandcontent/ml-accordion.defs" {
    export const group = "groupExpandContent";
    export const skill = "# Metadata\n- TagName: groupexpandcontent--ml-accordion\n\n# Objective\nAn accordion molecule. Themed version for design model POC.";
}
declare module "_102053_/l2/molecules/groupexpandcontent/ml-accordion" {
    import { MoleculeAuraElement } from '_102033_/l2/moleculeBase';
    export class MlAccordionMolecule extends MoleculeAuraElement {
        private msg;
        slotTags: string[];
        multiple: boolean;
        disabled: boolean;
        loading: boolean;
        private openSections;
        firstUpdated(): void;
        private handleToggle;
        private handleHeaderKeydown;
        private findNextEnabledHeader;
        private getSectionContent;
        private getHeaderClasses;
        private getContentClasses;
        private getChevronClasses;
        render(): any;
        private renderLabel;
        private renderLoading;
        private renderSections;
        private renderSection;
    }
}
declare module "_102053_/l2/molecules/grouptriggeraction/ml-button-standard.defs" {
    export const group = "groupTriggerAction";
    export const skill = "# Metadata\n- TagName: grouptriggeraction--ml-button-standard\n\n# Objective\nA standard button molecule. Themed version for design model POC.";
}
declare module "_102053_/l2/molecules/grouptriggeraction/ml-button-standard" {
    import { MoleculeAuraElement } from '_102033_/l2/moleculeBase';
    export class ButtonStandardMolecule extends MoleculeAuraElement {
        slotTags: string[];
        size: 'xs' | 'sm' | 'md' | 'lg';
        type: 'button' | 'submit' | 'reset';
        iconPosition: 'start' | 'end';
        disabled: boolean;
        loading: boolean;
        private handleActionClick;
        private isDisabled;
        private getVariant;
        private getSizeKey;
        private getSizeClasses;
        private getVariantClasses;
        private getButtonClasses;
        private getIconClasses;
        private renderSpinner;
        render(): any;
    }
}
declare module "_102053_/l2/testes/account-settings" {
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    import '/_102040_/l2/molecules/groupnavigatesection/ml-tabs';
    import '/_102040_/l2/molecules/groupentertext/ml-floating-text-input';
    import '/_102040_/l2/molecules/groupentertext/ml-multiline-text';
    import '/_102040_/l2/molecules/groupentertext/ml-cpf-input';
    import '/_102040_/l2/molecules/groupentermoney/ml-enter-money-br';
    import '/_102040_/l2/molecules/groupenterdate/ml-date-picker';
    import '/_102040_/l2/molecules/groupselectone/ml-select-dropdown';
    import '/_102040_/l2/molecules/groupselectone/ml-segmented-control';
    import '/_102040_/l2/molecules/groupenterboolean/ml-toggle-switch';
    import '/_102040_/l2/molecules/groupenterboolean/ml-checkbox-preference';
    import '/_102040_/l2/molecules/groupnotifyuser/ml-toast-notification';
    export class AccountSettings extends StateLitElement {
        activeTab: string;
        viewEpoch: number;
        toastVisible: boolean;
        toastMsg: string;
        isEditingPerfil: boolean;
        isEditingSeguranca: boolean;
        isEditingCobranca: boolean;
        errors: Record<string, string>;
        name: string;
        email: string;
        phone: string;
        birthDate: string;
        bio: string;
        recoveryEmail: string;
        twoFaEnabled: boolean;
        pushNotif: boolean;
        cpf: string;
        spendingLimit: number;
        spendingAlert: number;
        autoPayment: boolean;
        termsAccepted: boolean;
        language: string;
        timezone: string;
        theme: string;
        private snapshotPerfil;
        private snapshotSeguranca;
        private snapshotCobranca;
        private editPerfil;
        private cancelPerfil;
        private savePerfil;
        private editSeguranca;
        private cancelSeguranca;
        private saveSeguranca;
        private editCobranca;
        private cancelCobranca;
        private saveCobranca;
        private handleRequestEdit;
        private get languageLabel();
        private get timezoneLabel();
        private get themeLabel();
        private formatMoney;
        private formatCpf;
        private err;
        private badge;
        private editHeader;
        private renderPerfilView;
        private renderSegurancaView;
        private renderCobrancaView;
        private renderPreferenciasView;
        private renderPerfilEditForm;
        private renderSegurancaEditForm;
        private renderCobrancaEditForm;
        private renderPreferenciasControls;
        private renderActivePanel;
        private renderTabs;
        render(): any;
    }
}
declare module "_102053_/l2/testes/appointment-scheduler" {
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    import '/_102040_/l2/molecules/groupnavigatesection/ml-tabs';
    import '/_102040_/l2/molecules/groupentertext/ml-floating-text-input';
    import '/_102040_/l2/molecules/groupentertext/ml-multiline-text';
    import '/_102040_/l2/molecules/groupenterdatetime/ml-datetime-picker';
    import '/_102040_/l2/molecules/groupenterdatetimeinterval/ml-enter-datetime-interval';
    import '/_102040_/l2/molecules/groupentertimeinterval/ml-time-interval-selector';
    import '/_102040_/l2/molecules/groupselectone/ml-select-one-autocomplete';
    import '/_102040_/l2/molecules/groupselectmany/ml-multi-select-dropdown';
    import '/_102040_/l2/molecules/groupselectone/ml-radio-group';
    import '/_102040_/l2/molecules/groupenternumber/ml-number-input';
    import '/_102040_/l2/molecules/groupnotifyuser/ml-toast-notification';
    import '/_102040_/l2/molecules/groupviewtable/ml-data-table-minimal';
    interface Meeting {
        id: number;
        title: string;
        date: string;
        room: string;
        participants: number;
    }
    export class AppointmentScheduler extends StateLitElement {
        activeTab: string;
        viewEpoch: number;
        toastVisible: boolean;
        toastMsg: string;
        title: string;
        agenda: string;
        startAt: string;
        intervalStart: string;
        intervalEnd: string;
        preferredStart: string;
        preferredEnd: string;
        participants: string[];
        selectedRooms: string[];
        recurrence: string;
        recurrenceCount: number;
        errors: Record<string, string>;
        upcomingMeetings: Meeting[];
        private readonly availableRooms;
        private readonly allParticipants;
        private validate;
        private err;
        private handleAgendar;
        private handleParticipantSelect;
        private removeParticipant;
        private renderTabs;
        private renderNovaReuniaoForm;
        private renderMinhasReunioes;
        render(): any;
    }
}
declare module "_102053_/l2/testes/budget-editor" {
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    import '/_102040_/l2/molecules/groupviewtable/ml-data-table';
    import '/_102040_/l2/molecules/groupentermoney/ml-enter-money-br';
    import '/_102040_/l2/molecules/groupentertext/ml-floating-text-input';
    import '/_102040_/l2/molecules/groupselectone/ml-select-dropdown';
    import '/_102040_/l2/molecules/groupenternumber/ml-number-input';
    import '/_102040_/l2/molecules/groupselectone/ml-segmented-control';
    import '/_102040_/l2/molecules/groupnotifyuser/ml-notify-banner';
    import '/_102040_/l2/molecules/groupnotifyuser/ml-toast-notification';
    interface BudgetRow {
        id: number;
        description: string;
        costCenter: string;
        qty: number;
        planned: number;
        actual: number;
    }
    export class BudgetEditor extends StateLitElement {
        rows: BudgetRow[];
        activeFilter: 'all' | 'over' | 'within';
        editingRowId: number | null;
        tableEpoch: number;
        bannerDismissed: boolean;
        toastVisible: boolean;
        editDescription: string;
        editCostCenter: string;
        editQty: number;
        editPlanned: number;
        editActual: number;
        errors: Record<string, string>;
        private editSnapshot;
        private get filteredRows();
        private get overBudgetRows();
        private get editingRow();
        private fmt;
        private err;
        private handleRowClick;
        private openEdit;
        private cancelEdit;
        private saveEdit;
        private renderTable;
        private renderEditPanel;
        render(): any;
    }
}
declare module "_102053_/l2/testes/candidate-pipeline" {
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    import '/_102040_/l2/molecules/groupnavigatesection/ml-navigate-pills';
    import '/_102040_/l2/molecules/groupviewcard/ml-view-card-horizontal';
    import '/_102040_/l2/molecules/grouprateitem/ml-star-rating';
    import '/_102040_/l2/molecules/grouprateitem/ml-thumbs-rating';
    import '/_102040_/l2/molecules/groupselectfileforupload/ml-file-upload-dropzone';
    import '/_102040_/l2/molecules/groupselectfileforupload/ml-user-photo-upload';
    import '/_102040_/l2/molecules/groupviewdata/ml-vertical-record-list';
    import '/_102040_/l2/molecules/groupexpandcontent/ml-readmore-expand';
    import '/_102040_/l2/molecules/groupenterdate/ml-compact-calendar';
    import '/_102040_/l2/molecules/grouptriggeraction/ml-button-standard';
    import '/_102040_/l2/molecules/grouptriggeraction/ml-icon-button';
    import '/_102040_/l2/molecules/groupsearchcontent/ml-search-bar';
    import '/_102040_/l2/molecules/groupnotifyuser/ml-toast-notification';
    type Stage = 'triagem' | 'interview' | 'technical' | 'proposal' | 'hired';
    interface HistoryEntry {
        date: string;
        type: string;
        description: string;
    }
    interface Candidate {
        id: number;
        name: string;
        role: string;
        stage: Stage;
        rating: number;
        thumb: 'up' | 'down' | null;
        cvFile: string | null;
        interviewDate: string;
        history: HistoryEntry[];
    }
    export class CandidatePipeline extends StateLitElement {
        activeStage: Stage;
        searchQuery: string;
        selectedId: number;
        toastVisible: boolean;
        toastMessage: string;
        candidates: Candidate[];
        private readonly job;
        private readonly stageOrder;
        private readonly stageLabels;
        private readonly nextStageLabel;
        private get selectedCandidate();
        private get filteredCandidates();
        private countByStage;
        private initials;
        private selectFirstInStage;
        private autoSelectAfterMutation;
        private advanceCandidate;
        private rejectCandidate;
        private updateCandidate;
        private showToast;
        render(): any;
        private renderCandidateCard;
        private renderEmptyPanel;
        private renderDetailPanel;
    }
}
declare module "_102053_/l2/testes/corporate-dashboard" {
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    import '/_102040_/l2/molecules/groupviewmetric/ml-metric-big-number';
    import '/_102040_/l2/molecules/groupviewmetric/ml-metric-gauge';
    import '/_102040_/l2/molecules/groupviewchart/ml-area-chart';
    import '/_102040_/l2/molecules/groupviewchart/ml-bar-chart';
    import '/_102040_/l2/molecules/groupviewtable/ml-data-table-minimal';
    import '/_102040_/l2/molecules/groupnotifyuser/ml-notify-banner';
    import '/_102040_/l2/molecules/groupselectone/ml-segmented-control';
    export class CorporateDashboard extends StateLitElement {
        period: string;
        bannerVisible: boolean;
        private readonly kpiData;
        private readonly transactions;
        private get kpis();
        private statusBadge;
        render(): any;
    }
}
declare module "_102053_/l2/testes/customer-profile" {
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    import '/_102040_/l2/molecules/groupentertext/ml-floating-text-input';
    import '/_102040_/l2/molecules/groupentertext/ml-cpf-input';
    import '/_102040_/l2/molecules/groupentertext/ml-multiline-text';
    import '/_102040_/l2/molecules/groupenterdate/ml-date-picker';
    import '/_102040_/l2/molecules/groupselectone/ml-select-dropdown';
    import '/_102040_/l2/molecules/groupselectone/ml-select-one-autocomplete';
    import '/_102040_/l2/molecules/groupselectmany/ml-multi-checkbox-list';
    import '/_102040_/l2/molecules/groupenterboolean/ml-checkbox-preference';
    import '/_102040_/l2/molecules/groupnotifyuser/ml-toast-notification';
    export class CustomerProfile extends StateLitElement {
        isEditing: boolean;
        toastVisible: boolean;
        errors: Record<string, string>;
        clientName: string;
        personType: string;
        cnpj: string;
        cpf: string;
        email: string;
        phone: string;
        segment: string;
        city: string;
        stateUF: string;
        registerDate: string;
        birthday: string;
        channels: string;
        acceptsOffers: boolean;
        acceptsWpp: boolean;
        notes: string;
        private snapshot;
        private takeSnapshot;
        private restoreSnapshot;
        private edit;
        private cancel;
        private validate;
        private save;
        private err;
        private get segmentLabel();
        private get initials();
        private get personTypeLabel();
        render(): any;
    }
}
declare module "_102053_/l2/testes/edicao-cliente" {
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    import '/_102040_/l2/molecules/groupentertext/ml-floating-text-input';
    import '/_102040_/l2/molecules/groupselectone/ml-combobox';
    import '/_102040_/l2/molecules/groupselectone/ml-segmented-control';
    import '/_102040_/l2/molecules/groupnotifyuser/ml-notify-banner';
    export class EdicaoClientePage extends StateLitElement {
        private nome;
        private endereco;
        private situacao;
        private pesquisa;
        private clienteAtual;
        private errors;
        private saved;
        connectedCallback(): void;
        private getClientes;
        private err;
        private handleSelect;
        private handleSave;
        private handleCancel;
        private clearForm;
        render(): any;
        private renderForm;
        private renderSectionHeader;
    }
}
declare module "_102053_/l2/testes/employee-profile" {
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    import '/_102040_/l2/molecules/groupentertext/ml-floating-text-input';
    import '/_102040_/l2/molecules/groupentertext/ml-cpf-input';
    import '/_102040_/l2/molecules/groupentertext/ml-multiline-text';
    import '/_102040_/l2/molecules/groupenterdate/ml-date-picker';
    import '/_102040_/l2/molecules/groupselectone/ml-select-dropdown';
    import '/_102040_/l2/molecules/groupselectone/ml-radio-group';
    import '/_102040_/l2/molecules/groupentermoney/ml-enter-money-br';
    import '/_102040_/l2/molecules/groupenterboolean/ml-toggle-switch';
    import '/_102040_/l2/molecules/groupnotifyuser/ml-toast-notification';
    export class EmployeeProfile extends StateLitElement {
        isEditing: boolean;
        toastVisible: boolean;
        errors: Record<string, string>;
        name: string;
        cpf: string;
        email: string;
        phone: string;
        birthDate: string;
        admissionDate: string;
        department: string;
        role: string;
        workRegime: string;
        salary: number | null;
        systemAccess: boolean;
        isAdmin: boolean;
        notes: string;
        private snapshot;
        private takeSnapshot;
        private restoreSnapshot;
        private edit;
        private cancel;
        private validate;
        private save;
        private err;
        private get departmentLabel();
        private get roleLabel();
        private get initials();
        render(): any;
    }
}
declare module "_102053_/l2/testes/employee-registration" {
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    import '/_102040_/l2/molecules/groupnavigatesteps/ml-horizontal-stepper';
    import '/_102040_/l2/molecules/groupentertext/ml-floating-text-input';
    import '/_102040_/l2/molecules/groupentertext/ml-cpf-input';
    import '/_102040_/l2/molecules/groupenterdate/ml-date-picker';
    import '/_102040_/l2/molecules/groupselectone/ml-select-dropdown';
    import '/_102040_/l2/molecules/groupselectone/ml-radio-group';
    import '/_102040_/l2/molecules/groupentermoney/ml-enter-money-br';
    import '/_102040_/l2/molecules/groupenterboolean/ml-toggle-switch';
    import '/_102040_/l2/molecules/groupenterboolean/ml-checkbox-preference';
    import '/_102040_/l2/molecules/groupselectmany/ml-multi-checkbox-list';
    import '/_102040_/l2/molecules/groupnotifyuser/ml-toast-notification';
    export class EmployeeRegistration extends StateLitElement {
        currentStep: number;
        toastVisible: boolean;
        errors: Record<string, string>;
        name: string;
        cpf: string;
        email: string;
        phone: string;
        birthDate: string;
        department: string;
        role: string;
        workRegime: string;
        admissionDate: string;
        salary: number | null;
        systemAccess: boolean;
        isAdmin: boolean;
        modules: string;
        privacyAccepted: boolean;
        private readonly steps;
        private validate;
        private next;
        private back;
        private err;
        render(): any;
        private renderStep0;
        private renderStep1;
        private renderStep2;
    }
}
declare module "_102053_/l2/testes/escolha-orcamento" {
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    import '/_102040_/l2/molecules/groupnavigatesteps/ml-wizard-steps';
    import '/_102040_/l2/molecules/groupviewtable/ml-data-table-select';
    import '/_102040_/l2/molecules/groupviewmetric/ml-metric-card';
    import '/_102040_/l2/molecules/groupenterboolean/ml-toggle-switch';
    import '/_102040_/l2/molecules/groupentertext/ml-multiline-text';
    import '/_102040_/l2/molecules/groupnotifyuser/ml-notify-banner';
    export class EscolhaOrcamentoPage extends StateLitElement {
        private step;
        private steps;
        private orcamentoSelecionado;
        private orcamentoIdx;
        private tarefas;
        private bloquearVeiculo;
        private justificativa;
        private justificativaError;
        private osGerada;
        private getMenorValor;
        private brl;
        private stars;
        private tarefaLabel;
        private completeStep;
        private handleWizardChange;
        private handleTableChange;
        private handleNext;
        private handleBack;
        private handleGerarOS;
        render(): any;
        private renderNav;
        private renderStep0;
        private renderStep1;
        private compRow;
        private handleVistoriaChange;
        private renderStep2;
        private renderStep3;
        private renderStep4;
    }
}
declare module "_102053_/l2/testes/field-service-order" {
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    import '/_102040_/l2/molecules/groupnavigatesteps/ml-vertical-stepper';
    import '/_102040_/l2/molecules/groupscancode/ml-scan-code-1d';
    import '/_102040_/l2/molecules/groupscancode/ml-scan-code';
    import '/_102040_/l2/molecules/grouplocateposition/ml-locate-map-picker';
    import '/_102040_/l2/molecules/grouplocateposition/ml-geolocation-trigger';
    import '/_102040_/l2/molecules/groupshowprogress/ml-linear-progress';
    import '/_102040_/l2/molecules/groupshowprogress/ml-indeterminate-spinner';
    import '/_102040_/l2/molecules/groupentertime/ml-clock-time-picker';
    import '/_102040_/l2/molecules/groupentertime/ml-time-scroll-picker';
    import '/_102040_/l2/molecules/groupviewdata/ml-timeline-view';
    import '/_102040_/l2/molecules/groupexpandcontent/ml-single-expand-content';
    import '/_102040_/l2/molecules/grouptriggeraction/ml-button-standard';
    import '/_102040_/l2/molecules/grouptriggeraction/ml-icon-button';
    import '/_102040_/l2/molecules/groupentertext/ml-multiline-text';
    import '/_102040_/l2/molecules/groupenterboolean/ml-checkbox-preference';
    import '/_102040_/l2/molecules/groupnotifyuser/ml-toast-notification';
    interface ChecklistItem {
        id: number;
        label: string;
        done: boolean;
    }
    export class FieldServiceOrder extends StateLitElement {
        currentStep: number;
        scannedBarcode: string;
        scannedQr: string;
        locationCoords: string;
        arrivalTime: string;
        preferredWindowStart: string;
        preferredWindowEnd: string;
        report: string;
        loadingHistory: boolean;
        historyLoaded: boolean;
        toastVisible: boolean;
        toastMessage: string;
        checklist: ChecklistItem[];
        private readonly order;
        private readonly serviceHistory;
        private get doneCount();
        private get allDone();
        private get checklistProgress();
        private toggleItem;
        private showToast;
        private loadHistory;
        private nextStep;
        render(): any;
    }
}
declare module "_102053_/l2/testes/financial-report" {
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    import '/_102040_/l2/molecules/groupenterdateinterval/ml-date-range-dual-calendar';
    import '/_102040_/l2/molecules/groupselectone/ml-select-dropdown';
    import '/_102040_/l2/molecules/groupselectone/ml-segmented-control';
    import '/_102040_/l2/molecules/groupviewmetric/ml-metric-big-number';
    import '/_102040_/l2/molecules/groupviewchart/ml-area-chart';
    import '/_102040_/l2/molecules/groupviewchart/ml-pie-chart';
    import '/_102040_/l2/molecules/groupviewtable/ml-view-table';
    import '/_102040_/l2/molecules/groupnavigatesection/ml-tabs';
    export class FinancialReport extends StateLitElement {
        startDate: string;
        endDate: string;
        granularity: string;
        activeView: 'revenue' | 'expense' | 'margin';
        activeTab: string;
        private readonly summary;
        private kpiRing;
        render(): any;
    }
}
declare module "_102053_/l2/testes/ml-radio-group-exemple" {
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    import '/_102040_/l2/molecules/groupselectone/ml-radio-group';
    interface Config {
        value: string;
        isEditing: boolean;
        required: boolean;
        disabled: boolean;
        readonly: boolean;
        loading: boolean;
        error: string;
    }
    export class MlRadioGroupExemple extends StateLitElement {
        basic: Config;
        grouped: Config;
        private toggle;
        private renderToggle;
        private renderConfig;
        render(): any;
    }
}
declare module "_102053_/l2/testes/order-management" {
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    import '/_102040_/l2/molecules/groupsearchcontent/ml-search-bar';
    import '/_102040_/l2/molecules/groupenterdateinterval/ml-date-range-dual-calendar';
    import '/_102040_/l2/molecules/groupselectmany/ml-multi-select-dropdown';
    import '/_102040_/l2/molecules/groupselectone/ml-select-dropdown';
    import '/_102040_/l2/molecules/groupviewtable/ml-data-table';
    import '/_102040_/l2/molecules/groupnotifyuser/ml-notify-banner';
    import '/_102040_/l2/molecules/groupviewchart/ml-line-chart';
    import '/_102040_/l2/molecules/groupnavigatesection/ml-tabs';
    export class OrderManagement extends StateLitElement {
        activeTab: string;
        search: string;
        statusFilter: string;
        sortBy: string;
        filterStartDate: string;
        filterEndDate: string;
        page: number;
        bannerVisible: boolean;
        private readonly pageSize;
        private readonly allOrders;
        private readonly volumePoints;
        private get filteredOrders();
        private get visibleOrders();
        private toStatusKey;
        private countByTab;
        private statusBadge;
        private lateInTransit;
        render(): any;
    }
}
declare module "_102053_/l2/testes/org-chart" {
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    import '/_102040_/l2/molecules/groupnavigatemain/ml-sidebar-nav';
    import '/_102040_/l2/molecules/groupnavigatesection/ml-breadcrumb-trail';
    import '/_102040_/l2/molecules/groupnavigatesection/ml-navigate-pills';
    import '/_102040_/l2/molecules/groupviewhierarchy/ml-hierarchy-orgchart';
    import '/_102040_/l2/molecules/groupviewhierarchy/ml-hierarchy-tree';
    import '/_102040_/l2/molecules/groupviewhierarchy/ml-hierarchy-tree-diagram';
    import '/_102040_/l2/molecules/groupviewcard/ml-vertical-card';
    import '/_102040_/l2/molecules/groupsearchcontent/ml-search-bar';
    import '/_102040_/l2/molecules/groupselectone/ml-segmented-control';
    import '/_102040_/l2/molecules/groupshowprogress/ml-circular-progress';
    import '/_102040_/l2/molecules/grouptriggeraction/ml-icon-button';
    import '/_102040_/l2/molecules/groupnotifyuser/ml-toast-notification';
    type ViewMode = 'orgchart' | 'tree' | 'diagram';
    type LevelFilter = 'all' | 'exec' | 'manager' | 'operational';
    interface Employee {
        name: string;
        role: string;
        level: LevelFilter;
        dept: string;
        email: string;
    }
    export class OrgChart extends StateLitElement {
        activeDept: string;
        activeView: ViewMode;
        levelFilter: LevelFilter;
        searchQuery: string;
        selectedEmployee: Employee | null;
        loadingChart: boolean;
        loadingProgress: number;
        toastVisible: boolean;
        toastMessage: string;
        private readonly navItems;
        private readonly allEmployees;
        private get currentDeptLabel();
        private get employees();
        private initials;
        private levelLabel;
        private matchesSearch;
        private matchesLevel;
        private switchDept;
        private showToast;
        private handleNodeClick;
        private renderHierarchyNodes;
        render(): any;
    }
}
declare module "_102053_/l2/testes/product-edit" {
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    import '/_102040_/l2/molecules/groupentertext/ml-floating-text-input';
    import '/_102040_/l2/molecules/groupentertext/ml-multiline-text';
    import '/_102040_/l2/molecules/groupentermoney/ml-enter-money-br';
    import '/_102040_/l2/molecules/groupenternumber/ml-number-input';
    import '/_102040_/l2/molecules/groupenternumber/ml-number-stepper';
    import '/_102040_/l2/molecules/groupselectone/ml-select-dropdown';
    import '/_102040_/l2/molecules/groupselectmany/ml-multi-checkbox-list';
    import '/_102040_/l2/molecules/groupenterboolean/ml-toggle-switch';
    import '/_102040_/l2/molecules/groupnotifyuser/ml-toast-notification';
    export class ProductEdit extends StateLitElement {
        isEditing: boolean;
        toastVisible: boolean;
        errors: Record<string, string>;
        productName: string;
        sku: string;
        barcode: string;
        description: string;
        salePrice: number | null;
        costPrice: number | null;
        stock: number | null;
        minStock: number | null;
        packQty: number | null;
        category: string;
        supplier: string;
        tags: string;
        isActive: boolean;
        availOnline: boolean;
        private snapshot;
        private takeSnapshot;
        private restoreSnapshot;
        private edit;
        private cancel;
        private validate;
        private save;
        private err;
        private get margin();
        private get marginColor();
        private get stockStatus();
        private get categoryLabel();
        private get supplierLabel();
        render(): any;
    }
}
declare module "_102053_/l2/testes/select-one" {
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    import '/_102040_/l2/molecules/groupselectone/ml-radio-group';
    import '/_102040_/l2/molecules/groupselectone/ml-segmented-control';
    export class SelectOne102040 extends StateLitElement {
        radioValue: string;
        radioGroupedValue: string;
        segmentedValue: string;
        segmentedErrorValue: string;
        render(): any;
    }
}
declare module "_102053_/l2/testes/supplier-edit" {
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    import '/_102040_/l2/molecules/groupexpandcontent/ml-accordion';
    import '/_102040_/l2/molecules/groupentertext/ml-floating-text-input';
    import '/_102040_/l2/molecules/groupentertext/ml-multiline-text';
    import '/_102040_/l2/molecules/groupenterdate/ml-date-picker';
    import '/_102040_/l2/molecules/groupselectone/ml-select-dropdown';
    import '/_102040_/l2/molecules/groupselectone/ml-radio-group';
    import '/_102040_/l2/molecules/groupselectmany/ml-multi-checkbox-list';
    import '/_102040_/l2/molecules/groupenterboolean/ml-toggle-switch';
    import '/_102040_/l2/molecules/groupnotifyuser/ml-toast-notification';
    export class SupplierEdit extends StateLitElement {
        isEditing: boolean;
        toastVisible: boolean;
        viewEpoch: number;
        errors: Record<string, string>;
        companyName: string;
        cnpj: string;
        email: string;
        website: string;
        address: string;
        companyType: string;
        paymentTerm: string;
        currency: string;
        taxRegime: string;
        contractStart: string;
        certExpiry: string;
        categories: string;
        isActive: boolean;
        isHomologated: boolean;
        isPreferred: boolean;
        notes: string;
        private snapshot;
        private takeSnapshot;
        private restoreSnapshot;
        private edit;
        private cancel;
        private validate;
        private save;
        private err;
        private get companyTypeLabel();
        private get taxRegimeLabel();
        private get paymentTermLabel();
        private get currencyLabel();
        private readonly categoryMap;
        private get categoryLabels();
        private get initials();
        private statusBadge;
        private renderViewMode;
        private renderEditMode;
        render(): any;
    }
}
declare module "_102053_/l2/testes/system-settings" {
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    import '/_102040_/l2/molecules/groupnavigatesection/ml-tabs';
    import '/_102040_/l2/molecules/groupentertext/ml-floating-text-input';
    import '/_102040_/l2/molecules/groupselectone/ml-select-dropdown';
    import '/_102040_/l2/molecules/groupselectone/ml-segmented-control';
    import '/_102040_/l2/molecules/groupenternumber/ml-number-input';
    import '/_102040_/l2/molecules/groupentermoney/ml-enter-money-br';
    import '/_102040_/l2/molecules/groupenterboolean/ml-toggle-switch';
    import '/_102040_/l2/molecules/groupenterboolean/ml-checkbox-preference';
    import '/_102040_/l2/molecules/groupnotifyuser/ml-toast-notification';
    export class SystemSettings extends StateLitElement {
        activeTab: string;
        viewEpoch: number;
        toastVisible: boolean;
        toastMsg: string;
        isEditingGeral: boolean;
        isEditingNotif: boolean;
        isEditingLimites: boolean;
        isEditingIntegracoes: boolean;
        errors: Record<string, string>;
        companyName: string;
        domain: string;
        supportEmail: string;
        language: string;
        timezone: string;
        currency: string;
        theme: string;
        emailNotif: boolean;
        smsNotif: boolean;
        pushNotif: boolean;
        require2fa: boolean;
        autoApproveLimit: number;
        defaultingAlert: number;
        sessionTimeout: number;
        loginAttempts: number;
        erp: string;
        termsAccepted: boolean;
        dataRetention: boolean;
        private snapshotGeral;
        private snapshotNotif;
        private snapshotLimites;
        private snapshotIntegracoes;
        private editGeral;
        private cancelGeral;
        private saveGeral;
        private editNotif;
        private cancelNotif;
        private saveNotif;
        private editLimites;
        private cancelLimites;
        private saveLimites;
        private editIntegracoes;
        private cancelIntegracoes;
        private saveIntegracoes;
        private handleRequestEdit;
        private get languageLabel();
        private get timezoneLabel();
        private get currencyLabel();
        private get themeLabel();
        private get erpLabel();
        private formatMoney;
        private err;
        private badge;
        private editHeader;
        private renderGeralView;
        private renderNotifView;
        private renderLimitesView;
        private renderIntegracoesView;
        private renderGeralEditForm;
        private renderNotifEditForm;
        private renderLimitesEditForm;
        private renderIntegracoesEditForm;
        private renderActiveEditForm;
        private renderTabs;
        render(): any;
    }
}
declare module "_102053_/l2/testes/training-catalog" {
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    import '/_102040_/l2/molecules/groupnavigatesection/ml-breadcrumb-trail';
    import '/_102040_/l2/molecules/groupviewcard/ml-view-card-media';
    import '/_102040_/l2/molecules/groupviewdata/ml-card-grid';
    import '/_102040_/l2/molecules/groupplaymedia/ml-video-player';
    import '/_102040_/l2/molecules/groupplaymedia/ml-audio-player';
    import '/_102040_/l2/molecules/groupshowprogress/ml-linear-progress';
    import '/_102040_/l2/molecules/groupshowprogress/ml-circular-progress';
    import '/_102040_/l2/molecules/grouprateitem/ml-star-rating';
    import '/_102040_/l2/molecules/grouprateitem/ml-numeric-rating-nps';
    import '/_102040_/l2/molecules/groupexpandcontent/ml-single-expand-content';
    import '/_102040_/l2/molecules/groupenterdateinterval/ml-date-interval-drag';
    import '/_102040_/l2/molecules/grouptriggeraction/ml-split-button';
    import '/_102040_/l2/molecules/grouptriggeraction/ml-button-group';
    import '/_102040_/l2/molecules/groupselectmany/ml-multi-select-dropdown';
    import '/_102040_/l2/molecules/groupsearchcontent/ml-search-bar';
    import '/_102040_/l2/molecules/groupnotifyuser/ml-toast-notification';
    type FormatFilter = 'video' | 'audio' | 'reading';
    export class TrainingCatalog extends StateLitElement {
        lessonProgress: number;
        courseComplete: boolean;
        userRating: number;
        npsScore: number | null;
        formatFilter: FormatFilter;
        areaFilter: string;
        searchQuery: string;
        enrollmentStart: string;
        enrollmentEnd: string;
        toastVisible: boolean;
        toastMessage: string;
        private readonly course;
        private readonly recommendedCourses;
        private get filteredCourses();
        private showToast;
        private simulateProgress;
        private formatLabel;
        render(): any;
    }
}
declare module "_102053_/l2/testes/vehicle-registration" {
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    import '/_102040_/l2/molecules/groupentertext/ml-floating-text-input';
    import '/_102040_/l2/molecules/groupselectone/ml-combobox';
    import '/_102040_/l2/molecules/groupselectone/ml-select-one-autocomplete';
    import '/_102040_/l2/molecules/groupselectone/ml-segmented-control';
    import '/_102040_/l2/molecules/groupenternumber/ml-number-input';
    import '/_102040_/l2/molecules/groupnotifyuser/ml-notify-banner';
    export class VehicleRegistration extends StateLitElement {
        codigo: string;
        dataInclusao: string;
        dataModificacao: string;
        placa: string;
        situacao: string;
        marca: string;
        modelo: string;
        anoFabricacao: number | null;
        anoModelo: number | null;
        quilometragem: number | null;
        errors: Record<string, string>;
        saved: boolean;
        private readonly currentYear;
        private readonly brands;
        private readonly modelsByBrand;
        private err;
        private getModelos;
        private validate;
        private handleSave;
        private handleCancel;
        render(): any;
        private renderControle;
        private renderIdentificacao;
        private renderDadosVeiculo;
        private renderEstadoAtual;
        private renderSectionHeader;
    }
}
declare module "_102053_/l2/uidesign/design-showcase" {
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    import "_102053_/l2/molecules/groupentertext/ml-floating-text-input";
    import "_102053_/l2/molecules/groupenterboolean/ml-toggle-switch";
    import "_102053_/l2/molecules/groupexpandcontent/ml-accordion";
    import "_102053_/l2/molecules/grouptriggeraction/ml-button-standard";
    export class DesignShowcase extends StateLitElement {
        designModel: 'material' | 'brutalism' | 'flat' | 'glass';
        darkMode: boolean;
        inputValue: string;
        inputErrorValue: string;
        inputFilledValue: string;
        toggleOn: boolean;
        toggleOff: boolean;
        toggleDisabled: boolean;
        private setDesign;
        private toggleDarkMode;
        private renderTopBar;
        private renderSection;
        private renderInputDemos;
        private renderToggleDemos;
        private renderButtonDemos;
        private renderAccordionDemos;
        render(): any;
    }
}
